function [sr, WHres,  rho, resnorm]= dippa_fitWH(guess, haxes, selected, delK, K )
if nargin == 2
    
    %% values for fit
    load([cd,'/0. variables/phases.mat'],'dsettings')
    load([cd,'/0. variables/fit.mat'],'aa','aabcg')
    load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')

    WHpref= getappdata(0,'WHpref');
    selected = WHpref.selected;
    phaseno = WHpref.phaseno;
    type_FWorIB = WHpref.type_FWorIB;
    
    delK = getFW_IB(type_FWorIB,selected,phaseno);

    index=dsettings(phaseno).index(:,:);
    H2=Hsq(index);
    H2 = H2(selected);
    K = aa(1,selected);
    K2=[K;H2];
    
    
    %get rid of nan values from guess
    for i = 1:3
        switch i
            case 1
                if isnan(guess(1))
                    guess(i)= 2;
                end
            case 2
                if isnan(guess(2))
                    guess(i)= 200000;
                end                
            case 3
                if isnan(guess(3))
                    guess(i)= 1e-3;
                end                
        end
    end
end

%%
WHpref= getappdata(0,'WHpref');
type_sizestrain = WHpref.type_sizestrain;
qlb = WHpref.q_lb; qub =  WHpref.q_ub;
Aest = WHpref.chk0;
M = WHpref.M;

sizelb = WHpref.boundary_size(1); 
sizeub = WHpref.boundary_size(2);
strainlb = WHpref.boundary_strain(1); 
strainub = WHpref.boundary_strain(2);

fitype = WHpref.type_fitalgor;

lb=[qlb ,sizelb , strainlb    ];
ub=[qub ,sizeub ,  strainub    ];
K2(3,1)= Aest;


    
        %could be improved by giving a strain values based on WH
        %or mWH plus a 
        
switch fitype

    case 'lsqcu'
        sr = inner_lsqcu(guess, K2, delK, lb, ub,type_sizestrain);
        
    case 'psrch'
        sr = inner_psrch(guess, K2, delK, lb, ub,type_sizestrain);
        
    case 'genet'
        sr = inner_genet(guess, K2, delK, lb, ub,type_sizestrain);
        
    case 'siman'
        sr = inner_siman(guess, K2, delK, lb, ub,type_sizestrain);
        
end
        


%% get rho

%% strain_M*g.^2.*C  strain term MWH
strain_M = sr(3);
lat=dsettings(phaseno).lat1;
b = lat/2^0.5 ; %lat ni
fm2 = (pi * M^2 * b^2 /2);
a0=-0.173; b0=7.797; c0 =-4.818; d0=0.911;
fm2 = b^2*( a0 * log(M+1) + b0 * (log(M+1))^2 + ...
c0 * (log(M+1))^3 + d0 * (log(M+1))^4 );
  %fm2 == fm^2
switch type_sizestrain
    case 'mwhA'
% strain_M = sqrt(rho)*fm
% FWc =  sizee + strain*g.*C.^0.5;
rho = 1e4 * ( strain_M  / sqrt(fm2) ).^2;
resnorm = sum( (MWHA(sr, K2)-delK).^2);

    case 'mwhB'
% strain_M = sqrt(rho)*fm
%FWc =(  sizee^2 + strain^2*g.^2.*C  ).^0.5;

% gadj = 1e10;
rho = 1e4 *  ( strain_M  / sqrt(fm2) ).^2;

resnorm = sum( (MWHB(sr, K2)-delK).^2);

    case 'mwhC'
% strain_M = sqrt(rho)*fm^2 (*g^2)
% FWc =  sizee + strain*g.^2.*C  ;
% gadj = 1e10;
%below may be incorrect but gives closer values
rho = 1e4 *  ( strain_M  / sqrt(fm2) ).^2;

resnorm = sum( (MWHC(sr, K2)-delK).^2);

end


%% ends
q=sr(1);sizeA=sr(2);strain=sr(3);
[FWfitval, X, FWfit_line, X_line]= getWH(sr, selected,phaseno);

WHres.sizeA = sizeA;
WHres.strain = strain;
WHres.rho = rho;
WHres.q = q;


plot(X, delK,'parent',haxes,'marker','o',...
    'linestyle','none','markersize',15,'linewidth',2)
hold(haxes,'on')

plot(X_line,FWfit_line,'color','r',...
    'markersize',15,'linewidth',2,'parent',haxes)

xlabel(haxes,'C^0^.^5/d (10^-^1^0 m^-^1)','fontsize',14)
switch type_FWorIB
    case 'FW'
ylabel(haxes,'Full-width (10^-^1^0 m^-^1)','fontsize',14)
    case 'IB'
ylabel(haxes,'Integral breadth (10^-^1^0 m^-^1)','fontsize',14)
end
set(haxes,'fontsize',16)
grid(haxes,'on')

end

%%
function sr =inner_lsqcu(guess, K2, delK, lb, ub,type_sizestrain)


switch type_sizestrain
    case 'mwhA'
        qrange = lb(1):(ub(1)-lb(1))/8:ub(1);
        for jk=1:length(qrange)
            guess(1) = qrange(jk);
            [sr_(:,jk), resnorm(jk)] = lsqcurvefit(@MWHA, guess, K2, delK, lb, ub) ; 
        end
        sr= sr_(:,resnorm==min(resnorm));
    case 'mwhB'
        qrange = lb(1):(ub(1)-lb(1))/8:ub(1);
        for jk=1:length(qrange)
            guess(1) = qrange(jk);
            [sr_(:,jk), resnorm(jk)] = lsqcurvefit(@MWHB, guess, K2, delK, lb, ub) ; 
        end
        sr= sr_(:,resnorm==min(resnorm));
    case 'mwhC'
        qrange = lb(1):(ub(1)-lb(1))/8:ub(1);
        for jk=1:length(qrange)
            guess(1) = qrange(jk);
            [sr_(:,jk), resnorm(jk)] = lsqcurvefit(@MWHC, guess, K2, delK, lb, ub) ; 
        end
        sr= sr_(:,resnorm==min(resnorm));

end

end
%% 
function sr = inner_psrch(guess, K2, delK, lb, ub,type_sizestrain)
options = psoptimset('Display','iter','TolMesh',1e-15,...
                            'CompleteSearch','on','SearchMethod',@searchlhs);

switch type_sizestrain
    case 'mwhA'
        sr = patternsearch(@(guess)MWHA_psearch(guess,...
            K2,delK), guess,[],[],[],[], lb, ub,options) ; 

    case 'mwhB'
        sr = patternsearch(@(guess)MWHB_psearch(guess,K2,delK), ...
            guess,[],[],[],[], lb, ub) ; 

    case 'mwhC'
        sr = patternsearch(@(guess)MWHC_psearch(guess,K2,delK), ...
            guess,[],[],[],[], lb, ub) ;

end
end
%%
function sr = inner_genet(guess, K2, delK, lb, ub,type_sizestrain)

options = gaoptimset('Disp','iter','TolFun',1e-7);
     
switch type_sizestrain
    case 'mwhA'
        sr = ga(@(guess)MWHA_psearch(guess,K2,delK),...
            3,[],[],[],[], lb, ub,[],options) ;           
    case 'mwhB'
        sr = ga(@(guess)MWHB_psearch(guess,K2,delK),...
            3,[],[],[],[], lb, ub,[],options) ; 
    case 'mwhC'
        sr = ga(@(guess)MWHC_psearch(guess,K2,delK),...
            3,[],[],[],[], lb, ub,[],options) ; 

end
end
%%
function sr = inner_siman(guess, K2, delK, lb, ub,type_sizestrain)
options = saoptimset('Display','iter','TolFun',1e-7);
        
switch type_sizestrain
    case 'mwhA'
        sr = simulannealbnd(@(guess)MWHA_psearch(guess,K2,delK),...
            guess,lb,ub,options);
        
    case 'mwhB'
        sr = simulannealbnd(@(guess)MWHB_psearch(guess,K2,delK),...
            guess,lb,ub,options);
        
    case 'mwhC'
        sr = simulannealbnd(@(guess)MWHC_psearch(guess,K2,delK),...
            guess,lb,ub,options);

end

end
%%
    function FWc=MWHA(x, g2)
      q=x(1);
      sizee=x(2);
      strain=x(3);
      
      g = g2(1,:);
      H2 = g2(2,:);
      Aest = g2(3,1);    
      
      C = Aest*(1-q*H2);  
      FWc =  sizee + strain*g.*C.^0.5;
      if abs(imag(q))>0;FWc=FWc*1e5;end
      if abs(imag(sizee))>0;FWc=FWc*1e5;end
      if abs(imag(strain))>0;FWc=FWc*1e5;end
    end
    
    function FWc=MWHA_pl(x, g2)
      q=x(1);
      sizee=x(2);
      strain=x(3);
      pl=x(4);
      
      g = g2(1,:);
      H2 = g2(2,:);
      Aest = g2(3,1);
      alat = g2(3,2);
      omega = g2(4,:);
      
      C = Aest*(1-q*H2);  
      FWc =  sizee + 2.5*pl*(1/alat)*omega + strain*g.*C.^0.5;
      if abs(imag(q))>0;FWc=FWc*1e5;end
      if abs(imag(sizee))>0;FWc=FWc*1e5;end
      if abs(imag(strain))>0;FWc=FWc*1e5;end
    end
    
    function FWc=MWHB(x, g2)
      q=x(1);
      sizee=x(2);
      strain=x(3);
      
      g = g2(1,:);
      H2 = g2(2,:);
      Aest = g2(3,1);   
      
      C = Aest*(1-q*H2);  
      FWc =(  sizee^2 + strain^2*g.^2.*C  ).^0.5;
%       if abs(imag(q))>0;FWc=FWc*1e5;end
%       if abs(imag(sizee))>0;FWc=FWc*1e5;end
%       if abs(imag(strain))>0;FWc=FWc*1e5;end

        if sizee < 0
         FWc = 0*FWc; 
        end
    end
    
    function FWc=MWHC(x, g2)
      q=x(1);
      sizee=x(2);
      strain=x(3);
      
      g = g2(1,:);
      H2 = g2(2,:);
      Aest = g2(3,1);   
      
      C = Aest*(1-q*H2);  
      FWc =  sizee + strain*g.^2.*C  ;
      if abs(imag(q))>0;FWc=FWc*1e5;end
      if abs(imag(sizee))>0;FWc=FWc*1e5;end
      if abs(imag(strain))>0;FWc=FWc*1e5;end
    end
%%