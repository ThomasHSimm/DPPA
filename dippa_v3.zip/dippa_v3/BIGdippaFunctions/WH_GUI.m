function WH_GUI(FWq,inda,haxes)
% modq=get(handles.mwh_wh_b,'value');
% FWq=get(handles.FW_IB_b,'value');
% inda=get(handles.WHselected_l,'string');
% q=str2num(get(handles.WHq_t,'string'));

if nargin==0
    figure(1)
    haxes=gca;
    inda=['111';'200'; '220';'311';'222'];
    FWq=0;
    modq=1;
end
load([cd,'/0. variables/fit.mat'],'aa','aabcg')
load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
load([cd,'/0. variables/phases.mat'],'dsettings')

hold(haxes,'off')

index=num2str(dsettings(1).index);



if FWq==0
    if size(aa,1)==6
        aa(3,select)=0.5*(aa(3,select)+aa(5,select));
    end
        fw_r=(aa(3,select).^2-aa_I(3,1).^2).^.5;
        textFW='real FW';
else
    if size(IB_,1)~=0
        fw_r=IB_;
        textFW='real IB';
    else
         if size(aa,1)==6
            aa(3,select)=0.5*(aa(3,select)+aa(5,select));
         end
    
        fw_r=(aa(3,select).^2-aa_I(3,1).^2).^.5;
        textFW='real FW not IB';
    end
end

if modq==0
    plot(aa(1,select),fw_r,'o','markersize',5,'linewidth',5)
    title(['WH PLOT',textFW],'fontsize',20)
else
    
    q= 2;
    if strcmp(dsettings(1).cstruct(1:3),'HCP')==1
        q2=str2num(get(handles.q2_t,'string'));
        l=settings(1).index(select,3);
        xXx=(2/3)*((l./(aa(1,select)'*2.95)).^2);
        C=(1+q*xXx + q2*xXx.^2)'  ;  
    else
        H2=Hsq(dsettings(1,1).index(select,:));
        C=0.3*(1-q*H2);
    end
    texta=['MOD WH PLOT: ',textFW];
    
    
    plot(aa(1,select).^2.*C,fw_r,'om','markersize',5,'linewidth',5)
    title(texta,'fontsize',20)
end

end