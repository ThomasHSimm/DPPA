function startup_WHpref(WHpref_,nowttosee)
if nargin==0
    WHpref_ = 'Nickel'
end
if nargin==1
    %% When loading results
    WHpref = WHpref_;
    C0 = WHpref.chk0 ;
    qscrew = WHpref.q_ub ;
    qedge = WHpref.q_lb;
    HCPalloy = WHpref.HCPalloy;
    alloy = WHpref.alloy;
    
else
    %% preset values
    if strcmp(WHpref_,'Nickel')==1
        qscrew = 2.333; qedge = 1.515;
        C0screw = 0.289; C0edge = 0.279;
        C0 = 0.5 * ( C0screw + C0edge );
        HCPalloy ='No';
        alloy = WHpref_;
        M = 3;
        selected = 1:1:5;
        
    elseif strcmp(WHpref_,'Stainless Steel')==1
        qscrew = 2.470; qedge = 1.718;
        C0screw = 0.31; C0edge = 0.324;
        C0 = 0.5 * ( C0screw + C0edge );
        HCPalloy ='No';
        alloy = WHpref_;
        M = 3;
        selected = 1:1:5;
        
    elseif strcmp(WHpref_,'Titanium')==1
        qedge = [-1.5 , -2.5];
        qscrew = [1.5 , 1.5];
        C0 = 1;
        HCPalloy ='Yes';
        alloy = WHpref_; 
        M = 3;
        selected = 1:1:15;
        
    elseif strcmp(WHpref_,'Magnesium')==1
        qedge = [-1.5 , -2.5];
        qscrew = [1.5 , 1.5];
        C0 = 1;
        HCPalloy ='Yes';
        alloy = WHpref_;
        M = 3;
        selected = 1:1:15;
        
    elseif strcmp(WHpref_,'Zirconium')==1
        qedge = [-1.5 , -2.5];
        qscrew = [1.5 , 1.5];
        C0 = 1;
        HCPalloy ='Yes';
        alloy = WHpref_;  
        M = 3;
        selected = 1:1:15;
        
    end
end
%%
WHpref.boundary_size(1) = -1e-3; 
WHpref.boundary_size(2) = 3e-3;
WHpref.boundary_strain(1) = 0; 
WHpref.boundary_strain(2) = 1e-2;

%%
WHpref.chk0 = C0;
WHpref.M = M;
WHpref.q_ub = qscrew;
WHpref.q_lb = qedge;
WHpref.HCPalloy = HCPalloy;
WHpref.alloy = alloy;
WHpref.selected = selected;
WHpref.phaseno = 1;
WHpref.type_sizestrain = 'mwhA';

WHpref.type_fitalgor = 'lsqcu';

WHpref.type_FWorIB='FW';

setappdata(0,'WHpref',WHpref); 

end