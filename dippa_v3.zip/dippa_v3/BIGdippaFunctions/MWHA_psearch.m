function FWc=MWHA_psearch(x, g2, delK)
      q=x(1);
      sizee=x(2);
      strain=x(3);
      
      g = g2(1,:);
      H2 = g2(2,:);
      Aest = g2(3,1);    
      
      C = Aest*(1-q*H2);  
      FWc =  sizee + strain*g.*C.^0.5;
      if abs(imag(q))>0;FWc=FWc*1e5;end
      if abs(imag(sizee))>0;FWc=FWc*1e5;end
      if abs(imag(strain))>0;FWc=FWc*1e5;end
      
        FWc = sum(FWc-delK).^2;
        
    end