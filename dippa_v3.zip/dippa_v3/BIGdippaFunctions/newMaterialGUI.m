function varargout = newMaterialGUI(varargin)
% NEWMATERIALGUI MATLAB code for newMaterialGUI.fig
%      NEWMATERIALGUI, by itself, creates a new NEWMATERIALGUI or raises the existing
%      singleton*.
%
%      H = NEWMATERIALGUI returns the handle to a new NEWMATERIALGUI or the handle to
%      the existing singleton*.
%
%      NEWMATERIALGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in NEWMATERIALGUI.M with the given input arguments.
%
%      NEWMATERIALGUI('Property','Value',...) creates a new NEWMATERIALGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before newMaterialGUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to newMaterialGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help newMaterialGUI

% Last Modified by GUIDE v2.5 06-Aug-2017 21:20:32

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @newMaterialGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @newMaterialGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before newMaterialGUI is made visible.
function newMaterialGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to newMaterialGUI (see VARARGIN)

% Choose default command line output for newMaterialGUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes newMaterialGUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);

dsettings(1).id = 'Material1';
dsettings(1).name='1';
dsettings(1).cstruct='FCC';
dsettings(1).lat1=3.6;
dsettings(1).lat2=0;
dsettings(1).index=[1 1 1;2 0 0;2 2 0; 3 1 1; 2 2 2];
dsettings(1).d=dspacing(dsettings(1).index, 'cub', 1,dsettings(1).lat1, dsettings(1).lat2);

save([cd,'/0. variables/phasesTemp.mat'],'dsettings')


% --- Outputs from this function are returned to the command line.
function varargout = newMaterialGUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function materialName_t_Callback(hObject, eventdata, handles)
% hObject    handle to materialName_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of materialName_t as text
%        str2double(get(hObject,'String')) returns contents of materialName_t as a double

load([cd,'/0. variables/phasesTemp.mat'],'dsettings')
dsettings(1).id = get(hObject,'String');
save([cd,'/0. variables/phasesTemp.mat'],'dsettings')

% --- Executes during object creation, after setting all properties.
function materialName_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to materialName_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in numberPhases_l.
function numberPhases_l_Callback(hObject, eventdata, handles)
% hObject    handle to numberPhases_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns numberPhases_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from numberPhases_l

number = get(hObject,'Value');
for n=1:number
   nums{n}=n; 
end
set(handles.nameofphases_l,'value',1)
set(handles.nameofphases_l,'string',nums)

if number > 1
    load([cd,'/0. variables/phasesTemp.mat'],'dsettings')
    dsettings=dsettings(1);
    for n=2:number
        dsettings(n)=dsettings(1);
        dsettings(n).name=num2str(n);
        dsettings(n).index=[0 0 0];
        dsettings(n).xp=1;
    end
save([cd,'/0. variables/phasesTemp.mat'],'dsettings')
end
% --- Executes during object creation, after setting all properties.
function numberPhases_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to numberPhases_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in nameofphases_l.
function nameofphases_l_Callback(hObject, eventdata, handles)
% hObject    handle to nameofphases_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns nameofphases_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from nameofphases_l

load([cd,'/0. variables/phasesTemp.mat'],'dsettings')
phaseno = get(handles.nameofphases_l,'value');

set(handles.nameofPhase_t,'string',dsettings(phaseno).name);
set(handles.lat1_t,'string',num2str(dsettings(phaseno).lat1));
set(handles.lat2_t,'string',num2str(dsettings(phaseno).lat2));
set(handles.indexs_l,'value',1);
set(handles.indexs_l,'string',num2str(dsettings(phaseno).index));
symm = dsettings(phaseno).cstruct;
switch symm
    case 'FCC'
        set(handles.crystaltype_l,'value',1)
    case 'BCC'
        set(handles.crystaltype_l,'value',2)
    case 'HCP'
        set(handles.crystaltype_l,'value',3)
end

% --- Executes during object creation, after setting all properties.
function nameofphases_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to nameofphases_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




function nameofPhase_t_Callback(hObject, eventdata, handles)
% hObject    handle to nameofPhase_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of nameofPhase_t as text
%        str2double(get(hObject,'String')) returns contents of nameofPhase_t as a double

str = get(hObject,'String');
phaseno = get(handles.nameofphases_l,'value');
contents = get(handles.nameofphases_l,'String');
contents{phaseno}=str;
set(handles.nameofphases_l,'String',contents);

load([cd,'/0. variables/phasesTemp.mat'],'dsettings')
dsettings(phaseno).name = str;
save([cd,'/0. variables/phasesTemp.mat'],'dsettings')


% --- Executes during object creation, after setting all properties.
function nameofPhase_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to nameofPhase_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in crystaltype_l.
function crystaltype_l_Callback(hObject, eventdata, handles)
% hObject    handle to crystaltype_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns crystaltype_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from crystaltype_l

contents = cellstr(get(hObject,'String'));
symm = contents{get(hObject,'Value')};
phaseno = get(handles.nameofphases_l,'value');

load([cd,'/0. variables/phasesTemp.mat'],'dsettings')
dsettings(phaseno).cstruct = symm;
save([cd,'/0. variables/phasesTemp.mat'],'dsettings')

krange(1)=str2double(get(handles.mink_t,'string'));
krange(2)=str2double(get(handles.maxk_t,'string'));
inda = create_index(symm,krange,dsettings(phaseno).lat1,dsettings(phaseno).lat2);

set(handles.indexs_l,'value',1);
set(handles.indexs_l,'string',num2str(inda));

% --- Executes during object creation, after setting all properties.
function crystaltype_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to crystaltype_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function lat1_t_Callback(hObject, eventdata, handles)
% hObject    handle to lat1_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of lat1_t as text
%        str2double(get(hObject,'String')) returns contents of lat1_t as a double

lat1 = str2double(get(hObject,'String'));
phaseno = get(handles.nameofphases_l,'value');

load([cd,'/0. variables/phasesTemp.mat'],'dsettings')
dsettings(phaseno).lat1 = lat1;
save([cd,'/0. variables/phasesTemp.mat'],'dsettings')


krange(1)=str2double(get(handles.mink_t,'string'));
krange(2)=str2double(get(handles.maxk_t,'string'));
inda = create_index(dsettings(phaseno).cstruct,krange,dsettings(phaseno).lat1,dsettings(phaseno).lat2);

set(handles.indexs_l,'value',1);
set(handles.indexs_l,'string',num2str(inda));

% --- Executes during object creation, after setting all properties.
function lat1_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lat1_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function lat2_t_Callback(hObject, eventdata, handles)
% hObject    handle to lat2_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of lat2_t as text
%        str2double(get(hObject,'String')) returns contents of lat2_t as a double

lat2 = str2double(get(hObject,'String'));
phaseno = get(handles.nameofphases_l,'value');

load([cd,'/0. variables/phasesTemp.mat'],'dsettings')
dsettings(phaseno).lat2 = lat2;
save([cd,'/0. variables/phasesTemp.mat'],'dsettings')

krange(1)=str2double(get(handles.mink_t,'string'));
krange(2)=str2double(get(handles.maxk_t,'string'));
inda = create_index(dsettings(phaseno).cstruct,krange,dsettings(phaseno).lat1,dsettings(phaseno).lat2);

set(handles.indexs_l,'value',1);
set(handles.indexs_l,'string',num2str(inda));

% --- Executes during object creation, after setting all properties.
function lat2_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lat2_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in indexs_l.
function indexs_l_Callback(hObject, eventdata, handles)
% hObject    handle to indexs_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns indexs_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from indexs_l


% --- Executes during object creation, after setting all properties.
function indexs_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to indexs_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function mink_t_Callback(hObject, eventdata, handles)
% hObject    handle to mink_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of mink_t as text
%        str2double(get(hObject,'String')) returns contents of mink_t as a double

phaseno = get(handles.nameofphases_l,'value');
load([cd,'/0. variables/phasesTemp.mat'],'dsettings')

krange(1)=str2double(get(handles.mink_t,'string'));
krange(2)=str2double(get(handles.maxk_t,'string'));
inda = create_index(dsettings(phaseno).cstruct,krange,dsettings(phaseno).lat1,dsettings(phaseno).lat2);

set(handles.indexs_l,'value',1);
set(handles.indexs_l,'string',num2str(inda));

% --- Executes during object creation, after setting all properties.
function mink_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to mink_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function maxk_t_Callback(hObject, eventdata, handles)
% hObject    handle to maxk_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of maxk_t as text
%        str2double(get(hObject,'String')) returns contents of maxk_t as a double
phaseno = get(handles.nameofphases_l,'value');
load([cd,'/0. variables/phasesTemp.mat'],'dsettings')

krange(1)=str2double(get(handles.mink_t,'string'));
krange(2)=str2double(get(handles.maxk_t,'string'));
inda = create_index(dsettings(phaseno).cstruct,krange,dsettings(phaseno).lat1,dsettings(phaseno).lat2);

set(handles.indexs_l,'value',1);
set(handles.indexs_l,'string',num2str(inda));

% --- Executes during object creation, after setting all properties.
function maxk_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to maxk_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in loadmaterial_b.
function loadmaterial_b_Callback(hObject, eventdata, handles)
% hObject    handle to loadmaterial_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in loadphase_b.
function loadphase_b_Callback(hObject, eventdata, handles)
% hObject    handle to loadphase_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

phase_folder= [cd,'\0. variables\_phases\'];
fnom = dir(phase_folder);
h=1;
for n=1:length(fnom)
    if fnom(n).name(1)~='.'
       fnoms{h}=fnom(n).name;
        h=h+1;
    end
end
choi = menu('Choose phase to load: ',fnoms);
load([phase_folder,fnoms{choi}],'dphase')

set(handles.lat1_t,'string',dphase.lat1);
set(handles.lat2_t,'string',dphase.lat2);
cstruct = dphase.cstruct;
switch cstruct
    case 'FCC'
        set(handles.crystaltype_l,'value',1)
    case 'BCC'
        set(handles.crystaltype_l,'value',2)
    case 'HCP'
        set(handles.crystaltype_l,'value',3)
end
contents = get(handles.nameofphases_l,'string');phaseno=get(handles.nameofphases_l,'value');
contents{phaseno}=dphase.name;
set(handles.nameofphases_l,'string',cellstr(contents))
set(handles.nameofPhase_t,'string',dphase.name)

load([cd,'/0. variables/phasesTemp.mat'],'dsettings')
dsettings(phaseno).name=dphase.name;
dsettings(phaseno).lat1=dphase.lat1;
dsettings(phaseno).lat2=dphase.lat2;
dsettings(phaseno).cstruct=dphase.cstruct;
save([cd,'/0. variables/phasesTemp.mat'],'dsettings')





% --- Executes on button press in saveMaterial_b.
function saveMaterial_b_Callback(hObject, eventdata, handles)
% hObject    handle to saveMaterial_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

loadphase_b_Callback(hObject, eventdata, handles)

% --- Executes on button press in savePhase_b.
function savePhase_b_Callback(hObject, eventdata, handles)
% hObject    handle to savePhase_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

phase_folder= [cd,'\0. variables\_phases\'];
dphase.lat1 = str2double(get(handles.lat1_t,'string'));
dphase.lat2 = str2double(get(handles.lat2_t,'string'));

contents = get(handles.crystaltype_l,'string');
phaseno=get(handles.crystaltype_l,'value');
dphase.cstruct = contents{phaseno} ;

dphase.name = get(handles.nameofPhase_t,'string');

save([phase_folder,dphase.name],'dphase')

% --- Executes on button press in done_b.
function done_b_Callback(hObject, eventdata, handles)
% hObject    handle to done_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

mnu= menu({'This will create a new BIGdippa materials file that deletes the existing one';...
    'You can now return to BIGdippa';
    'Proceed?'},'Go','Wait a minute');
if mnu==1
    load([cd,'/0. variables/phasesTemp.mat'],'dsettings')
    save([cd,'/0. variables/phases.mat'],'dsettings')
end

% --- Executes on button press in addPhase_b.
function addPhase_b_Callback(hObject, eventdata, handles)
% hObject    handle to addPhase_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

phaseno = get(handles.nameofphases_l,'value');
load([cd,'/0. variables/phasesTemp.mat'],'dsettings')

str = get(handles.nameofPhase_t,'String');
phaseno = get(handles.nameofphases_l,'value');
contents = get(handles.nameofphases_l,'String');
contents{phaseno}=str;
set(handles.nameofphases_l,'String',contents);


krange(1)=str2double(get(handles.mink_t,'string'));
krange(2)=str2double(get(handles.maxk_t,'string'));
inda = create_index(dsettings(phaseno).cstruct,krange,dsettings(phaseno).lat1,dsettings(phaseno).lat2);

dsettings(phaseno).index = inda;
dsettings(phaseno).d=dspacing(dsettings(phaseno).index, dsettings(phaseno).cstruct , 1,dsettings(phaseno).lat1, dsettings(phaseno).lat2);

save([cd,'/0. variables/phasesTemp.mat'],'dsettings')

contents = cellstr(get(handles.phasesadded_l,'String'));
contents{phaseno}= dsettings(phaseno).name;
set(handles.phasesadded_l,'String',contents)

set(handles.indexs_l,'value',1);
set(handles.indexs_l,'string',num2str(inda));

% --- Executes on selection change in phasesadded_l.
function phasesadded_l_Callback(hObject, eventdata, handles)
% hObject    handle to phasesadded_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns phasesadded_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from phasesadded_l


% --- Executes during object creation, after setting all properties.
function phasesadded_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to phasesadded_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
