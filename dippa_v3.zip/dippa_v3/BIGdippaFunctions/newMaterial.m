function newMaterial

    str1=input('Enter name of material    ','s');
    dsettings(1).id=str1;
    num=input('Enter number of different crystal phases       ');
    for n=1:num
        str1=input(['Enter name of phase ',num2str(n),'   '],'s');
        dsettings(n).name=str1;
        num2=input('Enter crystal structure, 1-fcc, 2-bcc, 3-hexagonal   ');
        symms = {'FCC';'BCC';'HCP'};
        dsettings(n).cstruct=symms{num2};
        str1=input('Enter lattice parameter   ');
        dsettings(n).lat1=str1;
        
        num3=input('Enter indices of peaks (e.g. [1 1 1;2 0 0] etc use function "create_index") ');
        dsettings(n).index=num3;
        if num2==3
            str1=input('Enter 2nd lattice parameter (c)   ');
            dsettings(n).lat2=str1;
            dsettings(n).d=dspacing(dsettings(n).index, 'hex', 1,dsettings(n).lat1, dsettings(n).lat2);
        else
            dsettings(n).lat2=0;
            dsettings(n).d=dspacing(dsettings(n).index, 'cub', 1,dsettings(n).lat1, dsettings(n).lat2);
        end
    end
    yorno=input('Is this okay?','s');
    if yorno(1)=='y' || 'Y'
    save([cd,'/0. variables/phases.mat'],'dsettings')
    end



