function OUT=tsinterpl(data,wavelen)
%%%TSimm 07
%%%turns theta values to K-values by interpolation
% close all

I(:,:)=data(:,2);

theta1=data(1,1);
theta2=data(end,1);

theta(:,:)=data(:,1);
len=length(theta);
K(:,:)=2*sin(2*pi*(1/360)*0.5*theta)/wavelen;

if K(1)>K(end)
   
   dd = [K,I];
   dd=sortrows(dd,1);
   K=dd(:,1);I=dd(:,2);
end

Kincr=.5e-04;

rk=rem(K(1),Kincr);
K1=K(1)-rk;K1=K1/Kincr;
K1=int16(K1);K1=double(K1)*Kincr;
rk=rem(K(end),Kincr);
Kend=K(end)-rk;


cc(:,:)=K1:Kincr:Kend;

cc=cc';

IK=interp1(K(:,1),I(:,1),cc(:,1),'PCHIP');

OUT=[cc IK];

end