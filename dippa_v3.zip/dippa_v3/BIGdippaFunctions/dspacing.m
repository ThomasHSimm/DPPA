function d=dspacing(dp, sym, lambda,lat1, lat2)

%%  find d-spacing values given symmetry and hkl values
% eg for hcp--> dp=[0 0 2;1 0 0;1 0 1;1 0 2;1 1 0;1 0 3;0 0 4;1 1 2;2 0 0;2 0 1;1 0 4] 
% mg--> lat1=3.210; lat2=1.624*3.21;lambda=0.179 (Co)
lenindex=size(dp,1);

if length(dp)==1
   if strcmp(sym, 'FCC')==1 || strcmp(sym, 'BCC')==1
       kmax = dp;
       n=1; 
       for i=0:10
           for j=0:10
               for k=1:10
                   ind = [i j k];
                   ind =sort(ind,'descend');
                   
                   if strcmp(sym, 'FCC')==1
                       rema = rem(ind,2);
                       if sum(rema)==3 | sum(rema)==0
                           inda(n,:)=ind;
                           n=n+1;
                       end
                   elseif strcmp(sym, 'BCC')==1
                       rema = rem(sum(ind),2);
                       if sum(rema)==0
                           inda(n,:)=ind;
                           n=n+1;
                       end
                   end
               end
           end
       end
       inda=unique(inda,'rows');
       k=zeros(1,length(inda));
       for n=1:length(inda)
            k(n)=1./(lat1/(sum(inda(n,:).^2)).^0.5);
       end
       
       indad=[inda, k'];
       dp = sortrows(indad,4);
       lenindex=size(dp,1);
       
       dp=dp(dp(:,4)<kmax, 1:3);
       clear k
    end
end


if strcmp(sym, 'cub')==1
    crystalsymm=2;
elseif strcmp(sym, 'FCC')==1
    crystalsymm=2;
elseif strcmp(sym, 'BCC')==1
    crystalsymm=2;
elseif strcmp(sym, 'tet')==1
    crystalsymm=3;
elseif strcmp(sym, 'hex')==1
    crystalsym=4;
elseif strcmp(sym, 'HCP')==1
    crystalsymm=4;
end

switch crystalsymm
    case 1
%         d=lambda./(2*sin(peaks*pi/360));
    case 2%cubic
        for n=1:lenindex;
            lat1/(sum(dp(n,:).^2)).^0.5;
            d(n)=lat1/(sum(dp(n,:).^2)).^0.5;
        end
        peaks=180*2*asin(lambda./(2*d))/pi;
    case 3
        for n=1:lenindex;
            d(n)=1/( ( dp(n,1)^2 + dp(n,2)^2 )/lat1^2 + dp(n,3)^2/lat2^2 )^0.5;
        end
        peaks=180*2*asin(lambda./(2*d))/pi;
    case 4
        for n=1:lenindex;
            d(n)=1/( (4/3)*(dp(n,1)^2 + dp(n,1)*dp(n,2) + dp(n,2)^2)/lat1^2  +  dp(n,3)^2/lat2^2 )^0.5;
        end
        peaks=180*2*asin(lambda./(2*d))/pi;
        
end
k=1./d;
