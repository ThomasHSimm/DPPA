function [fsum  ]=pk_alpha_asymm(x,lambda)
%% fitting function for asymmetric peaks with alpha1 and alpha2
%% THS 2016 dppa

                    %%%%lambda or 'a' gives the voight parameters lam(1:4)
                    %%%%f gives the intensities from the voight
% global   tube alpha2
alpha2 = getDPPApref('alpha2');
tube = getDPPApref('tube');
tube=tube(1:2);

% tube='Co';
if strcmp(tube,'Cu')==1
    alphadiff_lam=0.0038;
    wavelen=(1.54056+	1.54439)/2;
    alphadiff=lambda(1)*alphadiff_lam/wavelen;
    %%1.54056	1.54439  for Cu
elseif  strcmp(tube,'Co')==1
    LabdaAlpha1=  1.78897;
    LabdaAlpha2=  1.79285;
    wavelen=(LabdaAlpha1+LabdaAlpha2)/2;
    alphadiff_lam=abs(LabdaAlpha2-LabdaAlpha1);
    alphadiff=lambda(1)*alphadiff_lam/wavelen;    
elseif  tube=='Fe'
    LabdaAlpha1=  1.93604;%1.78897;
    LabdaAlpha2=  1.93998;%1.79285;
%     LabdaAlphaS=  1.78897-0.0075;
    wavelen=(LabdaAlpha1+LabdaAlpha2)/2;
    alphadiff_lam=(LabdaAlpha2-LabdaAlpha1);
%     alphadiff=1.78901-1.79290;
    alphadiff=lambda(1)*alphadiff_lam/wavelen;
end


if alpha2==0%alpha 2 is present
	[f ]=pk_voigt2asymm(x,lambda);
    lambda2=lambda;
    lambda2(1)=lambda(1)+alphadiff;
    lambda2(2)=0.5*lambda(2);
    [f2 ]=pk_voigt2asymm(x,lambda2);
	fsum=f+f2; 
else
    [fsum ]=pk_voigt2asymm(x,lambda);
end
        
end       
        
        
        
%%%lam(1) ==x0
%%%lam(2) ==PHI0  intensity
%%%lam(3) ==FWHM
%%%lam(4) ==neta (0->1 gauss->lorentz)
%%%%f intensity
%%%%x twotheta values
             
