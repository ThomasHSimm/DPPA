function [sr, WHres, YY, rho]= dippa_fitWH_HCP(guess, haxes, selected, delK, K )
if nargin == 2
    
    %% values for fit
    load([cd,'/0. variables/phases.mat'],'dsettings')
    load([cd,'/0. variables/fit.mat'],'aa','aabcg')
    load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
    
    
    WHpref= getappdata(0,'WHpref');
    phaseno = WHpref.phaseno;
    selected = WHpref.selected;
    type_FWorIB = WHpref.type_FWorIB;
    
    [delK, K] = getFW_IB(type_FWorIB,selected,phaseno);
    
    index=dsettings(phaseno).index(:,:);
    l=index(selected,3)';
    xXx=(2/3)*((l./(K*2.95)).^2);
        
    K2=[K;xXx];
    
    
    %get rid of nan values from guess
    for i = 1:3
        switch i
            case 1
                if isnan(guess(1))
                    guess(i)= 0;
                end
            case 2
                if isnan(guess(2))
                    guess(i)= 200000;
                end                
            case 3
                if isnan(guess(3))
                    guess(i)= 1e-3;
                end    
            case 4
                if isnan(guess(4))
                    guess(i)= 0;
                end
        end
    end
end

%%
WHpref= getappdata(0,'WHpref');

type_sizestrain = WHpref.type_sizestrain;
qlb = WHpref.q_lb; qub =  WHpref.q_ub;
Aest = WHpref.chk0;
M = WHpref.M;

sizelb = WHpref.boundary_size(1); 
sizeub = WHpref.boundary_size(2);
strainlb = WHpref.boundary_strain(1); 
strainub = WHpref.boundary_strain(2);

lb=[qlb(1) ,sizelb , strainlb  , qlb(2)  ];
ub=[qub(1) ,sizeub ,  strainub  , qub(2)  ];
K2(3,1)= Aest;

switch type_sizestrain
    case 'mwhA'
sr = lsqcurvefit(@MWHA, guess, K2, delK, lb, ub) ; 
sr = lsqcurvefit(@MWHA, sr, K2, delK, lb, ub) ;
YY = MWHA(sr, K2);
    case 'mwhB'
sr = lsqcurvefit(@MWHB, guess, K2, delK, lb, ub) ; 
sr = lsqcurvefit(@MWHB, sr, K2, delK, lb, ub) ;
YY = MWHB(sr, K2);

    case 'mwhC'
sr = lsqcurvefit(@MWHC, guess, K2, delK, lb, ub) ; 
sr = lsqcurvefit(@MWHC, sr, K2, delK, lb, ub) ;
YY = MWHC(sr, K2);

end

%% get rho

%% strain_M*g.^2.*C  strain term MWH
strain_M = sr(3);
lat=dsettings(1).lat1;
b = lat/2^0.5 ; %lat ni
fm2 = (pi * M^2 * b^2 /2)
a0=-0.173; b0=7.797; c0 =-4.818; d0=0.911;
fm2 = b^2*( a0 * log(M+1) + b0 * (log(M+1))^2 + ...
c0 * (log(M+1))^3 + d0 * (log(M+1))^4 )

q1=sr(1); q2=sr(4);

switch type_sizestrain
    case 'mwhA'


rho = 1e4 * ( strain_M  / sqrt(fm2) ).^2;

    case 'mwhB'

%FWc =(  sizee^2 + strain^2*g.^2.*C  ).^0.5;

rho = 1e4 *  ( strain_M  / sqrt(fm2) ).^2;

    case 'mwhC'

rho = 1e4 *  ( strain_M  / sqrt(fm2) ).^2;
end
%%
tizr = WHpref.alloy;
[indiv_comb, Burgcomb]=contrastHCP(q1 ,q2,tizr);
            
rho=rho/Burgcomb(4);
Aest = Aest * Burgcomb(4); 

%% ends
sizeA=sr(2);strain=sr(3);
[~, X, FWfit_line, X_line]= getWH_HCP(sr, selected);

WHres.HCP_CBadj = Burgcomb;
WHres.HCP_indivs = indiv_comb;
WHres.sizeA = sizeA;
WHres.strain = strain;
WHres.rho = rho;
WHres.Aest = Aest;
WHres.q = [q1 , q2];


plot(X, delK,'parent',haxes,'marker','o',...
    'linestyle','none','markersize',15,'linewidth',2)

hold(haxes,'on')

plot(X_line,FWfit_line,'color','r',...
    'markersize',15,'linewidth',2,'parent',haxes)

xlabel(haxes,'C^0^.^5/d (10^-^1^0m)','fontsize',14)
ylabel(haxes,'Full-width (10^-^1^0m)','fontsize',14)
set(haxes,'fontsize',16)
grid(haxes,'on')

%%
  
end
    
%%    
function FWc=MWHA(x, g2)
      q1=x(1);
      size=x(2);
      strain=x(3);
      q2=x(4);
      
      g = g2(1,:);
      xXx = g2(2,:);
      Aest = g2(3,1);
      
      C=(1+q1*xXx + q2*xXx.^2)  ;  
      FWc =  size + strain*g.*C.^0.5;
%       FWc=FWc';
      
      if min(C)<0
          vall=find(C<0);
          FWc(vall)=FWc(vall)*1e5;
          
      end
      if max(abs(imag(x)))>0
          FWc=FWc*inf;
      end
      
end
%%   
function FWc=MWHB(x, g2)
      q1=x(1);
      size=x(2);
      strain=x(3);
      q2=x(4);
      
      g = g2(1,:);
      xXx = g2(2,:);
      Aest = g2(3,1);
      
      C=(1+q1*xXx + q2*xXx.^2)  ;  
  
      FWc =(  size^2 + strain^2*g.^2.*C  ).^0.5;
%       FWc=FWc';
      if min(C)<0
          vall=find(C<0);
          FWc(vall)=FWc(vall)*1e5;          
      end
      if max(abs(imag(x)))>0
          FWc=FWc*inf;
      end
      
end
%%    
    
function FWc=MWHC(x, g2)
      q1=x(1);
      size=x(2);
      strain=x(3);%%slight diff from A
      q2=x(4);
      
      g = g2(1,:);
      xXx = g2(2,:);
      Aest = g2(3,1)
      
      C=(1+q1*xXx + q2*xXx.^2)  ;  
        
      FWc =  size + strain*g.^2.*C  ;
%       FWc=FWc';
      if min(C)<0
          vall=C<0;
          FWc(vall)=FWc(vall)*1e55;
          
      end
      if max(abs(imag(x)))>0
          FWc=FWc*inf;
      end
      
end
%%