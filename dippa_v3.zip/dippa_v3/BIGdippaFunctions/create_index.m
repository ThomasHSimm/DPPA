function inda = create_index(sym,krange,lat1,lat2)
if nargin==0
    sym='FCC';
    krange=[0 1.5];
    lat1 = 3.6;
%     lat1=2.9;
    lat2=0;
elseif nargin==1
    sym=sym(1:3);
    switch sym
        case 'FCC'
            krange=[0 1.5];
            lat1 = 3.6;lat1=2.9;
            lat2=0; 
        case 'BCC'
            krange=[0 1.5];
            lat1=2.9;
            lat2=0; 
        case 'HCP'
            krange=[0 1.5];
            lat1=2.92;
            lat2=4.67;
    end
elseif nargin==3
    lat2=0;
end
%% BCC
if strcmp(sym,'BCC')
    %sum to even
    nn=1;
   for i=0:10
       for j=0:10
           for k=0:10
               
               suma=i+j+k;
               iseven = rem(suma,2);
               if suma~=0 && iseven == 0  
                    inda(nn,:) = sort([i, j, k],'descend');
                    nn=nn+1;
               end
               
           end
       end
   end
   inda = unique(inda,'rows');


%% FCC
elseif strcmp(sym,'FCC')
%    111, 200, 220, 311, 222
% all odd or all even
nn=1;
   for i=0:10
       for j=0:10
           for k=0:10
               
               iseven = rem(i,2) + rem(j,2) + rem(k,2);
               suma=i+j+k;
               if suma~=0 && iseven == 0 || iseven == 3 
                    inda(nn,:) = sort([i, j, k],'descend');
                    nn=nn+1;
               end
               
           end
       end
   end
   inda = unique(inda,'rows');
   
%% HCP
elseif strcmp(sym,'HCP')
    inda=[0,1,0;
        0,0,2;
        1,0,1;
        1,0,2;
        1,1,0;
        1,0,3;
        2,0,0;
        1,1,2;
        2,0,1;
        0,0,4;
        2,0,2;
        1,0,4;
        2,0,3;
        1,2,0;
        1,2,1;
        1,1,4;
        1,2,2;
        1,0,5;
        2,0,4;
        3,0,0;
        2,1,3;
        3,0,2;
        0,0,6;
        2,0,5;
        1,0,6;
        1,2,4;
        2,2,0];
    
end
%%

k=1./dspacing(inda, sym, 1,lat1, lat2);

usse =k>krange(1) & k<krange(2);
inda = inda(usse,:);
end