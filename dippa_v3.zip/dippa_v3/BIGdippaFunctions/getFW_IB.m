function [delK, K] = getFW_IB(FWtype,selected,phaseno)
%%
load([cd,'/0. variables/fit.mat'],'aa','aabcg')
load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
load([cd,'/0. variables/phases.mat'],'dsettings')

if nargin==2
    phaseno=1;
end

if phaseno==1
        aa = aa(:,selected);
    elseif phaseno==2
        no_of1 = size(dsettings(1).index,1);
        aa = aa(:,selected + no_of1);
    elseif phaseno>2
       menu('not supported, max no of phases is 2','ok'); 
end
    
K=aa(1,:);


%%
switch FWtype
    
    case 'FW'
        if size(aa,1)==4
            delK_R = aa(3,:) ;
        else
            delK_R = 0.5* (aa(3,:) +...
                    aa(5,:) );
        end
        
        g_(:,1)=aa(1,:);
        g_I(:,1)=aa_I(1,:);
        %% find position of instrumental
        posI=zeros(1,length(selected));
        for ii=1:length(g_)
           posI(ii) = find( abs(g_(ii) - g_I) == min( abs(g_(ii) - g_I) ) );
        end
            %   get fw normaliseif asymmetric    
        if size(aa_I,1)==4
            delK_I = aa_I(3,posI) ;
        else
            delK_I = 0.5* (aa_I(3,posI) +...
                    aa_I(5,posI) );
        end
        
        delK = delK_R - delK_I;
                
    case 'IB'
        if size(aa,1)==4
            fw = aa(3,:) ;
            neta = aa(4,:);
        else
            fw = 0.5* (aa(3,:) +...
                    aa(5,:) );
            neta = 0.5* (aa(4,:) +...
                    aa(6,:) );
        end
        delK_R =0.5*fw(:,:).*...
        (pi*neta(:,:)+(1-neta(:,:))*sqrt(pi/log(2)));
        
        g_(:,1)=aa(1,:);
        g_I(:,1)=aa_I(1,:);
        %% find position of instrumental
        posI=zeros(1,length(selected));
        for ii=1:length(g_)
           posI(ii) = find( abs(g_(ii) - g_I) == min( abs(g_(ii) - g_I) ) );
        end
            %   get fw normaliseif asymmetric    
        if size(aa_I,1)==4
            fw_I = aa_I(3,posI) ;
            neta_I = aa_I(4,posI) ;
        else
            fw_I = 0.5* (aa_I(3,posI) +...
                    aa_I(5,posI) );
            neta_I = 0.5* (aa_I(4,posI) +...
                    aa_I(6,posI) );
        end
        
        delK_I =0.5*fw_I(:,:).*...
        (pi*neta_I(:,:)+(1-neta_I(:,:))*sqrt(pi/log(2)));
        
        delK = delK_R - delK_I;        
        
    case 'IBdata'
        


end