function startup_WH

WHpref.q_lb = 1.5;
WHpref.q_ub = 2.5;
WHpref.C0 = 0.29;
WHpref.M = 3;
WHpref.boundary_size = [ -1e-1 1e7];
WHpref.boundary_strain = [ 0 15];  
WHpref.type_sizestrain = 'mwhA';
WHpref.selected = [1 2 3 4 5];
WHpref.phaseno = 1;
WHpref.HCPalloy = HCPalloy; 

setappdata(0,'WHpref',WHpref)


end