function convertbattofit
% noma='batchbatchB2.mat'
% load(['D:\MATLAB\_THS\DPPAv2\4. RES\',noma])
% load('RT stress-strain','stress','strain')
noma = 'batchJ20_fit'
load('D:\MATLAB\_THS\DPPAv2\3. fit_data\batchJ20.mat')
% maxstrain =find(strain==max(strain));
% strain= strain(1:maxstrain);
val=[0 30 60 90 75 45 15]

for n=1:length(batcha)
   fita(n).data_I = batcha(1).data_I;
   fita(n).aa_I = batcha(1).aa_I;
   fita(n).aabcg_I = batcha(1).aabcg_I;
   
   fita(n).data = batcha(n).data;
   fita(n).aa = batcha(n).aa;
   fita(n).aabcg = batcha(n).aabcg;
   
   fita(n).DPPApref = batcha(1).DPPApref; 
   fita(n).dsettings = batcha(1).dsettings;
   
   fita(n).val = val(n);
   
end

save(['D:\MATLAB\_THS\DPPAv2\3. fit_data\',noma])
end