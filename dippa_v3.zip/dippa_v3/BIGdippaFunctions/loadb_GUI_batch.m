function outs = loadb_GUI_batch(handles, file, path, dataorInstr,krange,id,outs)
%% load data files for dippa
if nargin==4
    krange=[0 100];
    id='';
end
mnu = 1;%menu('Choose how to load data:','from file type','Matlabs uiimport wizard');

if exist('outs','var')==1
    outs = inner(handles, mnu, file, path, dataorInstr,krange,id,outs);
else
    outs = inner(handles, mnu, file, path, dataorInstr,krange,id);
end

end

function outs = inner(handles,mnu, file, path,  dataorInstr, krange,identa,outs)
if nargin==8
   wavelen=outs.wavelen;
   valCol=outs.valCol;
   dtype=outs.dtype; 
   wav=4;
end
haxes = handles.axes1;
if mnu==1 % from filetype
    %normalise data
    data=[];
    %find file location

    %% for udfs
    if strcmp(file(end-2:end),'udf')  || strcmp(file(end-2:end),'UDF')
        data = importUDF(path,file,handles);
%% if an ascii file        
    elseif strcmp(file(end-2:end),'asc')  || strcmp(file(end-2:end),'ASC')
        data = importascii(path,file,handles);
    elseif strcmp(file(end-2:end),'txt') 
        data = importENGINXtxt(path,file,handles);
    else
        %% not a udf or ascii
        if exist('outs','var')==0
            wavelen=menu('Enter Wavelength in A:   ','Copper with alpha2','Cobalt with alpha2','Iron with alpha2','(without alpha2) Enter value in Armstrongs:     ');
            wav=4;
        end
        
        switch wav
            case 1
                wavelen=0.5*(1.54056+1.54439);%%
                tube='Cu';alpha2=0;
                set(handles.alpha2_b,'value',1);
            case 2
                wavelen= 0.5*(1.78897+ 1.79285);%%in Armstrongs
                tube='Co';alpha2=0;
                set(handles.alpha2_b,'value',1);
           case 3
                wavelen= 0.5*(1.93604+ 1.93998);%%in Armstrongs
                tube='Fe';alpha2=0;
                set(handles.alpha2_b,'value',1);
            case 4
                if exist('outs','var')==0
                    wavelen= input('enter wavelength in A:  ');
                                 
                end
                set(handles.alpha2_b,'value',0);
                alpha2=1;
                tube='No';
        end

        %update prefs
        setDPPApref('alpha2',alpha2)
        setDPPApref('tube',tube)
        setDPPApref('wavelen',wavelen)
    %     
        if file(end-2:end)=='.xy'
            da=importdata([path,file]);
            data=da.data;
        else
            data=load([path,file]);
        end
        if exist('outs','var')==0
            if size(data,2)>2
                valCol=input(['Select column(s) to use, of ',num2str(size(data,2)),'    ']);
                data(:,2)=sum(data(:,valCol),2)';data=data(:,1:2);

            else
                data=data(:,1:2);
            end
        end
        
        if exist('outs','var')==0 
            dtype=menu('What type?','2theta','1/d','d');
        end
        
        switch dtype
            case 2
            data(:,1) = (180/pi)*2*asin(1*data(:,1)/2);
            case 3
                data(:,1)=1./data(:,1);
                data(:,1) = (180/pi)*2*asin(1*data(:,1)/2);
            case 1 
           
        end
    
    end    
    if isempty(identa)==1 
    identa=input('Enter Sample name:   ','s');
    end
else
    
    nogo = menu({'Import the data into the workspace';...
        'Two columns [2theta, Intensity] and call it data';...
        'Click when complete'},'Continue','Not now');
    
    if nogo==1
        data = evalin('base', 'data');
        wavelen = 1;
        if isempty(identa)==1
            identa=input('Enter Sample name:   ','s');
        end
        alpha2=1;
        tube='No';
        kor2theta = menu('What is x?','k (=1/d)','d','2\theta');
        switch kor2theta
            case 1
                data(:,1) = (180/pi)*2*asin(1*data(:,1)/2);
            case 2
                data(:,1)=1./data(:,1);
                data(:,1) = (180/pi)*2*asin(1*data(:,1)/2);
            case 3
                
        end
    else 
        disp('error')
    end
    
end%end of gui import
    
alpha2 = getDPPApref('alpha2');
tube = getDPPApref('tube');
wavelen =getDPPApref('wavelen');

%% interpolate
val=2;%, no option any more

switch val
    case 1
%         data(:,1)=2*sin(pi*data(:,1)/360)/wavelen;
    case 2
        data=tsinterpl(data,wavelen);
end

data = data(data(:,1)<krange(2),:);
data = data(data(:,1)>krange(1),:);


hold(haxes,'off')
semilogy(data(:,1),data(:,2),'.','parent',haxes)
% set(handles.sampleid2_t,'string',identa)


set(handles.wav_t,'string',num2str(wavelen))
setDPPApref('identa',identa);
setDPPApref('alpha2',alpha2);       
setDPPApref('tube',tube);
setDPPApref('wavelen',wavelen);

if strcmp(dataorInstr,'Sampl')
    save([cd,'/0. variables/data.mat'],'data')

elseif strcmp(dataorInstr,'Instr')
    data_I = data;
    save([cd,'/0. variables/data_I.mat'],'data_I')

end


outs.wavelen=wavelen;
outs.valCol=valCol;
outs.dtype=dtype;
end
