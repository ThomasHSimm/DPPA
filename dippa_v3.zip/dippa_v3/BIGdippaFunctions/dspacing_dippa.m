function d=dspacing_dippa(dp, crystalsymm, lat1, lat2)
%%  find d-spacing values given symmetry and hkl values
%% THS 2016 dppa

% eg for hcp--> dp=[0 0 2;1 0 0;1 0 1;1 0 2;1 1 0;1 0 3;0 0 4;1 1 2;2 0 0;2 0 1;1 0 4] 
% mg--> lat1=3.210; lat2=1.624*3.21;lambda=0.179 (Co)
lenindex=size(dp,1);


switch crystalsymm
    case '1'
%         d=lambda./(2*sin(peaks*pi/360));
    case 'FCC'
        for n=1:lenindex
%             lat1/(sum(dp(n,:).^2)).^0.5;
            d(n)=lat1/(sum(dp(n,:).^2)).^0.5;
        end
%         peaks=180*2*asin(lambda./(2*d))/pi;
        
    case 'BCC'
        for n=1:lenindex;
%             lat1/(sum(dp(n,:).^2)).^0.5;
            d(n)=lat1/(sum(dp(n,:).^2)).^0.5;
        end
%         peaks=180*2*asin(lambda./(2*d))/pi;
        
    case 'TET'
        for n=1:lenindex;
            d(n)=1/( ( dp(n,1)^2 + dp(n,2)^2 )/lat1^2 + dp(n,3)^2/lat2^2 )^0.5;
        end
%         peaks=180*2*asin(lambda./(2*d))/pi;
    case 'HCP'
        for n=1:lenindex
            d(n)=1/( (4/3)*(dp(n,1)^2 + dp(n,1)*dp(n,2) + dp(n,2)^2)/lat1^2  +  dp(n,3)^2/lat2^2 )^0.5;
        end
%         peaks=180*2*asin(lambda./(2*d))/pi;
        
end
% k=1./d;