function batchplotGUI(handles, batcha, whatplottype, whatplotphase, whatplotpks)
%initialises
load([cd,'/0. variables/phases.mat'],'dsettings')
haxes = handles.axes1;
hold(haxes,'off')
if whatplotphase==1
    pksuse = whatplotpks;
else
    pksuse = whatplotpks+length(dsettings(1).d);
end
%get values
h=1;
if size(batcha(end).aa,1)>4
    for n=1:length(batcha)
        FW(h,:)=.5*(batcha(n).aa(3,:)+batcha(n).aa(5,:));
        neta(h,:)=.5*(batcha(n).aa(4,:)+batcha(n).aa(6,:));
        intens(h,:)=batcha(n).aa(2,:);
        pos(h,:)=batcha(n).aa(1,:);
        h=h+1;
    end
else
    for n=1:length(batcha)
        FW(h,:)=batcha(n).aa(3,:);
        neta(h,:)=batcha(n).aa(4,:);
        intens(h,:)=batcha(n).aa(2,:);
        pos(h,:)=batcha(n).aa(1,:);
        h=h+1;
    end
end

switch whatplottype
    case 1
        plot(FW(:,pksuse),'parent',haxes),
    case 2
        plot(neta(:,pksuse),'parent',haxes),
    case 3
        semilogy(intens(:,pksuse),'parent',haxes),
    case 4
        del_d = 1./pos(:,pksuse)-1./pos(1,pksuse);
        d = 1./pos(:,pksuse);
        e = del_d ./ d;
        plot(e,'parent',haxes),
end

legend( haxes,num2str(dsettings(whatplotphase).index(whatplotpks,:)) )


end