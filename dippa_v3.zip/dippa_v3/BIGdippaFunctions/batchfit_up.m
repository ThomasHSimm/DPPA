function batchfit_up(hObject, eventdata, handles)
%% function to do batch fitting used with BIGdippa
load([cd,'/0. variables/batchdetails.mat'],'batcha')
midfileno = (length(batcha) + rem(length(batcha),2) )/2;

    %% loads
    load([cd,'/0. variables/fit.mat'],'aa','aabcg')
    load([cd,'/0. variables/data.mat'],'data')
    
    load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')    
    load([cd,'/0. variables/data_I.mat'],'data_I')
    load([cd,'/0. variables/phases.mat'],'dsettings')
    DPPApref= getDPPApref;
    
    batcha(1,1).data_I=data_I;%*
    batcha(1,1).aa_I=aa_I;%*
    batcha(1,1).aabcg_I=aabcg_I;%*
    batcha(1,1).dsettings=dsettings;%*
    batcha(1,1).DPPApref=DPPApref;%*
    id =dsettings(1).id;
    batcha(1,1).name=id%*
    
    batcha(1,midfileno).aa=aa;
    batcha(1,midfileno).data=data;
    batcha(1,midfileno).aabcg=aabcg;
save([cd,'/0. variables/batchdetails.mat'],'batcha')
%%
krange(1) = str2double(get(handles.batchKlower_t,'string'));
krange(2) = str2double(get(handles.batchKupper_t,'string'));

%% load files
for ni=midfileno+1:length(batcha)
    
    loadb_GUI_batch(handles, batcha(ni).filename, batcha(ni).pathname, 'Sampl',krange,id)
    
    inner(hObject, eventdata, handles)
    
load([cd,'/0. variables/fit.mat'],'aa','aabcg')
load([cd,'/0. variables/data.mat'],'data')    
    batcha(1,ni).aa=aa;
    batcha(1,ni).data=data;
    batcha(1,ni).aabcg=aabcg;
save([cd,'/0. variables/batchdetails.mat'],'batcha')

end

end
%%
function inner(hObject, eventdata, handles)

load([cd,'/0. variables/phases.mat'],'dsettings')
%go through phase 1
set(handles.phaseres_l,'value',1)
%then go through each peak
set(handles.indexres_l,'value',1)
for n=1:length(dsettings(1).d)
    n
    %move peak along
    set(handles.indexres_l,'value',n)
    %individually fit each peak
    indivfit_b_Callback(hObject, eventdata, handles)
end

%go through phase 2
set(handles.phaseres_l,'value',2)
%then go through each peak
set(handles.indexres_l,'value',1)
for n=1:length(dsettings(2).d)
    %move peak along
    set(handles.indexres_l,'value',n)
    %individually fit each peak
    indivfit_b_Callback(hObject, eventdata, handles)
end

%go through phase 1
set(handles.phaseres_l,'value',1)
%then go through each peak
set(handles.indexres_l,'value',1)
for n=1:length(dsettings(1).d)
    %move peak along
    set(handles.indexres_l,'value',n)
    %individually fit each peak
    indivfit_b_Callback(hObject, eventdata, handles)
end


end