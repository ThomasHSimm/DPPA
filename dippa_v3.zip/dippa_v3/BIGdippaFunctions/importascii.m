function data = importascii(path,file,handles)
    
%gets data from ascii
fid=fopen([path, file]);
tex = textscan(fid, '%q', 'delimiter', '\n');

h=1;c=0;
for n=1:size(tex{1})
    if strcmp(tex{1}{n}(1),'#')==0
        if h==1;c=c+1;end;
        dat{c}(h,:)=str2num(char(tex{1}{n}));h=h+1;
    else h=1;
    end;
end

data=dat{1};

%user input for type of tube
wav=menu('Enter Wavelength in A:   ','Copper with alpha2','Cobalt with alpha2','(without alpha2) Enter value in Armstrongs:     ');
switch wav
    case 1
        wavelen=0.5*(1.54056+1.54439);%%
        tube='Cu';alpha2=0;
        set(handles.alpha2_b,'value',1);
    case 2
        wavelen= 0.5*(1.78897+ 1.79285);%%in Armstrongs
        tube='Co';alpha2=0;
        set(handles.alpha2_b,'value',1);
    case 3
        wavelen= input('enter wavelength in A:  ');
        set(handles.alpha2_b,'value',0);
        alpha2=1;tube='No';

end

%update prefs
setDPPApref('alpha2',alpha2)
setDPPApref('tube',tube)
setDPPApref('wavelen',wavelen)

end