function data = importUDF(path,file,handles)

%convert udf to .dat
if strcmp(file(end-2:end),'udf') 
    perl([cd,'/udfcon_lc.pl'],[path,file(1:end-4),'.udf']); 
elseif strcmp(file(end-2:end),'UDF' )
    perl([cd,'/udfcon.pl'],[path,file(1:end-4),'.UDF']);
end

%and load the dat file
filenomdat=[path,file(1:end-4),'.dat'];
data=load(filenomdat);

%get the info from the sample
[tube, identa]=importfile([path,file]);

%what type of tube
if strcmp(tube,'Cu')==1  
    wavelen=0.5*(1.54056+1.54439);%%
elseif strcmp(tube,'Co')==1
    wavelen= 0.5*(1.78897+ 1.79285);%%in Armstrongs
end

%update prefs
setDPPApref('tube',tube)
disp(['setting tube as',tube])

%update GUI
set(handles.alpha2_b,'value',1);

%alpha 2 exists
alpha2=0;
setDPPApref('alpha2',alpha2)
setDPPApref('wavelen',wavelen)


end