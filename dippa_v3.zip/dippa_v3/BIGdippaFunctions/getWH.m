function [FWfit_data, X, FWfit_line, X_line]= getWH(lamfit,selected, g, H2, Aest, type_sizestrain)
if nargin ==2
    load([cd,'/0. variables/phases.mat'],'dsettings')
    load([cd,'/0. variables/fit.mat'],'aa','aabcg')
    index=dsettings(1).index(:,:);
    H2=Hsq(index);
    H2 = H2(selected);
    g = aa(1,selected);
    WHpref= getappdata(0,'WHpref');
    Aest = WHpref.chk0;
    type_sizestrain = WHpref.type_sizestrain;
elseif nargin ==3
    load([cd,'/0. variables/phases.mat'],'dsettings')
    load([cd,'/0. variables/fit.mat'],'aa','aabcg')
    phaseno=g;
    index=dsettings(phaseno).index(:,:);
    H2=Hsq(index);
    H2 = H2(selected);
    if phaseno==1
        g = aa(1,selected);
    elseif phaseno==2
        no_of1 = size(dsettings(1).index,1);
        g=aa(1,selected + no_of1);
    elseif phaseno>2
       menu('not supported, max no of phases is 2','ok'); 
    end
    
    WHpref= getappdata(0,'WHpref');
    Aest = WHpref.chk0;
    type_sizestrain = WHpref.type_sizestrain;
end

q = lamfit(1);
C = Aest*(1-q*H2); 
X = g.*C.^0.5;
X_line = 0:.01:max(X)*1.2;

switch type_sizestrain
    case 'mwhA'
        FWfit_data =        MWHA(lamfit , X) ; 
        FWfit_line =        MWHA(lamfit , X_line) ; 
        
    case 'mwhB'
        FWfit_data =        MWHB(lamfit , X) ; 
        FWfit_line =        MWHB(lamfit , X_line) ; 

    case 'mwhC'
        FWfit_data =        MWHC(lamfit , X) ; 
        FWfit_line =        MWHC(lamfit , X_line) ; 

end 


end

%%
function FWc=MWHA(x, X)
      q = x(1);
      sizee = x(2);
      strain = x(3);
      
       
      FWc =  sizee + strain*X;
      
    end
%%    
    function FWc=MWHB(x, X)
      q=x(1);
      sizee=x(2);
      strain=x(3);
        
      FWc =(  sizee^2 + strain^2*X.^2 ).^0.5;
      
          
    end
 %%   
    function FWc=MWHC(x, X)
      q=x(1);
      sizee=x(2);
      strain=x(3);
       
      
      FWc =  sizee + strain*X.^2  ;

    end
%%