function fitFC_GUI(handles)
%% paremnt to run fitting functions
%% TH Simm dppa

%prefs
dppFCpref = getdppFCpref;
selected = dppFCpref.selected;
type_sizestrain = dppFCpref.type_sizestrain;
allindi = dppFCpref.allindi;

num = dppFCpref.sample_n ;
load([cd,'/0. variables/phases.mat'],'dsettings')
crys = dsettings(1).cstruct(1:3);
HCPalloy = getdppFCpref('HCPalloy');

switch type_sizestrain
    %%
    case 'linWA'
        if strcmp(HCPalloy,'No')==1
            [ FCres,  all_I]=logWAindi(selected,num);
        else
            [ FCres,  all_I]=logWAindi_HCP(selected,num);
            tizr = getdppFCpref('HCPalloy');
            [indiv_comb, Burgcomb]=contrastHCP(FCres.q(1) ,FCres.q(2),tizr);
            FCres.HCP_CBadj = Burgcomb;
            FCres.HCP_indivs = indiv_comb;
            
            Re=FCres.M/( (FCres.rho*1e-4).^.5 );
            FCres.rho=FCres.rho/Burgcomb(4);
            FCres.M=(FCres.rho*1e-4 )^.5*Re;
            
            Re=FCres.MGrom/( (FCres.rhoGrom*1e-4).^.5 );
            FCres.rhoGrom=FCres.rhoGrom/Burgcomb(4);
            FCres.MGrom=(FCres.rhoGrom*1e-4 )^.5*Re;
            
            Re = FCres.MWilk/( (FCres.rhoWilk*1e-4).^.5 );
            FCres.rhoWilk = FCres.rhoWilk/Burgcomb(4);
            FCres.MWilk = (FCres.rhoWilk*1e-4 )^.5*Re;
            
            FCres.C = FCres.C * Burgcomb(4);
            all_I(:,3)=all_I(:,3)/Burgcomb(4);
        
        end
        
   
    case 'logWA'
    %%
        if strcmp(HCPalloy,'No')==1%CUBIC
            if allindi =='ind'
                [ FCres,  all_I]=logWAindi(selected,num);
            elseif allindi=='all'
                [ FCres,  all_I]=logWAall(selected,num);
            end
        else
            [ FCres,  all_I]=logWAindi_HCP(selected,num);
            tizr = getdppFCpref('HCPalloy');
            [indiv_comb, Burgcomb]=contrastHCP(FCres.q(1) ,FCres.q(2),tizr);
            FCres.HCP_CBadj = Burgcomb;
            FCres.HCP_indivs = indiv_comb;
            
            Re=FCres.M/( (FCres.rho*1e-4).^.5 );
            FCres.rho=FCres.rho/Burgcomb(4);
            FCres.M=(FCres.rho*1e-4 )^.5*Re;
            
            Re=FCres.MGrom/( (FCres.rhoGrom*1e-4).^.5 );
            FCres.rhoGrom=FCres.rhoGrom/Burgcomb(4);
            FCres.MGrom=(FCres.rhoGrom*1e-4 )^.5*Re;
            
            Re = FCres.MWilk/( (FCres.rhoWilk*1e-4).^.5 );
            FCres.rhoWilk = FCres.rhoWilk/Burgcomb(4);
            FCres.MWilk = (FCres.rhoWilk*1e-4 )^.5*Re;
            
            FCres.C = FCres.C * Burgcomb(4);
            all_I(:,3)=all_I(:,3)/Burgcomb(4);
        
        end
    
    case 'altrn'
    %%
       [ FCres,  all_I]=alternative(selected,num);
    case 'none'
    %% 
        if strcmp(HCPalloy,'No')==1
            [ FCres,  all_I]=logWAindi_noSIZE(selected,num);
        else 
            [ FCres,  all_I]=logWAindi_noSIZE_HCP(selected,num);
            tizr = getdppFCpref('HCPalloy');
            [indiv_comb, Burgcomb]=contrastHCP(FCres.q(1) ,FCres.q(2),tizr);
            FCres.HCP_CBadj = Burgcomb;
            FCres.HCP_indivs = indiv_comb;
            
            Re=FCres.M/( (FCres.rho*1e-4).^.5 );
            FCres.rho=FCres.rho/Burgcomb(4);
            FCres.M=(FCres.rho*1e-4 )^.5*Re;
            
            Re=FCres.MGrom/( (FCres.rhoGrom*1e-4).^.5 );
            FCres.rhoGrom=FCres.rhoGrom/Burgcomb(4);
            FCres.MGrom=(FCres.rhoGrom*1e-4 )^.5*Re;
            
            Re = FCres.MWilk/( (FCres.rhoWilk*1e-4).^.5 );
            FCres.rhoWilk = FCres.rhoWilk/Burgcomb(4);
            FCres.MWilk = (FCres.rhoWilk*1e-4 )^.5*Re;
            
            FCres.C = FCres.C * Burgcomb(4);
            all_I(:,3)=all_I(:,3)/Burgcomb(4);
        
        end
         
         disp('No SIZE')
end



%% GUI
set(handles.q_t,'string',FCres.q )
set(handles.gs_t,'string',FCres.gs )
disp('adjust below later')
set(handles.rho_t,'string',FCres.rhoGrom )
set(handles.M_t,'string', FCres.MGrom )

set(handles.results_p,'visible','on')

if strcmp(HCPalloy,'No') ~= 1
    set(handles.contrastHCPres_p,'visible','on')
    set(handles.cSlip_t,'string' , FCres.HCP_CBadj(1) )
    set(handles.aSlip_t,'String' , FCres.HCP_CBadj(3) )
    set(handles.cplusaSlip_t,'String' , FCres.HCP_CBadj(2) )
end
set(handles.fitta_p,'visible','off')
set(handles.menu_l,'value',6)

save([cd,'/0. variables/FCresStr.mat'],'FCres')
save([cd,'/0. variables/all_I.mat'],'all_I')

% set(handles.plotres_l,'string',string_plotres);
end

%% 
% % function [ FCres, all_I]=  inner_logWA(num,crys, selected)
% % 
% % if strcmp(crys,'HCP')%hx
% % 
% % elseif strcmp(crys(2:3),'CC') 
% %     
% %        
% %     
% % end
% % 
% % end
%%
