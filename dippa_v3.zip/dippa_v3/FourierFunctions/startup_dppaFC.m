function startup_dppaFC(dppFCpref,~)
if nargin==0
    dppFCpref='fcc';
end

if nargin==1
%% When loading results
    %general
    HCPalloy = dppFCpref.HCPalloy;
    selected = dppFCpref.selected;
    sample_n = dppFCpref.sample_n ;
    sampleID = dppFCpref.sampleID ;
    delK = dppFCpref.delK;
    semilogq = dppFCpref.semilogq;
    
    %FC choices
    type_sizestrain = dppFCpref.type_sizestrain;
    type_size = dppFCpref.type_size;
    type_strain = dppFCpref.type_strain;
    type_PF = dppFCpref.type_PF;
    KWmin = dppFCpref.KWmin;
    KWmax = dppFCpref.KWmax; 
    allindi = dppFCpref.allindi; 
    
    %needed for FC res  
    qscrew = dppFCpref.qscrew; 
    qedge = dppFCpref.qedge; 
    chk0 = dppFCpref.chk0;
    B = dppFCpref.B;
    
    
else
%% preset values
    dppaprefID = dppFCpref;
    clear dppFCpref
    if strcmp(dppaprefID,'fcc')==1
        
        HCPalloy = 'No';
            %general
        selected = [1 2 3 4 5];
        sample_n = 40 ;
        delK = 0.02;
        semilogq = 1;
        sampleID = 'sample1';
        
            %FC choices
        type_size = 'Cauchy';%'logNorm'
        type_sizestrain = 'logWA';%'linWA','altrn','sfeld'
        type_strain = 'Grom'; %'Wilk'
        type_PF = 0;
        KWmin = 200;
        KWmax = 300;
        allindi = 'ind';
        
            %needed for FC res  
        qscrew = 2.4699;
        qedge=1.7180 ;
        chk0 = 0.2;
        lat=0.35675*10;%for nickel 
        B = 0.5*pi*(lat/2^0.5)^2;
    elseif strcmp(dppaprefID,'hcp')==1
        
        HCPalloy = 'Titanium';
        
            %general
        selected = 1:1:15;
        sample_n = 40 ;
        delK = 0.02;
        semilogq = 1;
        sampleID = 'sample1';
        
            %FC choices
        type_size = 'Cauchy';%'logNorm'
        type_sizestrain = 'logWA';%'linWA','altrn','sfeld'
        type_strain = 'Grom'; %'Wilk'
        type_PF = 0;
        KWmin = 200;
        KWmax = 300;
        allindi = 'ind';
        
            %needed for FC res  
        qscrew = [ 1.5 , 1.5 ];
        qedge= [  -1.5 , -2.5  ];
        chk0 = 1;
%         lat= [ 2.9240  ,  4.6700];
        B = 1;

    end
end
%% update prefs       
    %general
dppFCpref.HCPalloy = HCPalloy;
dppFCpref.selected =selected;
dppFCpref.sample_n =sample_n;
dppFCpref.delK =delK;
dppFCpref.semilogq = semilogq; 
dppFCpref.sampleID = sampleID;

    %FC choices
dppFCpref.type_sizestrain =type_sizestrain;
dppFCpref.type_strain =type_strain;
dppFCpref.type_size =type_size;
dppFCpref.type_PF =type_PF;
dppFCpref.KWmin = KWmin;
dppFCpref.KWmax = KWmax; 
dppFCpref.allindi = allindi;

    %needed for FC res  
dppFCpref.qscrew = qscrew; 
dppFCpref.qedge = qedge; 
dppFCpref.chk0 = chk0;
dppFCpref.B = B;
    

setappdata(0,'dppFCpref',dppFCpref)

% setdppaFCpref('identa',identa);
% setDPPApref('alpha2',alpha2);
% setDPPApref('bcg2peak',bcg2peak);       


end