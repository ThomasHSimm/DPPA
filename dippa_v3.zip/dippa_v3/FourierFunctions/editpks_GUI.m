function editpks_GUI(value, peakno, realorinstr, haxes, handles)
%%

%% initialises

%loads
load([cd,'/0. variables/FC_Iall.mat'])
load([cd,'/0. variables/fit.mat'])
load([cd,'/0. variables/fit_I.mat'])
%prefs
xx = realorinstr;
if xx==0
    xx=2;
else
    xx=1;
end
sample_n = getdppFCpref('sample_n');
semilogq = getdppFCpref('semilogq');
delK = getdppFCpref('delK');
%%
switch value
    case '1. Change intensity values'
%%
        n = peakno;
     
        hold(haxes,'off')
        if semilogq==1
            semilogy(I_all(:,n,xx),'parent',haxes,...
                'color','k','Linewidth',2),
            hold(haxes,'on')
        else
            plot(I_all(:,n,xx),'parent',haxes,...
                color,'k','Linewidth',2)
            hold(haxes,'on')
        end

        menu('click on points to create new intensity points (right click when complete','ok');
        but=1;n=1;
        while but~=3
            [x(n), y(n), but]=ginput(1);
            n=n+1;
                          
        end
        x=x(1:end-1);y=y(1:end-1);
        x2=sort(x);
        for nn=1:length(x2)
            x2pos(nn)=find(x2(nn)==x,1);
        end
            y2=y(x2pos);
            
            xstart=x2(1)-rem(x2(1),1)+1;
            xend=x2(end)-rem(x2(end),1);
            xdata=xstart:1:xend;
            newdata=interp1(x2,y2,xdata);
            
            I_all(xstart:xend,peakno,xx)=newdata;
            
            disp('hi');
            hold(haxes,'off')
            semilogy(I_all(:,peakno,xx),'parent',haxes,...
                    'color','r','Linewidth',2),
            grid(haxes,'on')
            
    case '2. Reduce all I' 
%%
         hold(haxes,'off')
        if semilogq==1
            semilogy(I_all(:,peakno,xx),'parent',haxes,...
                'color','k','Linewidth',2),
            hold(haxes,'on')
            grid(haxes,'on')
        else
            plot(I_all(:,peakno,xx),'parent',haxes,...
                'color','k','Linewidth',2)
            hold(haxes,'on')
            grid(haxes,'on')
        end
        
        [x , y]=ginput(1);
        I_all(:,peakno,xx)=I_all(:,peakno,xx)-y;
        
        %normalise
        I_all(:,peakno,xx)=I_all(:,peakno,xx)./max(I_all(:,peakno,xx));
        
        hold(haxes,'off')
        semilogy(I_all(:,peakno,xx),'parent',haxes,...
                'color','r','Linewidth',2),
        grid(haxes,'on')
        
    case '3. Increase all I'
         hold(haxes,'off')
        if semilogq==1
            semilogy(I_all(:,peakno,xx),'parent',haxes,...
                'color','k','Linewidth',2),
            hold(haxes,'on')
            grid(haxes,'on')
        else
            plot(I_all(:,peakno,xx),'parent',haxes,...
                'color','k','Linewidth',2)
            hold(haxes,'on')
            grid(haxes,'on')
        end
        
        [x ,y]=ginput(1);
        I_all(:,peakno,xx)=I_all(:,peakno,xx)+y;
        %normalise
        I_all(:,peakno,xx)=I_all(:,peakno,xx)./max(I_all(:,peakno,xx));
        hold(haxes,'off')
        semilogy(I_all(:,peakno,xx),'parent',haxes,...
                'color','r','Linewidth',2),
        grid(haxes,'on')
        
    case '4. Only use LHS of peak'
%%
        opta = menu('Do for both measured and instrumental?','Yes','No');
        
        LR=1;
        if opta ==1
            I_all(:,peakno,1)=oneside(I_all(:,peakno,1),LR);
            I_all(:,peakno,2)=oneside(I_all(:,peakno,2),LR);
        else
            I_all(:,peakno,xx)=oneside(I_all(:,peakno,xx),LR);
        end
        hold(haxes,'off')
        semilogy(I_all(:,peakno,xx),'parent',haxes,...
            'color','r','Linewidth',2),
        grid(haxes,'on')
            
    case '5. Only use RHS of peak'
%%
        opta = menu('Do for both measured and instrumental?','Yes','No');
        LR=2;
        if opta ==1
            I_all(:,peakno,1)=oneside(I_all(:,peakno,1),LR);
            I_all(:,peakno,2)=oneside(I_all(:,peakno,2),LR);
        else
            I_all(:,peakno,xx)=oneside(I_all(:,peakno,xx),LR);
        end
        
        hold(haxes,'off')
        semilogy(I_all(:,peakno,xx),'parent',haxes,...
            'color','r','Linewidth',2),
        grid(haxes,'on')
        
    case '6. Auto background level'
%% 
        selected = getdppFCpref('selected');
        quest=menu('Which peaks to adjust the background of?','All','Selected');
        if quest==1
            hwa = waitbar(0,'Calculating...'); 
            for n=1:length(selected)
                waitbar(n/length(selected))
                I_all=bcgmin(sample_n, selected(n), I_all);
            end
            close(hwa)
        else
            I_all=bcgmin(sample_n,peakno, I_all);
        end
    case '7. Strip out alpha2'
        
            menu('Not implemented','ok');
            
    case '8. Use pV fit'
        
        if xx==2%instrumental
            opta = menu('Change just the instrumental peak to the PV fit?','yes','no change measured too','change neither');
            switch opta
                case 1
                    instraY=1; samplaY=0;
                case 2
                    instraY=1; samplaY=1;
                case 3
                    instraY=0; samplaY=0;
            end
        else%xx=1 measured
            opta =menu('Change just the measured peak to the PV fit?','yes','no change instrumental too','change neither');
            switch opta
                case 1
                    instraY=0; samplaY=1;
                case 2
                    instraY=1; samplaY=1;
                case 3
                    instraY=0; samplaY=0;
            end
        end
        
        if instraY==1%instrumental
            xpos = aa(1,peakno);
            instrpos = find( abs(xpos - aa_I(1,1:end-1))==min( abs(xpos - aa_I(1,1:end-1)) ) );
            aatemp=aa_I(:,instrpos);
            aatemp(1,:)=0;aatemp(2,:)=1;
            len00=size(I_all,1);incr0=2*delK/(-1+len00);
            xdata=-delK:incr0:delK;
            I_all(:,peakno,2)=pk_voigt2asymm(xdata',aatemp)';
        end
        if samplaY==1
            aatemp=aa(:,peakno);
            aatemp(1,:)=0;aatemp(2,:)=1;
            len00=size(I_all,1);incr0=2*delK/(-1+len00);
            xdata=-delK:incr0:delK;
            I_all(:,peakno,1)=pk_voigt2asymm(xdata',aatemp)';
        end
end


save([cd,'/0. variables/FC_Iall.mat'],'I_all','delK')
 
end