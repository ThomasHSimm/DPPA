function value = getdppFCpref(pref,default)

group = getappdata(0,'dppFCpref');

if nargin == 0

  value = group;
  
elseif isfield(group,pref)
  
  value = group.(pref);
  
else
  
  value = default;
  
end

end

