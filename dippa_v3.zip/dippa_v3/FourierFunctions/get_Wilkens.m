function fout=get_Wilkens(Re, L)
%% gets Wilkens function for use with strain FCs
%% THS 2016 dppa

xall=L/Re;
xall=0.5*exp(-0.25)*exp(2)*xall;%the other way?
%%
for na=1:length(xall)
    x=xall(na);
    
    if x<=1
        if x==0
            f=0;
        else
           f = -log(x) + 7/4 - log(2) + (1/6)*x^2 -(32/(225*pi))*x^3;%%Scardi 01 
        end 
        
    elseif x>1
        f = 256/(45*pi*x) - (11/24 + 0.25*log(2*x))/x^(2);%%is this log(2x) or log(2)*x? Scardi 01
    end
    
    fout(na)=f;
end
fout=fout';
