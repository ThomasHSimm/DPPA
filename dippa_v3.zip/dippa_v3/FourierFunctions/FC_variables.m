%%
getdppFCpref
%general
selected = [1 2 3 4 5];
sample_n = 40 ;
delK = 0.02;
semilogq = 1;

%FC choices
type_size = 'Cauchy';%'logNorm'
type_sizestrain = 'logWA';%'linWA','altrn','sfeld'
type_strain = 'Grom'; %'Wilk'
type_PF = 0;
KWmin = 200;
KWmax = 300;
allindi = 'ind'
%needed for FC res  
qscrew = 2.4699;
qedge=1.7180 ;
chk0 = 0.2;
% lat=0.35675*10;%for nickel 
B = 0.5*pi*(lat/2^0.5)^2;


        


%%
C
chk0
B
g
L


FCresStr.all_I = all_I;
FCresStr.L = L;

FCresStr.C = C;
FCresStr.g = g;
%% FCres

FCresStr.chk0 = chk0;
FCresStr.B = B;
FCresStr.q = q;

FCresStr.MGrom = M(1);
FCresStr.MWilk = M(2);
FCresStr.rhoGrom = rho(1)*1e20*1e-16;
FCresStr.rhoWilk = rho(2)*1e20*1e-16;

FCresStr.gs = gs * 1e-4;
FCresStr.a3 = a3;
% FCresStr.allindi = 'ind'
setdppFCpref('allindi','ind')

dppFCpref = getdppFCpref;
FCresStr.dppFCpref = dppFCpref;


%%
% type(1)=get(handles.strain_l,'value')-1;
% type(2)=get(handles.plf_l,'value')-1;
% 
% type(3)=str2double( get(handles.KWLmin_t,'string') );
% type(4)=str2double( get(handles.KWLmax_t,'string') );
% type(6)=get(handles.sizestrain_l,'value')-1;