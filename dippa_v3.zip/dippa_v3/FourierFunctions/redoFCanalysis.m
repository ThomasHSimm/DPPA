function newvals = redoFCanalysis(val, haxes, dppFCpref)

load([cd,'/0. variables/FC.mat'],'FC',...
    'selected','L','delK')

% load([cd,'/0. variables/FC_Iall.mat'])
% load([cd,'/0. variables/fit.mat'],'aa')
load([cd,'/0. variables/phases.mat'],'dsettings')
load([cd,'/0. variables/FCresStr.mat'],'FCres')
load([cd,'/0. variables/all_I.mat'],'all_I')
% number of n-values used
nmax = dppFCpref.sample_n;
switch val
    
        case '7. Kriv-Wilk plot'     
        type_strain = dppFCpref.type_strain;
        
        if strcmp(type_strain, 'Grom')==1
            rho = FCres.rhoGrom;
            M = FCres.MGrom;       
        elseif strcmp(type_strain, 'Wilk')==1
            rho = FCres.rhoWilk;
            M = FCres.MWilk;
        end

        g = FCres.g;
        C = FCres.C;
        B = FCres.B;
        Chk0 = FCres.chk0;
        
        [~, ADnocg] = get_strainFCs(rho, M, B, L, g, C, type_strain);
        
        XL_m=( all_I(1:nmax,3)' )./L(1:nmax).^2;

        semilogx(L(1:nmax), XL_m,'ok','parent',haxes,...
            'markersize',10,'linewidth',3),hold
        hold(haxes,'on')
        plot(L, ADnocg, 'parent',haxes,...
            'color','g','markersize',10,'linewidth',3)
        
%         xlim(haxes, [L(1)*.8 , L(nmax)*1.2 ])
        ylim(haxes, [0 , max(XL_m)*1.2])
        
    case '5. Size FCs'
        gs = FCres.gs;
        type_size = dppFCpref.type_size;
        AS = get_sizeFCs(gs, L, type_size, length(L));
        plot(L(1:length(all_I)), exp(all_I(:,2)),'marker','s','markerfacecolor','b','color','k','markersize',10,'linestyle','none','parent',haxes)
        hold(haxes,'on')
        plot(L(1:nmax), AS(1:nmax),'parent',haxes,'linewidth',3,'color','b')
        xlabel(haxes,'Fourier Length (x 10^-^1^0m)')
        ylabel(haxes,'Size Fourier Coefficients')
        
        posnot = 1:1:6;
        options=optimset('tolx',1e-9,'tolf',1e-12);
        FCsS = exp( all_I(posnot,2) );
        gs2 =lsqcurvefit(@sizeFC2s, [300 1]  , (L(posnot)'), FCsS,[0 ],[100000000],options)
        FCsS =FCsS /gs2(2);FCsS(1)=1;
        gs =lsqcurvefit(@sizeFC, gs2(1)  , (L(posnot)'), FCsS,[0 ],[100000000],options);
        
        gs = gs* 1e-4;
        AS = get_sizeFCs(gs, L, type_size, length(L));
        FCsS = exp( all_I(1:length(all_I),2) )/gs2(2);FCsS(1)=1;
        plot(L(1:length(all_I)), FCsS,'marker','s','markerfacecolor','g','color','g','markersize',10,'linestyle','none','parent',haxes)
       
        plot(L(1:nmax), AS(1:nmax),'parent',haxes,'linewidth',3,'color','r')

        newvals = gs;
        
end

end

function [AA, lam]=sizeFC2s(lam, L)
        
    AA = lam(2)*exp(-L/lam(1) );
end 

function [AA, lam]=sizeFC(lam, L)
        
    AA = exp(-L/lam(1) );
end 