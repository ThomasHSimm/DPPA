function  [ OUT, all_I]=logWAall(selected,num)
%% fits FCs to logWA- all method
%% THS 2016 dppa

%% initialises
%loads
load([cd,'/0. variables/phases.mat'],'dsettings')
load([cd,'/0. variables/FC.mat'],'FC','selected','L','delK')

%prefs
qscrew = getdppFCpref('qscrew');
qedge = getdppFCpref('qedge');
qv=.5*(qscrew+qedge);
qv111 = qv;

KWmax = getdppFCpref('KWmax');
KWmin = getdppFCpref('KWmin');
delK = getdppFCpref('delK');
type_strain = getdppFCpref('type_strain');

%defines
chk0= getdppFCpref('chk0');
B= getdppFCpref('B');
a3=0.5/delK;
H2=Hsq(dsettings(1,1).index(selected,:));

% Fouriers 
L2 = L'; %fourier length
A = FC(:,selected);
% sizA=length(A);
lnA=log(A);
st=2;%%starting L
% g
for n=1:length(selected)
    g(n)=1./dsettings(1,1).d(selected(n));
end
         
%%
% Fit of individual

%% Initial Combined Fits 
options=optimset('tolx',1e-9,'tolf',1e-12);
guesspar=[qv -0.05 0.003];
lb=[qedge -7 0   ];
ub=[qscrew -1e-34 15 ];
guesspar_all=[qv,   1e2,    0.5,      3];   %q gs rho  M
lb_all      =[lb(1), 1e-10,  1e-3,      .1];
ub_all      =[ub(1), 1e4  ,   1e3,       10];

%% The first fit gets the q-values but could be used as a fit on its own
qstep=0.1;
% qrange = lb(1):qstep:ub(1);
qrange=lb_all(4):qstep:ub_all(4);
for qi=1:length(qrange)
    guesspar_all(4)=qrange(qi);
    lb_all(4)=qrange(qi)-qstep/2;
    ub_all(4)=qrange(qi)+qstep/2;
    [all_I_together1(qi,:), resnorm1(qi)]=lsqcurvefit(@allF_together,...
        guesspar_all , L2(st:num), lnA((st:num),:),lb_all,ub_all,options);
end

[all_I_together, resnorm2]=lsqcurvefit(@allF_together,...
    all_I_together1 , L2(st:num), lnA((st:num),:),lb_all,ub_all,options);


%% data out
q=all_I_together(1);
gs=all_I_together(2);

%Grom
rho=all_I_together(3);
M=all_I_together(4);

% Wilk
rho=all_I_together(3);
M=all_I_together(4);

C=chk0*(1-q*H2)  ; 

%% update outputs
FCresStr.C = C;
FCresStr.g = g;
FCresStr.chk0 = chk0;
FCresStr.B = B;
FCresStr.q = q;

FCresStr.MGrom = M(1);
FCresStr.MWilk = M(1);
FCresStr.rhoGrom = rho(1);%*1e20*1e-16;
FCresStr.rhoWilk = rho(1);%*1e20*1e-16;

switch type_strain
    case 'Grom'
    FCresStr.M = M(1);
    FCresStr.rho = rho(1);%*1e20*1e-16;
case 'Wilk'
    FCresStr.M = M(1);
    FCresStr.rho = rho(1);%*1e20*1e-16;
end

FCresStr.gs = gs;% * 1e-4;
FCresStr.a3 = a3;


dppFCpref = getdppFCpref;
FCresStr.dppFCpref = dppFCpref;

OUT = FCresStr;

all_I(1:num,1)=q;
[all_I(st:num,2)]=get_sizeFCs(gs,L(st:num),'Cauchy');
all_I(st:num,2) = log ( all_I(st:num,2) );
[~ , all_I(st:num,3)]=get_strainFCs(rho,M,B, L(st:num),g,C,'Wilk');
all_I(st:num,3) = (all_I(st:num,3)').*L(st:num).^2;

%% function to fit all together to FCs
function [lnAA, lam]=allF_together(lam, L)
    %defines
    if imag(lam(1))~=0;lam(1)=2;    end
    if imag(lam(2))~=0;lam(2)=2e9;  end
    if imag(lam(3))~=0;lam(3)=2e-16;end
    if imag(lam(4))~=0;lam(4)=4;end
    
    q_ = lam(1);
    FCres.q = q_;
    FCres.gs = lam(2);
    FCres.rho =lam(3);
    FCres.M =lam(4);
    FCres.g =g;
    FCres.B =B;
    
    FCres.C=chk0*(1-q_*H2)  ;

    %get FCs
FCs_ = get_WAFCs(FCres, L);
    %get outs
lnAA = log(FCs_);
    
lam = real(lam);

end


%%
end