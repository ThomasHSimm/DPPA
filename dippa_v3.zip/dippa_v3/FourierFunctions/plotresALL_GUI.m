function plotresALL_GUI(haxes,choice)
%%

load([cd,'/0. variables/FCres_setLocation.mat'],...
    'FileName2','PathName2')
load([PathName2,FileName2],'FCres_set')
hold(haxes,'off')

%% get values
for n=1:length(FCres_set)

    q(n,:) = FCres_set(1,n).FCres.q;
    gs(n) = FCres_set(1,n).FCres.gs;
    rho(n) = FCres_set(1,n).FCres.rho;
    M(n) = FCres_set(1,n).FCres.M;
    val(n) = FCres_set(1,n).val;
    typeSS{n}=FCres_set(1,n).FCres.dppFCpref.type_sizestrain;
    id{n}=FCres_set(1,n).ident;

end

%%

switch choice
        case 'q'
            plot(val,q,'parent',haxes,'marker','o',...
                'Markersize',10,'linewidth',3,'linestyle','none')
                        
            xlabel(haxes,'Strain %','fontsize',16)
            ylabel(haxes,'q','fontsize',16)
            set(haxes,'Fontsize',18)

        case 'Crystal Size'
            plot(val,gs,'parent',haxes,'marker','o',...
                'Markersize',10,'linewidth',3,'linestyle','none')
                        
            xlabel(haxes,'Strain %','fontsize',16)
            ylabel(haxes,'Crystal size (\mum)','fontsize',16)
            set(haxes,'Fontsize',18)
            
        case 'Dislocation Density'
            plot(val,rho,'parent',haxes,'marker','o',...
                'Markersize',10,'linewidth',3,'linestyle','none')
                        
            xlabel(haxes,'Strain %','fontsize',16)
            ylabel(haxes,'Dislocation density (10^1^6 m^-^2)','fontsize',16)
            set(haxes,'Fontsize',18)
            
        case 'Sqrt. Dislocation Density'
            plot(val,rho.^.5,'parent',haxes,'marker','o',...
                'Markersize',10,'linewidth',3,'linestyle','none')
                        
            xlabel(haxes,'Strain %','fontsize',16)
            ylabel(haxes,'Square-root of Dislocation density (10^1^6 m^-^2)','fontsize',16)
            set(haxes,'Fontsize',18)
            
        case 'M, Dipole character'
            plot(val,M,'parent',haxes,'marker','o',...
                'Markersize',10,'linewidth',3,'linestyle','none')
                        
            xlabel(haxes,'Strain %','fontsize',16)
            ylabel(haxes,'Dipole character M','fontsize',16)
            set(haxes,'Fontsize',18)
            

        case 'Outer cut-off radius'
            Re=M./rho.^.5;

            plot(val,Re,'parent',haxes,'marker','o',...
                'Markersize',10,'linewidth',3,'linestyle','none')
                        
            xlabel(haxes,'Strain %','fontsize',16)
            ylabel(haxes,'Outer cut-off radius','fontsize',16)
            set(haxes,'Fontsize',18)
            
    case '.                  '
            plot(val,rho.*log(M./(rho).^.5),'parent',haxes,'marker','o',...
                'Markersize',10,'linewidth',3,'linestyle','none')
                        
            xlabel(haxes,'Strain %','fontsize',16)
            ylabel(haxes,'Dipole character M','fontsize',16)
            set(haxes,'Fontsize',18)
end


grid(haxes,'on')

end