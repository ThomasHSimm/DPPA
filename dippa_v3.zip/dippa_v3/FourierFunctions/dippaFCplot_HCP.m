function dippaFCplot(val, haxes, dppFCpref)
%% plots of FCs 
%% THS 2016 dppa

%
load([cd,'/0. variables/FC.mat'],'FC',...
    'selected','L','delK')

% load([cd,'/0. variables/FC_Iall.mat'])
% load([cd,'/0. variables/fit.mat'],'aa')
load([cd,'/0. variables/phases.mat'],'dsettings')
load([cd,'/0. variables/FCresStr.mat'],'FCres')
load([cd,'/0. variables/all_I.mat'],'all_I')

col = { 'ro'; 'yo'; 'go'; 'bo'; 'mo'; 'ko' ;
        'rs'; 'ys'; 'gs'; 'bs'; 'ms'; 'ks' ; 
        'r<'; 'y<'; 'g<'; 'b<'; 'm<'; 'k<' ;
        'r>'; 'y>'; 'g>'; 'b>'; 'm>'; 'k>' ;
        'rx'; 'yx'; 'gx'; 'bx'; 'mx'; 'kx' ;
        'rv'; 'yv'; 'gv'; 'bv'; 'mv'; 'kv' ;
        'r+'; 'y+'; 'g+'; 'b+'; 'm+'; 'k+' ;};
% number of n-values used
nmax = dppFCpref.sample_n;
val
% turn hold to off
hold(haxes,'off')
%% different plot options
switch val 
    case '1. FCs'
        for bh=1:length(selected)
            plot(L,FC(1:length(L),selected(bh)),col{bh},...
                'markersize',10,'linewidth',2,'parent', haxes,'linestyle','-'),
            hold(haxes,'on')
        end
        xlim(haxes,[0 L(nmax)*1.2])
        
%         plotFCfit( nmax, haxes, FCres, dppFCpref, L)
        
    case '2. FC fit'
        % plot FCs
        for bh=1:length(selected)
            plot(L,FC(1:length(L),selected(bh)),col{bh},...
                'markersize',10,'linewidth',2,'parent', haxes)
            hold(haxes,'on')
        end
        type_strain = 'Grom';
        % plot FC fit results
        plotFCfit( nmax, haxes, FCres, dppFCpref, L, col,type_strain)
        
     
    case '3. WA plot'
        disp('use external function')
        
    case '4. Size FCs'   
        gs = FCres.gs;
        type_size = dppFCpref.type_size;
        AS = get_sizeFCs(gs, L, type_size, length(L));
        plot(L(1:length(all_I)), exp(all_I(:,2)),'marker','s','markerfacecolor','b','color','k','markersize',10,'linestyle','none','parent',haxes)
        hold(haxes,'on')
        plot(L(1:nmax), AS(1:nmax),'parent',haxes,'linewidth',3,'color','b')
        xlabel(haxes,'Fourier Length (x 10^-^1^0m)')
        ylabel(haxes,'Size Fourier Coefficients')
        
    case '5. Strain FCs'   
        type_strain = dppFCpref.type_strain;
        
        if strcmp(type_strain, 'Grom')==1
            rho = FCres.rhoGrom;
            M = FCres.MGrom;   
            
        elseif strcmp(type_strain, 'Wilk')==1
            rho = FCres.rhoWilk;
            M = FCres.MWilk;
            
        end

        g = FCres.g;
        C = FCres.C;
        B = FCres.B;
        Chk0 = FCres.chk0;
        
        for j=1:length(g)
            plot(L(1:length(all_I)), exp(-all_I(:,3)*(B*g(j)^2*C(j))),...
                'marker',col{j}(2),'markerfacecolor',col{j}(1),'color','k','markersize',10,'linestyle','none','parent',haxes)
            hold(haxes,'on')
        end
        
        [AD, ~] = get_strainFCs(rho, M, B, L, g, C, type_strain);
        for j=1:length(g)
            plot(L(1:nmax), AD(1:nmax,j),...
                'parent',haxes,'color',col{j}(1),'linewidth',3)
        end
        
        xlabel(haxes,'Fourier Length (x 10^-^1^0m)')
        ylabel(haxes,'Strain Fourier Coefficients')
        
        ylim(haxes, [0 1.1])
        
    case '6. Kriv-Wilk plot'     
        type_strain = dppFCpref.type_strain;
        
        if strcmp(type_strain, 'Grom')==1
            rho = FCres.rhoGrom;
            M = FCres.MGrom;       
        elseif strcmp(type_strain, 'Wilk')==1
            rho = FCres.rhoWilk;
            M = FCres.MWilk;
        end

        g = FCres.g;
        C = FCres.C;
        B = FCres.B;
        Chk0 = FCres.chk0;
        
        [~, ADnocg] = get_strainFCs(rho, M, B, L, g, C, type_strain);
        
        XL_m=( all_I(1:nmax,3)' )./L(1:nmax).^2;

        semilogx(L(1:nmax), XL_m,'ok','parent',haxes,...
            'markersize',10,'linewidth',3),hold
        hold(haxes,'on')
        plot(L, ADnocg, 'parent',haxes,...
            'color','g','markersize',10,'linewidth',3)
        
        xlim(haxes, [L(1)*.8 , L(nmax)*10 ])
        ylim(haxes, [0 , max(XL_m)*1.2])
        
    case '8. Intensity values'      
        disp('????')
end

grid(haxes,'on')
set(haxes,'fontsize',17)
%          set(handles.plotres_l,'value',1)

end

%%
function plotFCfit( nmax, haxes, FCres, dppFCpref, L, col, type_strain)

% sizestrain = 'logWA';%'linWA','altrn','sfeld'
load([cd,'/0. variables/phases.mat'],'dsettings')
type_sizestrain = dppFCpref.type_sizestrain;
% type_strain = dppFCpref.type_strain;
type_size = dppFCpref.type_size;
% allindi = dppFCpref.allindi;

selected = dppFCpref.selected;

a3 = FCres.a3;

switch type_sizestrain
    case 'logWA'
        [A, ~, ~]=get_WAFCs(FCres, L,type_size, type_strain, type_sizestrain);
        lnA = log(A); 
        title_ = 'Fourier Coefficients Using fit of different n values --log WA method';
        
    case 'linWA'
        [A, ~, ~]=get_WAFCs(FCres, L,type_size, type_strain, type_sizestrain);
        lnA = log(A);
        title_ = 'Fourier Coefficients Using fit of different n values --linear WA method';
        
    case 'altrn'

           disp('do elsewhere')
           
    case 'none'
        [A, ~, ~]=get_WAFCs(FCres, L,type_size, type_strain, type_sizestrain);
        lnA = log(A);
        title_ = 'Fourier Coefficients Using fit of different n values --log WA method no size';
end

for ii=1:size(lnA,2)
    plot(L,exp(lnA(:,ii)),'parent',haxes,'color',col{ii}(1),'linewidth',2)
end

legend(haxes, num2str(dsettings(1,1).index(selected,:)));
ylabel(haxes,'Fourier Coefficients','fontsize',15)
        
xlim(haxes, [0 nmax*a3*1.3])
ylim(haxes, [0 1])

end

%%
function [AA_ lam]=all_logWA(L, FCres, strain, sizestrain, allindi)
        
lam=[FCres.q, FCres.gs*1e4, FCres.rhoWilk*1e-4, FCres.MWilk, FCres.a3];
B = FCres.B;
g = FCres.g;
C = FCres.C;

for na=1:length(L) 
    switch allindi
        case 'ind'
        
            switch strain
                case 'Grom'
                
                    
                case 'Wilk'
                    
                    
            end
            
        case 'all'
        
            AA_(na,:)=exp( log(ASlognormSc([lam(2),lam(5)],L(na))) - L(na)^2*B*Wilkens3([ (lam(4)/lam(3).^.5) , lam(3)],L(na) ) *g.^2.*C  );

    end

end

if min(C)<0;
    AA_=inf*AA_;
end

end

%%
function [AA_ lam]=all_linWA(L, FCres)
        
lam=[FCres.q, FCres.gs, FCres.rho*1e-4, FCres.M, FCres.a3];
B = FCres.B;
g = FCres.g;
C = FCres.C;

for na=1:length(L) 

    AA_(na,:)=(   exp(-L(na)/lam(2) )*(1 - L(na)^2*B*Wilkens3([ (lam(4)/lam(3).^.5) , lam(3)],L(na) ) *g.^2.*C  ));

end

if min(C)<0;
    AA_=inf*AA_;
end

end
%%
function [lnAA lam]=allF_tsf(lam, L)
                
    for nn=1:length(L)
%                     C=0.2*(1-lam(nn,1)*H2);
        lnAA(nn,:) = (lam(nn,2)) - B*real(lam(nn,3))*g.^2.*C ;%indivF(lam(nn,:), L(nn));
    end
end

function [lnFC lam]=allF_lin(lam, L)
    for nn=1:length(L)
        lnFC(nn,:) =log( exp(lam(nn,2)) - exp(lam(nn,2))*B*real(lam(nn,3))*g.^2.*C );
    end

end 