function join_XRDs

go=1;h=1;
[FileNameAll_,PathName] = uigetfile('*.xy','Select all data files',...
        'D:\MATLAB\DPPAv2\2. data\XRD\exports\','MultiSelect', 'on');
goall=menu('Select All file?',FileNameAll_);

FileNameAll{1} = FileNameAll_{goall};
hh=2;
for h=1:length(FileNameAll_)
    if h~=goall
        FileNameAll{hh} = FileNameAll_{h};
        
        hh=hh+1;
    end
end

for h=1:length(FileNameAll)
    
    FileName = FileNameAll{h};
%     PathName = PathNameAll{h};
    
    da = importdata([PathName,'\',FileName]);
    data{h}=da.data;
    
    timeperstepSTR = da.textdata{1};
    pos = find(timeperstepSTR=='"');
    timeperstep(h)= str2double(timeperstepSTR(pos(end-1)+1:pos(end)-1));

    if h==1
       FileNameOut = [FileName(1:find(FileName=='.')-1),'comb']; 
    end
    
end

for n=1:length(data)
    if n==1
        dataALL = data{n};
%         data{n}(:,2)=1000*data{n}(:,2)/timeperstep(n);
    else
       pkstrt = data{n}(1,1);
       pkend = data{n}(end,1);
       
       posabs = (dataALL(:,1)-pkstrt); posabs(posabs>0) = 100;posabs=abs(posabs);
       posstart = find( posabs == min(posabs) );
       
       posabs = (dataALL(:,1)-pkend);posabs(posabs<0) = 100;posabs=abs(posabs);
       posend = find( posabs == min(posabs) );
       
       dataAdj = dataALL(posstart,2) / data{n}(1,2);
       data{n}(:,2)=data{n}(:,2)*dataAdj;
       
       dataALL = [dataALL(1:posstart,:); data{n}; dataALL(posend:end,:);];
    end
    
end
fnom = [PathName,'\',FileNameOut,'.dat'];
save(fnom,'dataALL','-ASCII')
end
