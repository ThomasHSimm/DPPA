function anew=onepeak_asymm(tth,F,astart)
if astart(4,end)~=0
    fpos=astart(4,end);
end
lb=zeros(size(astart));
ub=inf*ones(size(astart));
lb(1,end)=-inf;
lb(2,end)=-inf;
lb(3,end)=-1e-50;
ub(3,end)=1e-50;

if size(astart,2)>2
lb(2,1:end-1)=.01*astart(2,1:end-1);
ub(2,1:end-1)=100*astart(2,1:end-1);

lb(4,1:end-1)=0;
ub(4,1:end-1)=1.3;
lb(6,1:end-1)=0;
ub(6,1:end-1)=1.3;

ub(1,1:end-1)=1.0001*astart(1,1:end-1);
lb(1,1:end-1)=.9999*astart(1,1:end-1);

lb(3,1:end-1)=.1*astart(3,1:end-1);
ub(3,1:end-1)=10*astart(3,1:end-1);
lb(5,1:end-1)=.1*astart(3,1:end-1);
ub(5,1:end-1)=10*astart(3,1:end-1);


end

lb(1,fpos)=astart(1,fpos)-5e-3;
ub(1,fpos)=astart(1,fpos)+5e-3;
lb(2,fpos)=0;
ub(2,fpos)=inf;
ub(3,fpos)=1e-02;
lb(3,fpos)=0;
ub(4,fpos)=1.3;
lb(4,fpos)=0;
ub(5,fpos)=1e-02;
lb(5,fpos)=0;
ub(6,fpos)=1.3;
lb(6,fpos)=0;

for nc=1:size(ub,2)
zeroaas=find(ub(:,nc)-lb(:,nc)==0);
ub(zeroaas,nc)=1e-05;
lb(zeroaas,nc)=-1e-05;
end
options=optimset('tolx',1e-5,'tolf',1e-5);
[anew resnorm residual exitflag]=lsqcurvefit(@pv_tv_asymm, astart, tth,F,lb,ub,options) ;


 
end
 
            