function [f , lam]=pk_voigt2(x,lam)
%% function to calculate single voigt peak % 5-2-94 SMB (Bren@SLAC.stanford.edu)
%% THS 2016 dppa

f=zeros(size(x));
delx=x-lam(1);
gau= exp(-(delx ./(0.600561*lam(3))).^2);
lor= 1+ (delx ./(0.5*lam(3))).^2;
f= f+ lam(2) .*((lam(4)./lor)+((1-lam(4)).*gau));



%%%lam(1) ==x0
%%%lam(2) ==PHI0  intensity
%%%lam(3) ==FWHM
%%%lam(4) ==neta (0->1 gauss->lorentz)
%%%%f intensity
%%%%x twotheta values

% iff=real(fft(f,10000))/max(fft(f,10000));
% plot(iff,'--go')




end