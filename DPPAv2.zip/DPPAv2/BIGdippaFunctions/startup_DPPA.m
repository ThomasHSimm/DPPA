function startup_DPPA(dppapref_,nowttosee)
if nargin==0
    dppapref_='fcc'
end
if nargin==1%%When loading results
    dppapref = dppapref_;
    alpha2 = dppapref.alpha2 ;
    bcg2peak = dppapref.bcg2peak;
    tube = dppapref.tube;
    wavelen = dppapref.wavelen;
    identa = dppapref.identa ;
    datainstr = dppapref.datainstr;
    sizfit = dppapref.sizfit;
    logplot = dppapref.logplot;
    
else%% preset values
    if strcmp(dppapref_,'fcc')==1
        alpha2=0;
        bcg2peak=0.02;
        tube='Co';
        wavelen=1.5425;
        identa='6.8% SS';
        datainstr = 'Sampl';%'Instr'
        sizfit = 0.02;
        logplot = 1;
    elseif strcmp(dppapref_,'hcp')==1
        alpha2=1;
        bcg2peak=0.02;
        tube='None';
        wavelen=0.3983;
        identa='Ti64 X';
        datainstr = 'Sampl';%'Instr'
        sizfit = 0.02;
        logplot = 1;
    end
end
        dppapref.alpha2 =alpha2;
        dppapref.bcg2peak =bcg2peak;
        dppapref.tube =tube;
        dppapref.wavelen =wavelen;
        dppapref.identa =identa;
        dppapref.datainstr = datainstr;
        dppapref.sizfit = sizfit;
        dppapref.logplot = logplot;
        
setappdata(0,'dppapref',dppapref)

setDPPApref('identa',identa);
setDPPApref('alpha2',alpha2);
setDPPApref('bcg2peak',bcg2peak);       
setDPPApref('tube',tube);
setDPPApref('wavelen',wavelen);
setDPPApref('datainstr',datainstr);
setDPPApref('sizfit',sizfit);
setDPPApref('logplot',logplot);

end