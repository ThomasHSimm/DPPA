function setDPPApref(pref,value)

group = getappdata(0,'dppapref');

group.(pref) = value;

setappdata(0,'dppapref',group);
