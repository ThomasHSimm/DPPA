function F= pv_tv_asymm(lam0, x)
            global alpha2
            len=size(lam0,2);
            npks=(len-1);
            F=zeros(size(x));
            
            
            for n=1:npks

                lam(1:6)=lam0(:,n);
%                 if alpha2==1
%                 [fia lam]=pk_voigt2(x,lam); %if no alpha2 present
%                 elseif alpha2==0
                [fia ]=pk_alpha_asymm(x,lam);
%                 end
                F=F+fia;
            end

            backgd =  lam0(1,len) + x*lam0(2,len) + lam0(3,len)*x.^2;
            F=F+backgd;

            end