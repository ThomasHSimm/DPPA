function F= pv_tv_aa(lam0, x)
%% fitting function for peaks
%% THS 2016 dppa

alpha2=getDPPApref('alpha2');

len=size(lam0,2);
npks=(len-1);
F=zeros(size(x));
if npks>0
for n=1:npks
    
    lam=lam0(:,n);
    
    if length(lam)==4
        if alpha2==1
            [fia , lam]=pk_voigt2(x,lam); %if no alpha2 present
        elseif alpha2==0
            [fia,  lam]=pk_alpha(x,lam);
        end
        F=F+fia;
    else
        
        [fia ]=pk_alpha_asymm(x,lam);

        F=F+fia;
    end
end
end

backgd =  lam0(1,len) + x*lam0(2,len) + lam0(3,len)*x.^2;
F=F+backgd;
