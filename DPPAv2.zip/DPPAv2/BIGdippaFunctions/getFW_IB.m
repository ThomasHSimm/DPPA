function delK = getFW_IB(FWtype,selected)
%%
load([cd,'/0. variables/fit.mat'],'aa','aabcg')
load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')



%%
switch FWtype
    
    case 'FW'
        if size(aa,1)==4
            delK_R = aa(3,selected) ;
        else
            delK_R = 0.5* (aa(3,selected) +...
                    aa(5,selected) );
        end
        
        g_(:,1)=aa(1,selected);
        g_I(:,1)=aa_I(1,:);
        %% find position of instrumental
        posI=zeros(1,length(selected));
        for ii=1:length(g_)
           posI(ii) = find( abs(g_(ii) - g_I) == min( abs(g_(ii) - g_I) ) );
        end
            %   get fw normaliseif asymmetric    
        if size(aa_I,1)==4
            delK_I = aa_I(3,posI) ;
        else
            delK_I = 0.5* (aa_I(3,posI) +...
                    aa_I(5,posI) );
        end
        
        delK = delK_R - delK_I;
                
    case 'IBanaly'
        
        
    case 'IBdata'
        


end