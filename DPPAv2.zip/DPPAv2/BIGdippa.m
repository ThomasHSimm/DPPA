function varargout = BIGdippa(varargin)
% BIGDIPPA MATLAB code for BIGdippa.fig
%      BIGDIPPA, by itself, creates a new BIGDIPPA or raises the existing
%      singleton*.
%
%      H = BIGDIPPA returns the handle to a new BIGDIPPA or the handle to
%      the existing singleton*.
%
%      BIGDIPPA('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in BIGDIPPA.M with the given input arguments.
%
%      BIGDIPPA('Property','Value',...) creates a new BIGDIPPA or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before BIGdippa_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to BIGdippa_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help BIGdippa

% Last Modified by GUIDE v2.5 07-Aug-2016 18:43:29

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @BIGdippa_OpeningFcn, ...
                   'gui_OutputFcn',  @BIGdippa_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before BIGdippa is made visible.
function BIGdippa_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to BIGdippa (see VARARGIN)

% Choose default command line output for BIGdippa
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes BIGdippa wait for user response (see UIRESUME)
% uiwait(handles.figure1);
path('BIGdippaFunctions',path)
path('FourierFunctions',path)
imshow('big-dipper.png','parent',handles.axes1)
imshow('Billetsandbillets2.png','parent',handles.bcg_p)
startup_DPPA('fcc',0)


% --- Outputs from this function are returned to the command line.
function varargout = BIGdippa_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in slider_l.
function slider_l_Callback(hObject, eventdata, handles)
% hObject    handle to slider_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns slider_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from slider_l

%% choose which part of dippa to access

contents = cellstr(get(hObject,'String'));
conchoose = contents{get(hObject,'Value')};
switch conchoose
    case 'Settings'
        set(handles.fit_p,'visible','off')
        set(handles.settings_p,'visible','on')
        set(handles.IB_p,'visible','off')
        set(handles.loadfit_p,'visible','off')
        set(handles.IBsettings_p,'visible','off')
    case 'Fit'
        set(handles.fit_p,'visible','on')
        set(handles.loadfit_p,'visible','on')
        set(handles.settings_p,'visible','off')
        set(handles.IB_p,'visible','off')
        set(handles.IBsettings_p,'visible','off')
    case 'IB Analysis'
        set(handles.fit_p,'visible','off')
        set(handles.settings_p,'visible','off')
        set(handles.IB_p,'visible','on')
        set(handles.loadfit_p,'visible','on')
        set(handles.IBsettings_p,'visible','off')
        startup_WH
        
        startup_WHpref
        set(handles.WHq_t,'string',2)
        
        
    case 'Fourier'
        
end

%load stuff
load([cd,'/0. variables/phases.mat'],'dsettings')
load([cd,'/0. variables/data.mat'],'data')

%update GUI
switch conchoose
    case 'Settings'

    case 'Fit'
%% 

disp('REMOVE THIS!! line 124 slider case fit')
    xxx=1;
    for x=1:length(dsettings)
   
            crys=dsettings(x).cstruct(1:3);
            lat1=dsettings(1,x).lat1;
            lat2=dsettings(1,x).lat2;
        
        for xx=1:length(dsettings(1,x).index)
            
            aa(1,xxx)=1./dspacing_dippa(dsettings(x).index(xx,:),crys,lat1,lat2  );
%               aa(1,xxx)=1/settings(1,x).d(xx);
          if size(data,1)~=0
              adjtth=abs( data(:,1) - aa(1,xx) - 1e-03);
              maxpos=find(adjtth==min(adjtth));
              adjtth=abs( data(:,1) - aa(1,xx) + 1e-03);
              minpos=find(adjtth==min(adjtth));
              aa(2,xxx)=max(data(minpos:maxpos,2));
          end
          aa(3,xxx)=1e-03;
          aa(4,xxx)=.4;
          xxx=xxx+1;
        end      
        
    end
    aabcg=0*aa(1:2,1:end-1); 
%%
    save([cd,'/0. variables/fit.mat'],'aa','aabcg')

        set(handles.data_instr_b,'string','Sample');
        setDPPApref('datainstr','Sampl')
        
        set(handles.indexres_l,'value',1);
        set(handles.indexres_l,'string',num2str(dsettings(1,1).index) )
        set(handles.xp_t,'string', num2str(aa(1,1)))
        for n=1:length(dsettings)
            phases{n}=dsettings(1,n).name;
        end
        set(handles.phaseres_l,'value',1)
        set(handles.phaseres_l,'string',phases)
        set(handles.I_t,'string', num2str(aa(2,1)))
        set(handles.fw_t,'string', num2str(aa(3,1)))
        set(handles.neta_t,'string', num2str(aa(4,1)))
        set(handles.bcg1_t,'string',num2str(aa(1,end)))
        set(handles.bcg2_t,'string',num2str(aa(2,end)))
        set(handles.bcg3_t,'string',num2str(aa(3,end)))
    case 'IB Analysis'
        set(handles.WHindex_l,'value',1);
        set(handles.WHindex_l,'string',num2str(dsettings(1,1).index) )
        
        set(handles.WHselected_l,'value',1);
        set(handles.WHselected_l,'string',num2str(dsettings(1,1).index) )
        
        
        
    
end


        

    

% --- Executes during object creation, after setting all properties.
function slider_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in phase_l.
function phase_l_Callback(hObject, eventdata, handles)
% hObject    handle to phase_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns phase_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from phase_l

%% choose the phase

if exist([cd,'/0. variables/phases.mat'],'file')~=0
phase=get(hObject,'value');

load([cd,'/0. variables/phases.mat'],'dsettings')


set(handles.lat1_t,'string',dsettings(1,phase).lat1)
set(handles.lat2_t,'string',dsettings(1,phase).lat2)
set(handles.symm_l,'string',dsettings(1,phase).cstruct)
set(handles.index_l,'value',1)
set(handles.index_l,'string',num2str(dsettings(1,phase).index))

else
   menu('Create settings first') 
end
% --- Executes during object creation, after setting all properties.
function phase_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to phase_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in symm_l.
function symm_l_Callback(hObject, eventdata, handles)
% hObject    handle to symm_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns symm_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from symm_l

%% the crystal structure of the phase

mnuopt={'Cancel';'FCC';'BCC';'HCP'};
mnuc=menu('Choose crystal structure ',mnuopt);


if mnuc~=1
    cstruct=mnuopt{mnuc};
    set(hObject,'String',cstruct)
    load([cd,'/0. variables/phases.mat'],'dsettings');
    val=get(handles.phase_l,'value');
    dsettings(val).cstruct=cstruct;
    save([cd,'/0. variables/phases.mat'],'dsettings');

end

% --- Executes during object creation, after setting all properties.
function symm_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to symm_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in index_l.
function index_l_Callback(hObject, eventdata, handles)
% hObject    handle to index_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns index_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from index_l

load([cd,'/0. variables/data.mat'],'data')
load([cd,'/0. variables/phases.mat'],'dsettings')

plotindex_b_Callback(hObject, eventdata, handles)

valuu = get(hObject,'Value') ;
phase = get(handles.phase_l,'Value') ;

xp=1./dsettings(1,phase).d(valuu);


col1={'b';'r';'g';'k';};
col2={'o';'s';'v';'>';};

hold on
plot(xp,(min(abs(data(:,2)))+1)*.6,...
    'color','k','marker','^','markersize',10,'parent',handles.axes1)
plot(xp,max(data(:,2))*3,...
    'color','k','marker','v','markersize',10,'parent',handles.axes1)
hold off

% --- Executes during object creation, after setting all properties.
function index_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to index_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in plusphase_b.
function plusphase_b_Callback(hObject, eventdata, handles)
% hObject    handle to plusphase_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%% add a new phase

opto = {'Add';'New Material'};
mnu = menu('Add phase to existing Material data? Or create new Material?',opto);
optos = opto{mnu};

switch optos
    case 'Add'
    %open settings 
    load([cd,'/0. variables/phases.mat'])
    % and add to next position
    LL=length(dsettings)+1;
    dsettings(1,LL).id=dsettings(1,1).id;
    
    NAME=get(handles.phasenom_t,'string');
    % make length of name 6 characters
    LEN=length(NAME);SP='      ';
    if LEN<6; NAME=[NAME,SP(1:6-LEN)];elseif LEN>6;NAME=NAME(1:6);end
    dsettings(1,LL).name=NAME;
    for n=1:LL;NOM{n}=dsettings(1,n).name;end
    set(handles.phase_l,'string',NOM)
    set(handles.phase_l,'value',LL)
    
    dsettings(1,LL).index=[1 0 0];
    dsettings(1,LL).d=1;
    dsettings(1,LL).cstruct=dsettings(1,1).cstruct;
    set(handles.index_l,'string',num2str(dsettings(1,LL).index))

save([cd,'/0. variables/phases.mat'],'dsettings')

    case 'New Material'
    phasenom_t_Callback(hObject, eventdata, handles)
end


function phasenom_t_Callback(hObject, eventdata, handles)
% hObject    handle to phasenom_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of phasenom_t as text
%        str2double(get(hObject,'String')) returns contents of phasenom_t as a double


% --- Executes during object creation, after setting all properties.
function phasenom_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to phasenom_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in plusfind_b.
function plusfind_b_Callback(hObject, eventdata, handles)
% hObject    handle to plusfind_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%% add an entry manually
%load settings
load([cd,'/0. variables/phases.mat'])
%get existing index
index_all=str2num( get(handles.index_l,'string') );
nn=get(handles.phase_l,'value');
indexlen=size(index_all,1);
% plotdata and get peak position

mnu = menu('Enter on Figure?','Yes','No');
if mnu==1
    load([cd,'/0. variables/data.mat'],'data')
    logplot=get(handles.logplot_b,'value');
      if logplot==0
            plot(data(:,1),data(:,1),'color','k'),
        else
            semilogy(data(:,1),data(:,2),'color','k'),
      end
        
    [x y]=ginput(1);
    dsettings(1,nn).d(indexlen+1)=1/x;
    dsettings(1,nn).index(indexlen+1,:)=[0 0 0];
    indexadd=[0 0 0];

    %update GUI and save
    index_all=[index_all;indexadd];
    set(handles.index_l,'string',num2str(index_all) )

    save([cd,'/0. variables/phases.mat'],'dsettings')

end

function index_t_Callback(hObject, eventdata, handles)
% hObject    handle to index_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of index_t as text
%        str2double(get(hObject,'String')) returns contents of index_t as a double


% --- Executes during object creation, after setting all properties.
function index_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to index_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function lat1_t_Callback(hObject, eventdata, handles)
% hObject    handle to lat1_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of lat1_t as text
%        str2double(get(hObject,'String')) returns contents of lat1_t as a double

%% unit cell a dimension
lat1 = str2double(get(hObject,'String') );
load([cd,'/0. variables/phases.mat'],'dsettings');
val=get(handles.phase_l,'value');
dsettings(val).lat1=lat1;

% calculate peak positions
xp=[];
for n=1:length(dsettings)
    symm=dsettings(1,n).cstruct(1:3);
    
    % get lat1 and lat2
        lat1=dsettings(1,n).lat1;
        lat2=dsettings(1,n).lat2;
    
    lambda = getDPPApref('wavelen');
    %find d-spacing
    
    xp=[xp;1./dspacing_dippa(dsettings(1,n).index,symm,lat1,lat2)'];
    dsettings(n).d=1./xp;
end


save([cd,'/0. variables/phases.mat'],'dsettings');

% --- Executes during object creation, after setting all properties.
function lat1_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lat1_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in minusindex_b.
function minusindex_b_Callback(hObject, eventdata, handles)
% hObject    handle to minusindex_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%% remove an index
% load settings
load([cd,'/0. variables/phases.mat'],'dsettings')
%find which index to remove

indexval = get(handles.index_l,'value');
phaseno = get(handles.phase_l,'value');

index_all = dsettings(phaseno).index;

d_old = dsettings(phaseno).d;

bb = 1:1:length(d_old);
newbb = bb(bb~= indexval);

index_new = index_all(newbb,:);
d_new = d_old(newbb);

% there are no indices left
if length(d_new)<1
    index_new=[1 0 0];
    d_new = 1;
    disp('cannot delete all')
end
%and change index in GUI and settings
set(handles.index_l,'value',1)
set(handles.index_l,'string',num2str(index_new) )
dsettings(phaseno).index=index_new;
dsettings(phaseno).d=d_new;

save([cd,'/0. variables/phases.mat'],'dsettings')


% --- Executes on button press in addindex_b.
function addindex_b_Callback(hObject, eventdata, handles)
% hObject    handle to addindex_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%% add a new hkl index

load([cd,'/0. variables/phases.mat'],'dsettings')
 
% nostruct=get(handles.symm_l,'value');
phase=get(handles.phase_l,'value');

%existing indices
index_all=str2num( get(handles.index_l,'string') );

%new index
indexadd=str2num( get(handles.index_t,'string') );

% if just want to add one by ginput without index
if isempty(indexadd)==1;
    plusfind_b_Callback(hObject, eventdata, handles)
else
    sym = dsettings(phase).cstruct;
    d = dsettings(phase).d;
    lat1 = dsettings(phase).lat1;
    lat2 = dsettings(phase).lat2;
    dnew = dspacing(indexadd, sym, 1,lat1, lat2);
    index_all=[index_all;indexadd];
    d_all = [d, dnew];
    
    dsettings(phase).index=index_all;
    dsettings(phase).d = d_all;
    
    set(handles.index_l,'string',num2str(index_all) )
    
    
    save([cd,'/0. variables/phases.mat'],'dsettings')
end

function lat2_t_Callback(hObject, eventdata, handles)
% hObject    handle to lat2_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of lat2_t as text
%        str2double(get(hObject,'String')) returns contents of lat2_t as a double

%% unit cell a dimension
lat2 = str2double(get(hObject,'String')) ;
load([cd,'/0. variables/phases.mat'],'dsettings');
val=get(handles.phase_l,'value');
dsettings(val).lat2=lat2;

% calculate peak positions
xp=[];
for n=1:length(dsettings)
    symm=dsettings(1,n).cstruct(1:3);
    
    % get lat1 and lat2
        lat1=dsettings(1,n).lat1;
        lat2=dsettings(1,n).lat2;
    
    lambda = getDPPApref('wavelen');
    %find d-spacing
    
    xp=[xp;1./dspacing_dippa(dsettings(1,n).index,symm,lat1,lat2)'];
    dsettings(n).d=1./xp;
end


save([cd,'/0. variables/phases.mat'],'dsettings');


% --- Executes during object creation, after setting all properties.
function lat2_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lat2_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function name_t_Callback(hObject, eventdata, handles)
% hObject    handle to name_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of name_t as text
%        str2double(get(hObject,'String')) returns contents of name_t as a double


% --- Executes during object creation, after setting all properties.
function name_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to name_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in newphase_b.
function newphase_b_Callback(hObject, eventdata, handles)
% hObject    handle to newphase_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.phase_l,'value',1)
set(handles.index_l,'value',1)
set(handles.symm_l,'value',1)

go=input('Do you want to enter new material details y/n ? (Will delete current details):       ','s');
if go(1)=='y' || 'Y'
    str1=input('Enter name of material    ','s');
    dsettings(1).id=str1;
    num=input('Enter number of different crystal phases       ');
    for n=1:num
        str1=input(['Enter name of phase ',num2str(n),'   '],'s');
        dsettings(n).name=str1;
        num2=input('Enter crystal structure, 1-fcc, 2-bcc, 3-hexagonal   ');
        symms = {'FCC';'BCC';'HCP'};
        dsettings(n).cstruct=symms{num2};
        str1=input('Enter lattice parameter   ');
        dsettings(n).lat1=str1;
        
        num3=input('Enter indices of peaks (e.g. [1 1 1;2 0 0]  ');
        dsettings(n).index=num3;
        if num2==3
            str1=input('Enter 2nd lattice parameter (c)   ','s');
            dsettings(n).lat2=str1;
            dsettings(n).d=dspacing(dsettings(n).index, 'hex', 1,dsettings(n).lat1, dsettings(n).lat2);
        else
            dsettings(n).lat2=0;
            dsettings(n).d=dspacing(dsettings(n).index, 'cub', 1,dsettings(n).lat1, dsettings(n).lat2);
        end
    end
    yorno=input('Is this okay?','s');
    if yorno(1)=='y' || 'Y'
    save([cd,'/0. variables/phases.mat'],'dsettings')
    end

for n=1:length(dsettings)
    phas{n}=dsettings(n).name;
    sym{n}=dsettings(n).cstruct;
end
set(handles.phase_l,'string',phas)
set(handles.phase_l,'value',1)
set(handles.symm_l,'string',sym)
set(handles.lat1_t,'string',dsettings(1).lat1)
set(handles.name_t,'string',dsettings(1).id)
set(handles.index_l,'string',num2str(dsettings(1).index))

end


% --- Executes on button press in logplot_b.
function logplot_b_Callback(hObject, eventdata, handles)
% hObject    handle to logplot_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of logplot_b

%% Whether to plot log y or not 
logplot = get(hObject,'value') ;
setDPPApref('logplot',logplot);

% --- Executes on button press in minusphase_b.
function minusphase_b_Callback(hObject, eventdata, handles)
% hObject    handle to minusphase_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in plotindex_b.
function plotindex_b_Callback(hObject, eventdata, handles)
% hObject    handle to plotindex_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%% plot settings Sample data

%loads
load([cd,'/0. variables/data.mat'],'data')
load([cd,'/0. variables/phases.mat'],'dsettings')

haxes = handles.axes1;

hold(haxes,'off')

%plot data
logplot=get(handles.logplot_b,'value');
if logplot==1
    semilogy(data(:,1),data(:,2),'parent',...
        handles.axes1,'color','k','linewidth',2),
else
    plot(data(:,1),data(:,2),'parent',...
        handles.axes1,'color','k','linewidth',2),
end
hold(haxes,'on')
%get peak position
xp=[];
for n=1:length(dsettings)
    xp{n}=1./dsettings(1,n).d;
end

col1={'b';'r';'g';'k';};
col2={'o';'s';'v';'>';};

for j=1:length(dsettings)
    for n=1:length(xp{j})
    plot([xp{j}(n),xp{j}(n)],[(min(abs(data(:,2)))+1)*.6;max(data(:,2))*3],...
        'color',col1{j},'marker',col2{j},'parent',handles.axes1)
    end
end


% grid on
set(handles.axes1, 'fontsize',16)
grid(handles.axes1,'on')



function wav_t_Callback(hObject, eventdata, handles)
% hObject    handle to wav_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of wav_t as text
%        str2double(get(hObject,'String')) returns contents of wav_t as a double


% --- Executes during object creation, after setting all properties.
function wav_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to wav_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in alpha2_b.
function alpha2_b_Callback(hObject, eventdata, handles)
% hObject    handle to alpha2_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of alpha2_b

val = get(hObject,'Value');
setDPPApref('alpha2',val);
% --- Executes on button press in loadset_b.
function loadset_b_Callback(hObject, eventdata, handles)
% hObject    handle to loadset_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%% LOAD SETTINGS

%choose whether to load settings or instr
instr_or_set =menu( 'What would you like to load?','Materials info','instrumental','both');

if instr_or_set==1%material settings
    %% if settings
    %open file location
    [file, path] = uigetfile({'*.mat';},...%file type
          'find Settings file',...%quote
          [cd,'\1. settings\']);%location
    %load it  
    load([path,file],'dppapref','dsettings');
    
    %update prefs
    startup_DPPA(dppapref)
    
    %set values to GUI
    set(handles.name_t,'string',dsettings(1,1).id)
    set(handles.lat1_t,'string',dsettings(1,1).lat1)
    set(handles.lat2_t,'string',dsettings(1,1).lat2)
    set(handles.symm_l,'string',dsettings(1,1).cstruct)
    
    set(handles.wav_t,'string',num2str(getDPPApref('wavelen')))
    if dppapref.alpha2 == 0%are there alpha2s?
        set(handles.alpha2_b,'value',1);
    else
        set(handles.alpha2_b,'value',0);
    end
    
    set(handles.index_l,'string',num2str(dsettings(1,1).index))
    
    for n=1:length(dsettings)
        noma{n}=dsettings(n).name;
    end
        
    set(handles.phase_l,'string',cellstr(noma))
    if exist('dsettings')==0 || size(dsettings,1)==0;
        disp('Error: no settings')
    else
        save([cd,'/0. variables/phases.mat'],'dsettings')
    end
    
elseif instr_or_set==2
    %% if instrumental
    [file path] = uigetfile({'*.mat'},'Select File to open');
    load([path,file],'aa_I','aabcg_I','data_I');
    if exist('aabcg_I')==0 || size(aabcg_I,1)==0;
        disp('instr. bcg dont exist creating variables')
        aabcg_I=zeros(2,length(aa_I)-1);
    end
    
    if exist('aa_I')==0 || size(aa_I,1)==0 || exist('data_I')==0 || size(data_I,1)==0;
        disp('Variables dont exist')
    else
        set(handles.indexinstr_l,'string',num2str(aa_I(1,1:end-1)') )
        
        save([cd,'/0. variables/data_I.mat'],'data_I')
        save([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
        
        plotindex_b_Callback(hObject, eventdata, handles)
    end
end
    
set(handles.phase_l,'value',1)


% --- Executes on button press in saveset_b.
function saveset_b_Callback(hObject, eventdata, handles)
% hObject    handle to saveset_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%% save settings


mnu =menu( 'What would you like to save?','Materials info','instrumental','both');

direc=cd;

    [name path] = uiputfile('*.mat','Select folder to save in',[direc,'/1. settings/',get(handles.name_t,'string')]);
    
if mnu==1    
    %get settings
    load([cd,'/0. variables/phases.mat'],'dsettings')
    dppapref = getDPPApref;
    %save them
    save([path,'/SET_',name],'dsettings','dppapref')
elseif mnu==2    
    %get instrumental
    load([cd,'/0. variables/data_I.mat'],'data_I')
    load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
    %and save them
    save([path,'/INSTR_',name],'data_I','aa_I','aabcg_I')
elseif mnu==3
    %get settings
    load([cd,'/0. variables/phases.mat'],'dsettings')
    dppapref = getDPPApref;
    %get instrumental
    load([cd,'/0. variables/data_I.mat'],'data_I')
    load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
    %and save them
    save([path,'/INSTR_',name],'data_I','aa_I','aabcg_I')
    save([path,'/SET_',name],'dsettings','dppapref')
end


% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in indexinstr_l.
function indexinstr_l_Callback(hObject, eventdata, handles)
% hObject    handle to indexinstr_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns indexinstr_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from indexinstr_l


% --- Executes during object creation, after setting all properties.
function indexinstr_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to indexinstr_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in findpks_b.
function findpks_b_Callback(hObject, eventdata, handles)
% hObject    handle to findpks_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


if exist([cd,'/0. variables/data_I.mat'],'file')~=0
    load([cd,'/0. variables/data_I.mat'],'data_I')
    
    hold(handles.axes1,'off')
    semilogy(data_I(:,1),data_I(:,2),'parent',handles.axes1),
    hold(handles.axes1,'on')
    
    mnu = menu('Select peak positions at the peak, right click when complete','ok','no k')
    if mnu==1
    but=2;n=1;xp=[];
    while but~=3
        [xp_I(n) y(n) but]=ginput(1);
        n=n+1;
    end

    xp_I=sort(xp_I(1:end-1));
    y=y(1:end-1);%could sort too but not important
    hold on

    for n=1:length(xp_I)
        plot([xp_I(n) xp_I(n)], [min(data_I(:,2)), max(data_I(:,2))],...
            'r','parent',handles.axes1)
    end
    
    aa_I=zeros(4,length(xp_I)+1);
    aa_I(1,1:end-1)=xp_I;
    aa_I(2,1:end-1)=y;
    aa_I(3,1:end-1)=0.001;
    aa_I(4,1:end-1)=.5;
    aabcg_I=zeros(2,length(xp_I));
    save([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
    grid(handles.axes1,'on')
    
    set(handles.indexinstr_l,'string',num2str(aa_I(1,1:end-1)') )
    end
else
    disp('Error: no instr')
    
end

% --- Executes on button press in Si_b.
function Si_b_Callback(hObject, eventdata, handles)
% hObject    handle to Si_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

loadb_GUI(handles, 'Instr')
plotSi_b_Callback(hObject, eventdata, handles)

% --- Executes on button press in fitSi_b.
function fitSi_b_Callback(hObject, eventdata, handles)
% hObject    handle to fitSi_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%% fit standard

mnu = menu('Fit the instrumental, then click done when complete:' ,'ok','not yet');
if mnu == 1
    set(handles.fit_p,'visible','on')
    set(handles.settings_p,'visible','off')
    set(handles.IB_p,'visible','off')
    set(handles.doneres_b,'visible','on')
    set(handles.slider_l,'visible','off')

    set(handles.data_instr_b,'string','Instrumental')
    setDPPApref('datainstr','Instr')
    
    data_instr_b_Callback(hObject, eventdata, handles)

end


% --- Executes on selection change in indexres_l.
function indexres_l_Callback(hObject, eventdata, handles)
% hObject    handle to indexres_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns indexres_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from indexres_l

%% select peak index in fitting

plotexternal = get(handles.plotexternal_b,'value');
if plotexternal ==1
figure
haxes = gca;
hold(haxes,'off')    
else
haxes = handles.axes1;
hold(haxes,'off')
end


peakno = get(hObject,'Value');
logplot = get(handles.logplot_b,'value');
val = get(handles.phaseres_l,'value');

[aaC, aabcgC, dataC]=plotfit_GUI(haxes, val, peakno, logplot);
load([cd,'/0. variables/phases.mat'],'dsettings')
if val==2 
peakno=length(dsettings(1,1).d)+peakno;
end
%% update GUI and focus on the one peak

set(handles.xp_t,'string', num2str(aaC(1,peakno)))
set(handles.I_t,'string', num2str(aaC(2,peakno)))
set(handles.fw_t,'string', num2str(aaC(3,peakno)))
set(handles.neta_t,'string', num2str(aaC(4,peakno)))
set(handles.bcgI1_t,'string', num2str(aabcgC(1,peakno)))
set(handles.bcgI2_t,'string', num2str(aabcgC(2,peakno)))


            
% --- Executes during object creation, after setting all properties.
function indexres_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to indexres_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in phaseres_l.
function phaseres_l_Callback(hObject, eventdata, handles)
% hObject    handle to phaseres_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns phaseres_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from phaseres_l
load([cd,'/0. variables/phases.mat'],'dsettings')
val=get(hObject,'value');

set(handles.indexres_l,'value',1)
set(handles.indexres_l,'string',num2str(dsettings(1,val).index))


% --- Executes during object creation, after setting all properties.
function phaseres_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to phaseres_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in doneres_b.
function doneres_b_Callback(hObject, eventdata, handles)
% hObject    handle to doneres_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.fit_p,'visible','off')
set(handles.settings_p,'visible','on')
set(handles.IB_p,'visible','off')
set(handles.doneres_b,'visible','off')
set(handles.slider_l,'visible','on')

set(handles.data_instr_b,'string','Sampl')
setDPPApref('datainstr','Sampl')



% --- Executes on button press in savefit_b.
function savefit_b_Callback(hObject, eventdata, handles)
% hObject    handle to savefit_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%% Save fit

%% user inputs - create / add to file
[FileName,PathName] = uiputfile('*.mat','Select the Fit file',[cd]);
if FileName ~=0
    filq=exist( [PathName,FileName],'file');
    
    if filq~=0%an existing file
        load([PathName,FileName],'fita')
        sizfit=length(fita);
    else%create a new file
        dotsq=find(FileName=='.');
        if isempty(dotsq)==0
            FileName=FileName(1:dotsq-1);   
        end
        FileName=[FileName,'_fit'];
        sizfit=0;%length of fita
        val_old=1;%position within fita
        fita=[];
    end
    %% loads
    load([cd,'/0. variables/fit.mat'],'aa','aabcg')
    load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
    load([cd,'/0. variables/data.mat'],'data')
    load([cd,'/0. variables/data_I.mat'],'data_I')
    load([cd,'/0. variables/phases.mat'],'dsettings')
    DPPApref= getDPPApref;
    
    id = DPPApref.identa;
    
    %% check if file name exists and if so deletes previous
    for n=1:length(fita)
        noms=fita(1,n).name;
        ifind=strcmp(noms,id);
        val_old=sizfit+1;
        if ifind~=0
            val_old=n;
            break
        end
    end
    
    fita(1,val_old).data_I=data_I;
    fita(1,val_old).aa_I=aa_I;
    fita(1,val_old).aa=aa;
    fita(1,val_old).data=data;
    fita(1,val_old).aabcg_I=aabcg_I;
    fita(1,val_old).aabcg=aabcg;
    fita(1,val_old).dsettings=dsettings;
    fita(1,val_old).DPPApref=DPPApref;
    fita(1,val_old).name=id;
    
    val=input('Enter a numerical value? \n');

    fita(1,val_old).val=val;
    save([PathName,FileName],'fita')
else
    menu('no file selected','ok')
end
% --- Executes on selection change in data_instr_b.
function data_instr_b_Callback(hObject, eventdata, handles)
% hObject    handle to data_instr_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns data_instr_b contents as cell array
%        contents{get(hObject,'Value')} returns selected item from data_instr_b

%% whether fitting to data or instrumental

datainstr = get(handles.data_instr_b,'String') ;
datainstr = datainstr(1:5)

setDPPApref('datainstr',datainstr);
%initialise list
set(handles.indexres_l,'value',1)

%update GUI
if strcmp(datainstr,'Sampl')
    load([cd,'/0. variables/fit.mat'],'aa','aabcg')
    load([cd,'/0. variables/phases.mat'],'dsettings')
    
    set(handles.indexres_l,'string',num2str(dsettings(1,1).index) )
    set(handles.xp_t,'string', num2str(aa(1,1)))
    for n=1:length(dsettings)
        phases(n,:)=dsettings(1,n).name;
    end
        
    set(handles.phaseres_l,'string',phases)
    set(handles.I_t,'string', num2str(aa(2,1)))
    set(handles.fw_t,'string', num2str(aa(3,1)))
    set(handles.neta_t,'string', num2str(aa(4,1)))
    set(handles.bcg1_t,'string',num2str(aa(1,end)))
    set(handles.bcg2_t,'string',num2str(aa(2,end)))
    set(handles.bcg3_t,'string',num2str(aa(3,end)))
    
elseif strcmp(datainstr,'Instr')
    disp('Instrumental fitting')
    load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
    
    set(handles.indexres_l,'string',num2str(aa_I(1,1:end-1)') )
    set(handles.xp_t,'string', num2str(aa_I(1,1)))
    
    set(handles.phaseres_l,'value',1)
    set(handles.phaseres_l,'string','instrumental')
    set(handles.I_t,'string', num2str(aa_I(2,1)))
    set(handles.fw_t,'string', num2str(aa_I(3,1)))
    set(handles.neta_t,'string', num2str(aa_I(4,1)))
    set(handles.bcg1_t,'string',num2str(aa_I(1,end)))
    set(handles.bcg2_t,'string',num2str(aa_I(2,end)))
    set(handles.bcg3_t,'string',num2str(aa_I(3,end)))
    
end
plotfit_b_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function data_instr_b_CreateFcn(hObject, eventdata, handles)
% hObject    handle to data_instr_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in indivfit_b.
function indivfit_b_Callback(hObject, eventdata, handles)
% hObject    handle to indivfit_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%% fit a peak individually

%gets
val=get(handles.phaseres_l,'value');
n=get(handles.indexres_l,'value');
haxes = handles.axes1;

%call extrenal
indivfit_GUI(n, val, haxes)

% --- Executes on button press in bcgspline_b.
function bcgspline_b_Callback(hObject, eventdata, handles)
% hObject    handle to bcgspline_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%% fit a bcg spline

datainstr = getDPPApref('datainstr');
bcg2peak = getDPPApref('bcg2peak');
logplot= getDPPApref('logplot');

if strcmp(datainstr,'Sampl')
    %loads
    load([cd,'/0. variables/fit.mat'],'aa','aabcg')
    load([cd,'/0. variables/data.mat'],'data')

    xp=aa(1,:);
    
    if size(aa,2)==4
    aa(:,size(aa,2))=steel_bcg(data(:,1), data(:,2), xp, bcg2peak,logplot);
    else
    aa(1:4,size(aa,2))=steel_bcg(data(:,1), data(:,2), xp, bcg2peak,logplot);
    end
    set(handles.bcg1_t,'string',num2str(aa(1,end)))
    set(handles.bcg2_t,'string',num2str(aa(2,end)))
    set(handles.bcg3_t,'string',num2str(aa(3,end)))
    
    %saves
    save([cd,'/0. variables/fit.mat'],'aa','aabcg')
    
elseif strcmp(datainstr,'Instr')
    %loads
    load([cd,'/0. variables/data_I.mat'],'data_I')
    load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')

    xp=aa_I(1,:);
 
    aa_I(:,size(aa_I,2))=steel_bcg(data_I(:,1), data_I(:,2), xp, bcg2peak,logplot);
    set(handles.bcg1_t,'string',num2str(aa_I(1,end)))
    set(handles.bcg2_t,'string',num2str(aa_I(2,end)))
    set(handles.bcg3_t,'string',num2str(aa_I(3,end)))
    %saves
    save([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
end

function sizfit_t_Callback(hObject, eventdata, handles)
% hObject    handle to sizfit_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sizfit_t as text
%        str2double(get(hObject,'String')) returns contents of sizfit_t as a double

bcg2peak = str2double(get(hObject,'String'));

setDPPApref('bcg2peak',bcg2peak);

% --- Executes during object creation, after setting all properties.
function sizfit_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sizfit_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in plotfit_b.
function plotfit_b_Callback(hObject, eventdata, handles)
% hObject    handle to plotfit_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%%plot the fit
plotexternal = get(handles.plotexternal_b,'value');
if plotexternal ==1
figure
haxes = gca;
hold(haxes,'off')    
else
haxes = handles.axes1;
hold(haxes,'off')
end

datorI=getDPPApref('datainstr');

if strcmp(datorI,'Sampl')%% data
    %%
    load([cd,'/0. variables/fit.mat'],'aa','aabcg')
    load([cd,'/0. variables/data.mat'],'data')
    if ishold==1;hold;end
        logplot=get(handles.logplot_b,'value');

    if logplot==1
        semilogy(data(:,1),data(:,2),'b.','parent',haxes),
    else
        plot(data(:,1),data(:,2),'b.','parent',haxes),    
    end
    hold(haxes,'on')
    IIfit=pv_tv_aa(aa(:,:),data(:, 1)) ;
    plot(data(:,1),IIfit,'color','k','parent',haxes)
    

    legend(haxes,'Raw data','Fit of all')%,'Data to use')
    xlabel(haxes,'1/d (10^-^1^0 m^-^1)','fontsize',18)
    ylabel(haxes,'Intensity','fontsize',18)
    set(haxes,'fontsize',16)
    
elseif strcmp(datorI,'Instr')%% instrumental
    %%
    load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
    load([cd,'/0. variables/data_I.mat'],'data_I')
    if ishold==1;hold;end
        logplot=get(handles.logplot_b,'value');

    if logplot==1
        semilogy(data_I(:,1),data_I(:,2),'parent',haxes),
    else
        plot(data_I(:,1),data_I(:,2),'parent',haxes),    
    end
    hold(haxes,'on')
    IIfit=pv_tv_aa(aa_I(:,:),data_I(:, 1)) ;
    plot(data_I(:,1),IIfit,'m','parent',haxes)
end

grid(haxes,'on')
% --- Executes on button press in loadfitmenu_b.
function loadfitmenu_b_Callback(hObject, eventdata, handles)
% hObject    handle to loadfitmenu_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[FileName,PathName] = uigetfile('*.mat','Select the Fit file',[cd]);
if FileName == 0
    menu('Nothing to load','ok');
else
    save([cd,'/0. variables/load_fnames.mat'],'FileName','PathName')
    load([PathName,FileName],'fita')

    for n=1:length(fita)
    nom{n}=fita(1,n).name;
    end
    set(handles.load_l,'value',1)
    set(handles.load_l,'string',nom)
end

% --- Executes on button press in fitrange_b.
function fitrange_b_Callback(hObject, eventdata, handles)
% hObject    handle to fitrange_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%crop data

load([cd,'/0. variables/data.mat'],'data')
load([cd,'/0. variables/data_I.mat'],'data_I')

plotfit_b_Callback(hObject, eventdata, handles)

mnu = menu('Are you sure you want to crop the data?','Yes','No');

if mnu==1
    [x y but]=ginput(2);
    x=sort(x);

    datainstr=getDPPApref('datainstr');
    if strcmp(datainstr,'Sampl')
        adjtth=abs(data(:,1)-x(1));
        minpos=find(adjtth==min(adjtth));
        adjtth=abs(data(:,1)-x(2));
        maxpos=find(adjtth==min(adjtth));
        data=data(minpos:maxpos,:);
        save([cd,'/0. variables/data.mat'],'data')
    elseif strcmp(datainstr,'Instr')
        adjtth=abs(data_I(:,1)-x(1));
        minpos=find(adjtth==min(adjtth));
        adjtth=abs(data_I(:,1)-x(2));
        maxpos=find(adjtth==min(adjtth));
        data_I=data_I(minpos:maxpos,:);
        save([cd,'/0. variables/data_I.mat'],'data_I')
    end
    
    
    plotfit_b_Callback(hObject, eventdata, handles)
    
end

% --- Executes on button press in selindivfit_b.
function selindivfit_b_Callback(hObject, eventdata, handles)
% hObject    handle to selindivfit_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of selindivfit_b


% --- Executes on button press in asymm_b.
function asymm_b_Callback(hObject, eventdata, handles)
% hObject    handle to asymm_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of asymm_b

%% whether fit is assymetric or not

%loads
load([cd,'/0. variables/fit.mat'],'aa','aabcg')
load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
datainstr = getDPPApref('datainstr');

%change aa and aa_I depending on whether asymm or not
value=get(hObject,'Value');
if value==1
    if value==1 && size(aa,1)==4
        aa(5:6,:)=aa(3:4,1:end);
        
    end
    if value==1 && size(aa_I,1)==4
        aa_I(5:6,:)=aa_I(3:4,1:end);
    end
else
    aa=aa(1:4,:);
    aa_I=aa_I(1:4,:);
end

%save new instr

if strcmp(datainstr,'Instr')
    save([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
elseif strcmp(datainstr,'Sampl')
    save([cd,'/0. variables/fit.mat'],'aa','aabcg')
end


% --- Executes on button press in pushbutton21.
function pushbutton21_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton22.
function pushbutton22_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in alpha2q_b.
function alpha2q_b_Callback(hObject, eventdata, handles)
% hObject    handle to alpha2q_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of alpha2q_b



function delK_t_Callback(hObject, eventdata, handles)
% hObject    handle to delK_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of delK_t as text
%        str2double(get(hObject,'String')) returns contents of delK_t as a double


% --- Executes during object creation, after setting all properties.
function delK_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to delK_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function bcg2_t_Callback(hObject, eventdata, handles)
% hObject    handle to bcg2_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bcg2_t as text
%        str2double(get(hObject,'String')) returns contents of bcg2_t as a double
%% bcg spline 2
datinstr=getDPPApref('datainstr');

if strcmp(datinstr,'Sampl')
    load([cd,'/0. variables/fit.mat'],'aa','aabcg')
    aa(2,end) = str2double( get(hObject,'String') );
    save([cd,'/0. variables/fit.mat'],'aa','aabcg')
    
else
    load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
    aa_I(2,end) = str2double( get(hObject,'String') );
    save([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
end

plotfit_b_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function bcg2_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bcg2_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in kpos_b.
function kpos_b_Callback(hObject, eventdata, handles)
% hObject    handle to kpos_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of kpos_b

%% Change position & intensity of peak

    
%initialises
load([cd,'/0. variables/phases.mat'],'dsettings')
val=get(handles.indexres_l,'value');
datainstr=getDPPApref('datainstr');
phase=get(handles.phaseres_l,'value');

%
if strcmp(datainstr,'Sampl')
    load([cd,'/0. variables/fit.mat'],'aa','aabcg')
    load([cd,'/0. variables/data.mat'],'data')
    % adjust position of aa if 2nd phase
    if phase==2
        val=val+length(dsettings(1,1).d);
    end
    mnu=menu('Click on sample peaks- peak','ok');
    [x ,y, ~]=ginput(1);
    % background level
    lam0=aa;lam0(:,val)=zeros(size(aa(:,1)));
    IIfit=+ pv_tv_aa(lam0,data(:, 1))+...
        pv_tv_aa([aabcg(:,val);0;0],data(:, 1)) ;
    absa = abs(data(:,1) - x);
    ypk = IIfit(absa==min(absa));
    
    y = y-ypk; if y<0 ; y=1e-4;end
    aa(2,val)=y;
    
    aa(1,val)=x;
    save([cd,'/0. variables/fit.mat'],'aa','aabcg')
    
elseif strcmp(datainstr,'Instr')
    mnu=menu('Click on instrumental peaks- peak','ok');
    load([cd,'/0. variables/data_I.mat'],'data_I')
    load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
    [x, y, but]=ginput(1);
    
    % background level
    lam0=aa_I;lam0(:,val)=zeros(size(aa_I(:,1)));
    IIfit=+ pv_tv_aa(lam0,data_I(:, 1))+...
        pv_tv_aa([aabcg_I(:,val);0;0],data_I(:, 1)) ;
    absa = abs(data_I(:,1) - x);
    ypk = IIfit(absa==min(absa));
    
    y = y-ypk; if y<0 ; y=1e-4;end
    aa_I(2,val)=y;
    
    
    aa_I(1,val)=x;
    aa_I(2,val)=y;
    save([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
end
    
% plot and reset
indexres_l_Callback(hObject, eventdata, handles)
set(hObject,'value',0)


% --- Executes on button press in bcgindi_b.
function bcgindi_b_Callback(hObject, eventdata, handles)
% hObject    handle to bcgindi_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of bcgindi_b

%% change individual background level

%initialises
load([cd,'/0. variables/phases.mat'],'dsettings')
peakno=get(handles.indexres_l,'value');
datainstr=getDPPApref('datainstr');
phase=get(handles.phaseres_l,'value');

%
if strcmp(datainstr,'Sampl')
    load([cd,'/0. variables/data.mat'])
    load([cd,'/0. variables/fit.mat'],'aa','aabcg')
    if phase==2 
        peakno=length(dsettings(1,1).d)+peakno;
    end
    [~ , y]=ginput(1);
    lam0=aa;
    lam0(:,peakno)=zeros(size( lam0(:,peakno)));
    %fit of everything but the peak including bcg indi
    IFT=pv_tv_aa(lam0,data(:,1))+...
        pv_tv_aa([aabcg(:,peakno);0;0],data(:,1));
    adjtth=abs(data(:,1)-aa(1,peakno));
    peakpos=(adjtth==min(adjtth));
    aabcg(1,peakno)=y-IFT(peakpos)+aabcg(1,peakno);
    save([cd,'/0. variables/fit.mat'],'aa','aabcg')
else
    load([cd,'/0. variables/data_I.mat'])
    load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
    
    [~ , y]=ginput(1);
    lam0=aa_I;
    lam0(:,peakno)=zeros(size( lam0(:,peakno)));
    IFT=pv_tv_aa(lam0,data_I(:,1))+...
        pv_tv_aa([aabcg_I(:,peakno);0;0],data_I(:,1));
    adjtth=abs(data_I(:,1)-aa_I(1,peakno));
    peakpos=(adjtth==min(adjtth));
    aabcg_I(1,peakno)=y-IFT(peakpos)+aabcg_I(1,peakno);
    save([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
end


set(hObject,'value',0)
indexres_l_Callback(hObject, eventdata, handles)



% --- Executes on button press in korig_b.
function korig_b_Callback(hObject, eventdata, handles)
% hObject    handle to korig_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of korig_b

%% replace k with settings values

% initialises
load([cd,'/0. variables/phases.mat'],'dsettings')
pval_=get(handles.indexres_l,'value');
sval=get(handles.phaseres_l,'value');
datinstr=getDPPApref('datainstr');
lat1=dsettings(1,sval).lat1;
lat2=dsettings(1,sval).lat2;
crys=dsettings(1,sval).cstruct;

if strcmp(datinstr,'Sampl')
    load([cd,'/0. variables/fit.mat'],'aa','aabcg')
    % position within aa of the peak
    if sval==2;
        pval=pval_+length(dsettings(1).d);
    else
        pval=pval_;
    end

    aa(1,pval)=1./dspacing_dippa(dsettings(sval).index(pval_,:),...
        crys,lat1,lat2  );
    save([cd,'/0. variables/fit.mat'],'aa','aabcg')
    
else
    disp('Error: just for sample')
    
end


set(hObject,'value',0)
indexres_l_Callback(hObject, eventdata, handles)

function xp_t_Callback(hObject, eventdata, handles)
% hObject    handle to xp_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of xp_t as text
%        str2double(get(hObject,'String')) returns contents of xp_t as a double
%% position of peak

datinstr=getDPPApref('datainstr');
val=get(handles.phaseres_l,'value');
peakval=get(handles.indexres_l,'value');

if strcmp(datinstr,'Sampl')
    load([cd,'/0. variables/phases.mat'],'dsettings')
    load([cd,'/0. variables/fit.mat'],'aa','aabcg')
    if val==2
        peakval=length(dsettings(1,1).d)+peakval;
    end
    aa(1,peakval)=str2double( get(hObject,'string') );

    save([cd,'/0. variables/fit.mat'],'aa','aabcg')

elseif strcmp(datinstr,'Instr')
    load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
    aa_I(1,peakval)=str2double( get(hObject,'string') );
    save([cd,'/0. variables/fit.mat'],'aa','aabcg')
end

indexres_l_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function xp_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to xp_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function I_t_Callback(hObject, eventdata, handles)
% hObject    handle to I_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of I_t as text
%        str2double(get(hObject,'String')) returns contents of I_t as a double

%% intensity of peak

datinstr=getDPPApref('datainstr');
val=get(handles.phaseres_l,'value');
peakval=get(handles.indexres_l,'value');

if strcmp(datinstr,'Sampl')
    load([cd,'/0. variables/phases.mat'],'dsettings')
    load([cd,'/0. variables/fit.mat'],'aa','aabcg')
    if val==2
        peakval=length(dsettings(1,1).d)+peakval;
    end
    aa(2,peakval)=str2double( get(hObject,'string') );

    save([cd,'/0. variables/fit.mat'],'aa','aabcg')

elseif strcmp(datinstr,'Instr')
    load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
    aa_I(2,peakval)=str2double( get(hObject,'string') );
    save([cd,'/0. variables/fit.mat'],'aa','aabcg')
end

indexres_l_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function I_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to I_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function bcgI1_t_Callback(hObject, eventdata, handles)
% hObject    handle to bcgI1_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bcgI1_t as text
%        str2double(get(hObject,'String')) returns contents of bcgI1_t as a double

datinstr=getDPPApref('datainstr');
val=get(handles.phaseres_l,'value');
peakval=get(handles.indexres_l,'value');

if strcmp(datinstr,'Sampl')
    
    load([cd,'/0. variables/fit.mat'],'aa','aabcg')
    if val==2
        peakval=length(dsettings(1,1).d)+peakval;
    end
    aabcg(1,peakval)=str2double( get(hObject,'string') );

    save([cd,'/0. variables/fit.mat'],'aa','aabcg')
    
else
    load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')

    aabcg_I(1,peakval)=str2double( get(hObject,'string') );

    save([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
    
end
indexres_l_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function bcgI1_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bcgI1_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function bcgI2_t_Callback(hObject, eventdata, handles)
% hObject    handle to bcgI2_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bcgI2_t as text
%        str2double(get(hObject,'String')) returns contents of bcgI2_t as a double

datinstr=getDPPApref('datainstr');
val=get(handles.phaseres_l,'value');
peakval=get(handles.indexres_l,'value');

if strcmp(datinstr,'Sampl')
    
    load([cd,'/0. variables/fit.mat'],'aa','aabcg')
    if val==2
        peakval=length(dsettings(1,1).d)+peakval;
    end
    aabcg(2,peakval)=str2double( get(hObject,'string') );

    save([cd,'/0. variables/fit.mat'],'aa','aabcg')
    
else
    load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')

    aabcg_I(2,peakval)=str2double( get(hObject,'string') );

    save([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
    
end

indexres_l_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function bcgI2_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bcgI2_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function fw_t_Callback(hObject, eventdata, handles)
% hObject    handle to fw_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of fw_t as text
%        str2double(get(hObject,'String')) returns contents of fw_t as a double
%% FW of peak

datinstr=getDPPApref('datainstr');
val=get(handles.phaseres_l,'value');
peakval=get(handles.indexres_l,'value');

if strcmp(datinstr,'Sampl')
    load([cd,'/0. variables/phases.mat'],'dsettings')
    load([cd,'/0. variables/fit.mat'],'aa','aabcg')
    if val==2
        peakval=length(dsettings(1,1).d)+peakval;
    end
    aa(3,peakval)=str2double( get(hObject,'string') );

    save([cd,'/0. variables/fit.mat'],'aa','aabcg')

elseif strcmp(datinstr,'Instr')
    load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
    aa_I(3,peakval)=str2double( get(hObject,'string') );
    save([cd,'/0. variables/fit.mat'],'aa','aabcg')
end

indexres_l_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function fw_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to fw_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function neta_t_Callback(hObject, eventdata, handles)
% hObject    handle to neta_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of neta_t as text
%        str2double(get(hObject,'String')) returns contents of neta_t as a double

%% neta of peak

datinstr=getDPPApref('datainstr');
val=get(handles.phaseres_l,'value');
peakval=get(handles.indexres_l,'value');

if strcmp(datinstr,'Sampl')
    load([cd,'/0. variables/phases.mat'],'dsettings')
    load([cd,'/0. variables/fit.mat'],'aa','aabcg')
    if val==2
        peakval=length(dsettings(1,1).d)+peakval;
    end
    aa(4,peakval)=str2double( get(hObject,'string') );

    save([cd,'/0. variables/fit.mat'],'aa','aabcg')

elseif strcmp(datinstr,'Instr')
    load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
    aa_I(4,peakval)=str2double( get(hObject,'string') );
    save([cd,'/0. variables/fit.mat'],'aa','aabcg')
end

indexres_l_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function neta_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to neta_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function bcg1_t_Callback(hObject, eventdata, handles)
% hObject    handle to bcg1_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bcg1_t as text
%        str2double(get(hObject,'String')) returns contents of bcg1_t as a double

%% bcg spline 1
datinstr=getDPPApref('datainstr');

if strcmp(datinstr,'Sampl')
    load([cd,'/0. variables/fit.mat'],'aa','aabcg')
    aa(1,end) = str2double( get(hObject,'String') );
    save([cd,'/0. variables/fit.mat'],'aa','aabcg')
    
else
    load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
    aa_I(1,end) = str2double( get(hObject,'String') );
    save([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
end

plotfit_b_Callback(hObject, eventdata, handles)
% --- Executes during object creation, after setting all properties.
function bcg1_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bcg1_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function bcg3_t_Callback(hObject, eventdata, handles)
% hObject    handle to bcg3_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bcg3_t as text
%        str2double(get(hObject,'String')) returns contents of bcg3_t as a double
%% bcg spline 3
datinstr=getDPPApref('datainstr');

if strcmp(datinstr,'Sampl')
    load([cd,'/0. variables/fit.mat'],'aa','aabcg')
    aa(3,end) = str2double( get(hObject,'String') );
    save([cd,'/0. variables/fit.mat'],'aa','aabcg')
    
else
    load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
    aa_I(3,end) = str2double( get(hObject,'String') );
    save([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
end

plotfit_b_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function bcg3_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bcg3_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in loadlist_b.
function loadlist_b_Callback(hObject, eventdata, handles)
% hObject    handle to loadlist_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%% load file from list

%check1 to stop rubbish
if exist([cd,'/0. variables/load_fnames.mat'],'file')
    
load([cd,'/0. variables/load_fnames.mat'],'FileName','PathName')

%check2 to stop rubbish
if length(FileName)>2

    %load file data
    load([PathName,FileName],'fita')

    sel=get(handles.load_l,'value');
    identa=fita(1,sel).name;
    
    aa=fita(1,sel).aa;
    data=fita(1,sel).data;
        
    %%
    fnoms=fieldnames(fita(1,sel));
    existbcg = isempty(find(strcmp(fnoms,'aabcg')==1)==1);
    if existbcg==1
        aabcg=zeros(2,size(aa,2)-1);
    else
        aabcg=fita(1,sel).aabcg;
        if size(aabcg,1)==0
            aabcg=zeros(2,size(aa,2)-1);
        end

    end
    %%
    
    %% load instrumental
    instrload = get(handles.loadinstraswell_b,'value');
    if instrload ==1
        existdata_I = isempty(find(strcmp(fnoms,'data_I')==1)==1);
        if existdata_I ==0 && size(fita(sel).data_I,1)>0%%instr exists
            data_I=fita(sel).data_I;
            save([cd,'/0. variables/data_I.mat'],'data_I') 
        else
            disp('no instr data to load')
        end
        existdata_I = isempty(find(strcmp(fnoms,'aa_I')==1)==1);
        if existdata_I ==0 && size(fita(sel).aa_I,1)>0%%instr exists
            aa_I=fita(sel).aa_I;

            existbcg = isempty(find(strcmp(fnoms,'aabcg_I')==1)==1);
            if existbcg==1
                aabcg_I=zeros(2,size(aa_I,2)-1);
            else
                aabcg_I=fita(1,sel).aabcg_I;
                if size(aabcg_I,1)==0
                    aabcg_I=zeros(2,size(aa_I,2)-1);
                end
            end

            save([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
        else
            disp('no instr fits to load')
        end
    else
       disp('instr not loaded') 
    end

%% saves
    save([cd,'/0. variables/data.mat'],'data')
    save([cd,'/0. variables/fit.mat'],'aa','aabcg')

   
    hold(handles.axes1,'off')
    semilogy(data(:,1),data(:,2),...
        'parent',handles.axes1),
    hold(handles.axes1,'on')

    Ifit=pv_tv_aa(aa,data(:,1));
    plot(data(:,1),Ifit,'m',...
        'parent',handles.axes1)
    ylim(handles.axes1,[min(Ifit)*.9 max(Ifit)*1.3])
    
    %% update prefs
    existbcg = isempty(find(strcmp(fnoms,'DPPApref')==1)==1);
    if existbcg==1%doesn't exist
       DPPApref = getDPPApref ;
    else%exists
       DPPApref = fita(1,sel).DPPApref; 
    end
    
    alpha2=DPPApref.alpha2;
    tube=DPPApref.tube;
    wavelen = DPPApref.wavelen;
    DPPApref.identa = identa;
    startup_DPPA(DPPApref);
    
    %% update settings
    existbcg = isempty(find(strcmp(fnoms,'dsettings')==1)==1);
    if existbcg==1%doesn't exist
       load([cd,'/0. variables/phases.mat'],'dsettings')
    else%exists
       dsettings = fita(1,sel).dsettings; 
       save([cd,'/0. variables/phases.mat'],'dsettings')
    end
    
    
    %% update GUI
    set(handles.sampleID_t,'string',identa)
    
    set(handles.indexres_l,'value',1);
    set(handles.indexres_l,'string',num2str(dsettings(1,1).index) )
    set(handles.xp_t,'string', num2str(aa(1,1)))
    for n=1:length(dsettings)
        phases{n}=dsettings(1,n).name;
    end
    set(handles.phaseres_l,'value',1)
    set(handles.phaseres_l,'string',phases)

    set(handles.I_t,'string', ' ')
    set(handles.xp_t,'string', ' ')
    set(handles.fw_t,'string', ' ')
    set(handles.neta_t,'string', ' ')
    set(handles.bcgI1_t,'string',' ')
    set(handles.bcgI2_t,'string',' ')
    
    set(handles.bcg1_t,'string',num2str(aa(1,end)))
    set(handles.bcg2_t,'string',num2str(aa(2,end)))
    set(handles.bcg3_t,'string',num2str(aa(3,end)))
    
%     set(handles.delK_t,'string',num2str(DPPApref.delK))
    
end
end

% --- Executes on selection change in load_l.
function load_l_Callback(hObject, eventdata, handles)
% hObject    handle to load_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns load_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from load_l
%%

% --- Executes during object creation, after setting all properties.
function load_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to load_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in load_b.
function load_b_Callback(hObject, eventdata, handles)
% hObject    handle to load_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%% LOAD sample data

loadb_GUI(handles, 'Sampl')


% --- Executes on button press in resetaa_b.
function resetaa_b_Callback(hObject, eventdata, handles)
% hObject    handle to resetaa_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%% reset aa 
%load settings
load([cd,'/0. variables/phases.mat'],'dsettings')
load([cd,'/0. variables/data.mat'],'data')
%normalise aa
aa=zeros(4,length(dsettings(1,1).d)+1);
if length(dsettings)==2
    aa=zeros(4,length(dsettings(1,1).d)+...
        length(dsettings(1,2).d)+1);
    disp('if more than two phases this needs chaging')
end

xxx=1;
for x=1:length(dsettings)

    crys=dsettings(x).cstruct(1:3);
    lat1=dsettings(1,x).lat1;
    lat2=dsettings(1,x).lat2;

    for xx=1:length(dsettings(1,x).index)
        xx
        aa(1,xxx)=1./dspacing_dippa(dsettings(x).index(xx,:),...
            crys,lat1,lat2  );
%               aa(1,xxx)=1/dsettings(1,x).d(xx);
      if size(data,1)~=0
          adjtth=abs( data(:,1) - aa(1,xx) - 1e-03);
          maxpos=find(adjtth==min(adjtth));
          adjtth=abs( data(:,1) - aa(1,xx) + 1e-03);
          minpos=find(adjtth==min(adjtth));
          aa(2,xxx)=max(data(minpos:maxpos,2));
      end
      
      aa(3,xxx)=1e-03;

      aa(4,xxx)=.4;
      xxx=xxx+1;
    end
    
end

aabcg=0*aa(1:2,1:end-1);
save([cd,'/0. variables/fit.mat'],'aa','aabcg')


% --- Executes on button press in plotSi_b.
function plotSi_b_Callback(hObject, eventdata, handles)
% hObject    handle to plotSi_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%% plot settings Instr data

%loads
load([cd,'/0. variables/data_I.mat'],'data_I')
load([cd,'/0. variables/phases.mat'],'dsettings')


hold(handles.axes1,'off')
%plot data
logplot=getDPPApref('logplot');
if logplot==1
    semilogy(data_I(:,1),data_I(:,2),'parent',...
        handles.axes1,'color','k','linewidth',2),hold
else
    plot(data_I(:,1),data_I(:,2),'parent',...
        handles.axes1,'color','k','linewidth',2),hold
end

% grid on
set(handles.axes1, 'fontsize',16)
grid(handles.axes1,'on')


% --- Executes on button press in WHselectpks_b.
function WHselectpks_b_Callback(hObject, eventdata, handles)
% hObject    handle to WHselectpks_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

load([cd,'/0. variables/phases.mat'],'dsettings')

inda{1} = 'Done';
for n=1:size(dsettings(1,1).index,1)
    inda{n+1} = num2str(dsettings(1,1).index(n,:));
end

sel=2;h=1;
while sel~=1
    sel = menu('select peaks to use',inda);
    if sel~=1
       selected(h) = sel-1;
       inda{sel}=['>>',inda{sel}];
       h=h+1;
    end
end
selected = sort(selected);
WHpref = getappdata(0,'WHpref');
WHpref.selected =selected; 
setappdata(0,'WHpref',WHpref); 

set(handles.WHselected_l,'value',1);
set(handles.WHselected_l,'string',num2str(dsettings(1,1).index(selected,:)) )
    

% --- Executes on selection change in WHselected_l.
function WHselected_l_Callback(hObject, eventdata, handles)
% hObject    handle to WHselected_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns WHselected_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from WHselected_l


% --- Executes during object creation, after setting all properties.
function WHselected_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to WHselected_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton32.
function pushbutton32_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton32 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in WHfit_b.
function WHfit_b_Callback(hObject, eventdata, handles)
% hObject    handle to WHfit_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%% fit mWH

%% initialises
plotexternal = get(handles.plotexternal_b,'value');
if plotexternal ==1
figure
haxes = gca;
hold(haxes,'off')    
else
haxes = handles.axes1;
hold(haxes,'off')
end

q1 = str2double(get(handles.WHq_t,'string'));
sizeA  = 1/str2double(get(handles.WHsize_t,'string'));
strain = 1e-3 * str2double(get(handles.WHstrain_t,'string'));
guess = [q1, sizeA, strain];

WHpref = getappdata(0,'WHpref');
HCPalloy = WHpref.HCPalloy;

switch HCPalloy 
    case 'No'
%% fit external FCC
[lamfit, WHres, ~, rho]=dippa_fitWH(guess, haxes);
q1 = WHres.q ;
set(handles.WHq_t,'string',q1)
    case 'Yes'
%% fit external HCP
guess(1) = str2double(get(handles.q1WHres_t,'string'));
guess(4) = str2double(get(handles.q2WHres_t,'string'));
[~, WHres, ~, ~]=dippa_fitWH_HCP(guess, haxes);
q1 = WHres.q(1) ; q2 = WHres.q(2) ;
set(handles.q1WHres_t,'string',q1)
set(handles.q2WHres_t,'string',q2)
PC(1,:) = WHres.HCP_CBadj(3);
PC(2,:) = WHres.HCP_CBadj(2);
PC(3,:) = WHres.HCP_CBadj(1);
set(handles.slipsysHCP_l,'string',PC)
end

load([cd,'/0. variables/phases.mat'],'dsettings')
WHpref= getappdata(0,'WHpref');

sizeA = WHres.sizeA ;
strain = WHres.strain ;
rho = WHres.rho;

WHres_set(1).WHpref = WHpref;
WHres_set(1).WHres = WHres;
WHres_set(1).rho = rho;
WHres_set(1).strain = strain;
WHres_set(1).sizeA = sizeA;
WHres_set(1).dsettings=dsettings;

save([cd,'\0. variables\WHRes'],'WHres_set')

set(handles.WHsize_t,'string',1/sizeA)
set(handles.WHstrain_t,'string',strain*1e3)
set(handles.rho_t,'string',rho)


% --- Executes on button press in getIB_b.
function getIB_b_Callback(hObject, eventdata, handles)
% hObject    handle to getIB_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --- Executes on button press in plotmWH_b.
function plotWH_b_Callback(hObject, eventdata, handles)
% hObject    handle to plotmWH_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% plot WH

haxes = handles.axes1;
hold(haxes,'off')

load([cd,'/0. variables/phases.mat'],'dsettings')
load([cd,'/0. variables/fit.mat'],'aa','aabcg')
load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
WHpref = getappdata(0,'WHpref');
Aest = WHpref.chk0;
selected = WHpref.selected;

q1 = str2double(get(handles.WHq_t,'string'));
strain = 1e-3 * str2double(get(handles.WHstrain_t,'string'));
sizeA  = str2double(get(handles.WHsize_t,'string'));
if sizeA ~= 0; sizeA = 1/sizeA; else sizeA = 1e9; end

% index=dsettings(1).index(:,:);
% H2=Hsq(index);


% C = Aest*(1-q1*H2);
K = aa(1,selected);
FW = getFW_IB('FW',selected);
X=K;


plot(X,FW,'marker','o','markerfacecolor','k','linestyle','none',...
    'markersize',10,'parent',haxes)
hold(haxes,'off')
xlabel(haxes,'1/d (10^-^1^0m)','fontsize',14)
ylabel(haxes,'Full-width (10^-^1^0m)','fontsize',14)
set(haxes,'fontsize',16)
% X2 = 0:0.01:max(X)*1.2;
% plot(X2,sizeA + strain*X2,'color','r',...
%     'markersize',15,'linewidth',2,'parent',haxes)

grid(haxes,'on')
% --- Executes on button press in plotmWH_b.
function plotmWH_b_Callback(hObject, eventdata, handles)
% hObject    handle to plotmWH_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% plot mWH

plotexternal = get(handles.plotexternal_b,'value');
if plotexternal ==1
figure
haxes = gca;
hold(haxes,'off')    
else
haxes = handles.axes1;
hold(haxes,'off')
end

%% values for fit
disp('change bewlo for IB and two-sided fw')
WHpref= getappdata(0,'WHpref');
selected = WHpref.selected;

sel= get(handles.WHindex_l,'value');

load([cd,'/0. variables/fit.mat'],'aa','aabcg')
load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')

delK = getFW_IB('FW',selected);

    load([cd,'/0. variables/phases.mat'],'dsettings')
    load([cd,'/0. variables/fit.mat'],'aa','aabcg')
%     index=dsettings(1).index(:,:);
%     H2=Hsq(index);
%     g = aa(1,1:length(H2));
%     g = g(selected);
%     H2 = H2(selected);
    WHpref= getappdata(0,'WHpref');
    HCPalloy = WHpref.HCPalloy;
%     Aest = WHpref.chk0;
%     type_sizestrain = WHpref.type_sizestrain;


sizeA  = 1 / str2double(get(handles.WHsize_t,'string'));
strain = 1e-3 * str2double(get(handles.WHstrain_t,'string'));

switch HCPalloy
    
    case 'No'
q1 = str2double(get(handles.WHq_t,'string'));
lamfit = [q1 , sizeA, strain ];
[~, X, FWfit_line, X_line]= getWH(lamfit,selected);
[~, XS, ~, ~]= getWH(lamfit,sel);
delKS = getFW_IB('FW',sel);
    case 'Yes'
q1 = str2double(get(handles.q1WHres_t,'string'));
q2 = str2double(get(handles.q2WHres_t,'string'));
lamfit = [q1 , sizeA, strain, q2 ];
[~, X, FWfit_line, X_line]= getWH_HCP(lamfit,selected);        
[~, XS, ~, ~]= getWH_HCP(lamfit,sel);  
delKS = getFW_IB('FW',sel);
end


plot(X, delK,'parent',haxes,'marker','o',...
    'linestyle','none','markersize',15,'linewidth',2)
hold(haxes,'on')

plot(X_line,FWfit_line,'color','r',...
    'markersize',15,'linewidth',2,'parent',haxes)

plot(XS, delKS,'parent',haxes,'marker','o',...
    'linestyle','none','markersize',15,'linewidth',2,...
    'markerfacecolor','r')

hold(haxes,'off')
% plot(X,YY,'color','r',...
%     'markersize',15,'linewidth',2,'parent',haxes)
xlabel(haxes,'C^0^.^5/d (10^-^1^0m)','fontsize',14)
ylabel(haxes,'Full-width (10^-^1^0m)','fontsize',14)
set(haxes,'fontsize',16)

grid(haxes,'on')




% --- Executes on button press in FW_IB_b.
function FW_IB_b_Callback(hObject, eventdata, handles)
% hObject    handle to FW_IB_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of FW_IB_b


% --- Executes on button press in pushbutton36.
function pushbutton36_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton36 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton29.
function pushbutton29_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton29 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit27_Callback(hObject, eventdata, handles)
% hObject    handle to edit27 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit27 as text
%        str2double(get(hObject,'String')) returns contents of edit27 as a double


% --- Executes during object creation, after setting all properties.
function edit27_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit27 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton30.
function pushbutton30_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton30 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in popupmenu5.
function popupmenu5_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu5 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu5


% --- Executes during object creation, after setting all properties.
function popupmenu5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit28_Callback(hObject, eventdata, handles)
% hObject    handle to edit28 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit28 as text
%        str2double(get(hObject,'String')) returns contents of edit28 as a double


% --- Executes during object creation, after setting all properties.
function edit28_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit28 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function WHstrain_t_Callback(hObject, eventdata, handles)
% hObject    handle to WHstrain_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of WHstrain_t as text
%        str2double(get(hObject,'String')) returns contents of WHstrain_t as a double


% --- Executes during object creation, after setting all properties.
function WHstrain_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to WHstrain_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function WHsize_t_Callback(hObject, eventdata, handles)
% hObject    handle to WHsize_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of WHsize_t as text
%        str2double(get(hObject,'String')) returns contents of WHsize_t as a double


% --- Executes during object creation, after setting all properties.
function WHsize_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to WHsize_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in saveWHres_b.
function saveWHres_b_Callback(hObject, eventdata, handles)
% hObject    handle to saveWHres_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% save results

[FileName2,PathName2] = uiputfile('*.mat',...
    'Select the Fit_Results file',...
    [cd,'/4. RES']);
if PathName2~=0
    %% 
    load([cd,'\0. variables\WHRes'],'WHres_set')
    WHres_set_sv = WHres_set;
    
    filq=exist( [PathName2,FileName2]);
   
    if filq~=0
        load([PathName2,FileName2],'WHres_set')
        sizfit=length(WHres_set);
        len=length(WHres_set);
    else
        dotsq=find(FileName2=='.');
        if isempty(dotsq)==0
            FileName2=FileName2(1:dotsq-1);
            FileName2=[FileName2,'_WHRES'];
        end
        len=0;
        WHres_set=[];
    end
    %%
    WHpref = getappdata(0,'WHpref');
    load([cd,'/0. variables/phases.mat'],'dsettings')    
    
    
    id = getDPPApref('identa')
    %then save it
    val=input('input \n');
    WHres_set(1,len+1).WHpref = WHres_set_sv.WHpref;
    WHres_set(1,len+1).WHres = WHres_set_sv.WHres;
    WHres_set(1,len+1).rho = WHres_set_sv.rho;
    WHres_set(1,len+1).strain = WHres_set_sv.strain;
    WHres_set(1,len+1).sizeA = WHres_set_sv.sizeA;
    WHres_set(1,len+1).dsettings = WHres_set_sv.dsettings;
    WHres_set(1,len+1).val = val;
    WHres_set(1,len+1).WHpref = WHpref;
    WHres_set(1,len+1).id = id;
    
    
    save([PathName2,FileName2],'WHres_set')
    
else
   menu('error: no file to load','ok'); 
end

% --- Executes on button press in pushbutton42.
function pushbutton42_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton42 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in popupmenu6.
function popupmenu6_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu6 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu6


% --- Executes during object creation, after setting all properties.
function popupmenu6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function WHq_t_Callback(hObject, eventdata, handles)
% hObject    handle to WHq_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of WHq_t as text
%        str2double(get(hObject,'String')) returns contents of WHq_t as a double
%% q values for WH

% q = str2double(get(hObject,'String'));


% --- Executes during object creation, after setting all properties.
function WHq_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to WHq_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit33_Callback(hObject, eventdata, handles)
% hObject    handle to edit33 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit33 as text
%        str2double(get(hObject,'String')) returns contents of edit33 as a double


% --- Executes during object creation, after setting all properties.
function edit33_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit33 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit34_Callback(hObject, eventdata, handles)
% hObject    handle to edit34 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit34 as text
%        str2double(get(hObject,'String')) returns contents of edit34 as a double


% --- Executes during object creation, after setting all properties.
function edit34_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit34 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit35_Callback(hObject, eventdata, handles)
% hObject    handle to edit35 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit35 as text
%        str2double(get(hObject,'String')) returns contents of edit35 as a double


% --- Executes during object creation, after setting all properties.
function edit35_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit35 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit36_Callback(hObject, eventdata, handles)
% hObject    handle to edit36 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit36 as text
%        str2double(get(hObject,'String')) returns contents of edit36 as a double


% --- Executes during object creation, after setting all properties.
function edit36_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit36 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit37_Callback(hObject, eventdata, handles)
% hObject    handle to edit37 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit37 as text
%        str2double(get(hObject,'String')) returns contents of edit37 as a double


% --- Executes during object creation, after setting all properties.
function edit37_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit37 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit38_Callback(hObject, eventdata, handles)
% hObject    handle to edit38 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit38 as text
%        str2double(get(hObject,'String')) returns contents of edit38 as a double


% --- Executes during object creation, after setting all properties.
function edit38_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit38 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit39_Callback(hObject, eventdata, handles)
% hObject    handle to edit39 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit39 as text
%        str2double(get(hObject,'String')) returns contents of edit39 as a double


% --- Executes during object creation, after setting all properties.
function edit39_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit39 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton43.
function pushbutton43_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton43 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in listbox10.
function listbox10_Callback(hObject, eventdata, handles)
% hObject    handle to listbox10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox10 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox10


% --- Executes during object creation, after setting all properties.
function listbox10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton44.
function pushbutton44_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton44 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton45.
function pushbutton45_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton45 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function qloIB_t_Callback(hObject, eventdata, handles)
% hObject    handle to qloIB_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of qloIB_t as text
%        str2double(get(hObject,'String')) returns contents of qloIB_t as a double


% --- Executes during object creation, after setting all properties.
function qloIB_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to qloIB_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function qhiIB_t_Callback(hObject, eventdata, handles)
% hObject    handle to qhiIB_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of qhiIB_t as text
%        str2double(get(hObject,'String')) returns contents of qhiIB_t as a double


% --- Executes during object creation, after setting all properties.
function qhiIB_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to qhiIB_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function C200IB_t_Callback(hObject, eventdata, handles)
% hObject    handle to C200IB_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of C200IB_t as text
%        str2double(get(hObject,'String')) returns contents of C200IB_t as a double


% --- Executes during object creation, after setting all properties.
function C200IB_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to C200IB_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in contrastSetvals_l.
function contrastSetvals_l_Callback(hObject, eventdata, handles)
% hObject    handle to contrastSetvals_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns contrastSetvals_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from contrastSetvals_l
%% inbuilt contrast factor settings

contents = cellstr(get(hObject,'String'));
choi = contents{get(hObject,'Value')} ;

switch choi
    case 'Nickel'
        startup_WHpref(choi,0)
        qscrew = 2.333; qedge = 1.515;
        C0screw = 0.289; C0edge = 0.279;
        
         qscrew_ = qscrew; qedge_ = qedge;
         
         HCPalloy ='No';
         alloy = choi;
         
    case 'Stainless Steel'
        startup_WHpref(choi, 0)
        qscrew = 2.470; qedge = 1.718;
        C0screw = 0.31; C0edge = 0.324;
        
         qscrew_ = qscrew; qedge_ = qedge;
         
         HCPalloy ='No';
         alloy = choi;
         
    case 'HCP'
        C0screw = 1; C0edge = 1;
        HCPcontents = cellstr(get(handles.HCPalloy_l,'String'));
        alloy = HCPcontents{get(handles.HCPalloy_l,'Value')};
        startup_WHpref(alloy,0)
        qscrew = [1.5 1.5 ]; 
        qedge = [-1.5 -2.5 ];
        
        qscrew_ = 0; qedge_ = 0;
           
        HCPalloy = 'Yes'
        
    case 'Add'
        disp('Error: In progress: add details here later')
        
end
%% 
if strcmp(HCPalloy,'Yes')==1
    set(handles.HCPcontrast_p,'visible','on')
    set(handles.WHhcpres_p,'visible','on')
else
    set(handles.HCPcontrast_p,'visible','off')
    set(handles.WHhcpres_p,'visible','off')
end

%%
if exist('C0screw','var')==1
    C0 = 0.5 * ( C0screw + C0edge );
    
    set(handles.C200IB_t,'string',C0)
    set(handles.qloIB_t,'string',qedge_)    
    set(handles.qhiIB_t,'string',qscrew_)
    
    set(handles.qFCClb_t,'string',qedge_)    
    set(handles.qFCCub_t,'string',qscrew_)
    
    WHpref = getappdata(0,'WHpref');
    WHpref.chk0 = C0;
    WHpref.q_ub = qscrew;
    WHpref.q_lb = qedge;
    WHpref.HCPalloy = HCPalloy;
    WHpref.alloy = alloy;
    setappdata(0,'WHpref',WHpref);    
end

% --- Executes during object creation, after setting all properties.
function contrastSetvals_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to contrastSetvals_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in IBsettings_b.
function IBsettings_b_Callback(hObject, eventdata, handles)
% hObject    handle to IBsettings_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

val = get(hObject,'Value');
if val==1
    set(handles.IBsettings_p,'visible','on')
else
    set(handles.IBsettings_p,'visible','off')
end


% --- Executes on button press in closesettings_b.
function closesettings_b_Callback(hObject, eventdata, handles)
% hObject    handle to closesettings_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.IBsettings_p,'visible','off')
set(handles.IBsettings_b , 'Value', 0);


% --- Executes on selection change in indexWH_l.
function indexWH_l_Callback(hObject, eventdata, handles)
% hObject    handle to indexWH_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns indexWH_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from indexWH_l


% --- Executes during object creation, after setting all properties.
function indexWH_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to indexWH_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% --- Executes on button press in WHcauchy_b.
function WHcauchy_b_Callback(hObject, eventdata, handles)
% hObject    handle to WHcauchy_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of WHcauchy_b

WHpref = getappdata(0,'WHpref');
val = get(hObject,'Value');
if val == 1
    WHpref.type_sizestrain = 'whC'
    setappdata(0,'WHpref',WHpref)
end


% --- Executes on button press in WH_Gauss_b.
function WH_Gauss_b_Callback(hObject, eventdata, handles)
% hObject    handle to WH_Gauss_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of WH_Gauss_b

WHpref = getappdata(0,'WHpref');
val = get(hObject,'Value');
if val == 1
    WHpref.type_sizestrain = 'whG'
    setappdata(0,'WHpref',WHpref)
end

% --- Executes on button press in mwhA_b.
function mwhA_b_Callback(hObject, eventdata, handles)
% hObject    handle to mwhA_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of mwhA_b

WHpref = getappdata(0,'WHpref');
val = get(hObject,'Value');
if val == 1
    WHpref.type_sizestrain = 'mwhA'
    setappdata(0,'WHpref',WHpref)
end



% --- Executes on button press in mwhB_b.
function mwhB_b_Callback(hObject, eventdata, handles)
% hObject    handle to mwhB_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of mwhB_b

WHpref = getappdata(0,'WHpref');
val = get(hObject,'Value');
if val == 1
    WHpref.type_sizestrain = 'mwhB'
    setappdata(0,'WHpref',WHpref)
end


% --- Executes on button press in mwhC_b.
function mwhC_b_Callback(hObject, eventdata, handles)
% hObject    handle to mwhC_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of mwhC_b

WHpref = getappdata(0,'WHpref');
val = get(hObject,'Value');
if val == 1
    WHpref.type_sizestrain = 'mwhC'
    setappdata(0,'WHpref',WHpref)
end



function M_t_Callback(hObject, eventdata, handles)
% hObject    handle to M_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of M_t as text
%        str2double(get(hObject,'String')) returns contents of M_t as a double

WHpref = getappdata(0,'WHpref');
M = str2double( get(hObject,'String') );
WHpref.M = M;
setappdata(0,'WHpref',WHpref)



% --- Executes during object creation, after setting all properties.
function M_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to M_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function rho_t_Callback(hObject, eventdata, handles)
% hObject    handle to rho_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of rho_t as text
%        str2double(get(hObject,'String')) returns contents of rho_t as a double


% --- Executes during object creation, after setting all properties.
function rho_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rho_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in WHindex_l.
function WHindex_l_Callback(hObject, eventdata, handles)
% hObject    handle to WHindex_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns WHindex_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from WHindex_l


% --- Executes during object creation, after setting all properties.
function WHindex_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to WHindex_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function FWIB_t_Callback(hObject, eventdata, handles)
% hObject    handle to FWIB_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of FWIB_t as text
%        str2double(get(hObject,'String')) returns contents of FWIB_t as a double


% --- Executes during object creation, after setting all properties.
function FWIB_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FWIB_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function netaIB_t_Callback(hObject, eventdata, handles)
% hObject    handle to netaIB_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of netaIB_t as text
%        str2double(get(hObject,'String')) returns contents of netaIB_t as a double


% --- Executes during object creation, after setting all properties.
function netaIB_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to netaIB_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function sampleID_t_Callback(hObject, eventdata, handles)
% hObject    handle to sampleID_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sampleID_t as text
%        str2double(get(hObject,'String')) returns contents of sampleID_t as a double


% --- Executes during object creation, after setting all properties.
function sampleID_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sampleID_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function strainub_t_Callback(hObject, eventdata, handles)
% hObject    handle to strainub_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of strainub_t as text
%        str2double(get(hObject,'String')) returns contents of strainub_t as a double

WHpref = getappdata(0,'WHpref');
WHpref.boundary_strain(2)= str2double(get(hObject,'String'));
setappdata(0,'WHpref',WHpref)

% --- Executes during object creation, after setting all properties.
function strainub_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to strainub_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit65_Callback(hObject, eventdata, handles)
% hObject    handle to edit65 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit65 as text
%        str2double(get(hObject,'String')) returns contents of edit65 as a double


% --- Executes during object creation, after setting all properties.
function edit65_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit65 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function sizeub_t_Callback(hObject, eventdata, handles)
% hObject    handle to sizeub_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sizeub_t as text
%        str2double(get(hObject,'String')) returns contents of sizeub_t as a double

WHpref = getappdata(0,'WHpref');
WHpref.boundary_size(2)= str2double(get(hObject,'String'))
setappdata(0,'WHpref',WHpref)

% --- Executes during object creation, after setting all properties.
function sizeub_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sizeub_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit67_Callback(hObject, eventdata, handles)
% hObject    handle to edit67 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit67 as text
%        str2double(get(hObject,'String')) returns contents of edit67 as a double


% --- Executes during object creation, after setting all properties.
function edit67_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit67 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit68_Callback(hObject, eventdata, handles)
% hObject    handle to edit68 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit68 as text
%        str2double(get(hObject,'String')) returns contents of edit68 as a double


% --- Executes during object creation, after setting all properties.
function edit68_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit68 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit69_Callback(hObject, eventdata, handles)
% hObject    handle to edit69 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit69 as text
%        str2double(get(hObject,'String')) returns contents of edit69 as a double


% --- Executes during object creation, after setting all properties.
function edit69_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit69 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function sizelb_t_Callback(hObject, eventdata, handles)
% hObject    handle to sizelb_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sizelb_t as text
%        str2double(get(hObject,'String')) returns contents of sizelb_t as a double

WHpref = getappdata(0,'WHpref');
WHpref.boundary_size(1)= str2double(get(hObject,'String'));
setappdata(0,'WHpref',WHpref)

% --- Executes during object creation, after setting all properties.
function sizelb_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sizelb_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit71_Callback(hObject, eventdata, handles)
% hObject    handle to edit71 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit71 as text
%        str2double(get(hObject,'String')) returns contents of edit71 as a double


% --- Executes during object creation, after setting all properties.
function edit71_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit71 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in tubetype_l.
function tubetype_l_Callback(hObject, eventdata, handles)
% hObject    handle to tubetype_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns tubetype_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from tubetype_l

contents = cellstr(get(hObject,'String'));
tube = contents{get(hObject,'Value')};

if strcmp(tube , 'Cu')==1
    wavelen=(1.54056+	1.54439)/2;
    alpha2=0;
    setDPPApref('wavelen',wavelen)
    setDPPApref('alpha2',alpha2)
    set(handles.wav_t,'string',wavelen)
    set(handles.alpha2_b,'value',alpha2)
elseif  strcmp(tube , 'Co')==1
    LabdaAlpha1=  1.789010;%1.78897;
    LabdaAlpha2=  1.792900;%1.79285;
    wavelen=(LabdaAlpha1+LabdaAlpha2)/2;
    alpha2 = 0;
    setDPPApref('wavelen',wavelen)
    setDPPApref('alpha2',alpha2)
    set(handles.wav_t,'string',wavelen)
    set(handles.alpha2_b,'value',alpha2)
else
    alpha2=1;
    set(handles.alpha2_b,'value',alpha2)
end

% --- Executes during object creation, after setting all properties.
function tubetype_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tubetype_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function qFCClb_t_Callback(hObject, eventdata, handles)
% hObject    handle to qFCClb_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of qFCClb_t as text
%        str2double(get(hObject,'String')) returns contents of qFCClb_t as a double


% --- Executes during object creation, after setting all properties.
function qFCClb_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to qFCClb_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function qFCCub_t_Callback(hObject, eventdata, handles)
% hObject    handle to qFCCub_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of qFCCub_t as text
%        str2double(get(hObject,'String')) returns contents of qFCCub_t as a double


% --- Executes during object creation, after setting all properties.
function qFCCub_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to qFCCub_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function strainlb_t_Callback(hObject, eventdata, handles)
% hObject    handle to strainlb_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of strainlb_t as text
%        str2double(get(hObject,'String')) returns contents of strainlb_t as a double

WHpref = getappdata(0,'WHpref');
WHpref.boundary_strain(1)= str2double(get(hObject,'String'));
setappdata(0,'WHpref',WHpref)

% --- Executes during object creation, after setting all properties.
function strainlb_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to strainlb_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit76_Callback(hObject, eventdata, handles)
% hObject    handle to C200IB_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of C200IB_t as text
%        str2double(get(hObject,'String')) returns contents of C200IB_t as a double


% --- Executes during object creation, after setting all properties.
function edit76_CreateFcn(hObject, eventdata, handles)
% hObject    handle to C200IB_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit77_Callback(hObject, eventdata, handles)
% hObject    handle to qhiIB_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of qhiIB_t as text
%        str2double(get(hObject,'String')) returns contents of qhiIB_t as a double


% --- Executes during object creation, after setting all properties.
function edit77_CreateFcn(hObject, eventdata, handles)
% hObject    handle to qhiIB_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit78_Callback(hObject, eventdata, handles)
% hObject    handle to qloIB_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of qloIB_t as text
%        str2double(get(hObject,'String')) returns contents of qloIB_t as a double


% --- Executes during object creation, after setting all properties.
function edit78_CreateFcn(hObject, eventdata, handles)
% hObject    handle to qloIB_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function q2ub_t_Callback(hObject, eventdata, handles)
% hObject    handle to q2ub_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of q2ub_t as text
%        str2double(get(hObject,'String')) returns contents of q2ub_t as a double


% --- Executes during object creation, after setting all properties.
function q2ub_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to q2ub_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit81_Callback(hObject, eventdata, handles)
% hObject    handle to edit81 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit81 as text
%        str2double(get(hObject,'String')) returns contents of edit81 as a double


% --- Executes during object creation, after setting all properties.
function edit81_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit81 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit82_Callback(hObject, eventdata, handles)
% hObject    handle to edit82 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit82 as text
%        str2double(get(hObject,'String')) returns contents of edit82 as a double


% --- Executes during object creation, after setting all properties.
function edit82_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit82 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function q2lb_t_Callback(hObject, eventdata, handles)
% hObject    handle to q2lb_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of q2lb_t as text
%        str2double(get(hObject,'String')) returns contents of q2lb_t as a double


% --- Executes during object creation, after setting all properties.
function q2lb_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to q2lb_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function q1lb_t_Callback(hObject, eventdata, handles)
% hObject    handle to q1lb_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of q1lb_t as text
%        str2double(get(hObject,'String')) returns contents of q1lb_t as a double


% --- Executes during object creation, after setting all properties.
function q1lb_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to q1lb_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function q1ub_t_Callback(hObject, eventdata, handles)
% hObject    handle to q1ub_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of q1ub_t as text
%        str2double(get(hObject,'String')) returns contents of q1ub_t as a double


% --- Executes during object creation, after setting all properties.
function q1ub_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to q1ub_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in HCPalloy_l.
function HCPalloy_l_Callback(hObject, eventdata, handles)
% hObject    handle to HCPalloy_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns HCPalloy_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from HCPalloy_l

contents = cellstr(get(hObject,'String'));
alloy = contents{get(hObject,'Value')};

WHpref = getappdata(0,'WHpref');
WHpref.alloy = alloy;
WHpref.HCPalloy = 'Yes';
setappdata(0,'WHpref',WHpref);

% --- Executes during object creation, after setting all properties.
function HCPalloy_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to HCPalloy_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function q1WHres_t_Callback(hObject, eventdata, handles)
% hObject    handle to q1WHres_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of q1WHres_t as text
%        str2double(get(hObject,'String')) returns contents of q1WHres_t as a double


% --- Executes during object creation, after setting all properties.
function q1WHres_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to q1WHres_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function q2WHres_t_Callback(hObject, eventdata, handles)
% hObject    handle to q2WHres_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of q2WHres_t as text
%        str2double(get(hObject,'String')) returns contents of q2WHres_t as a double


% --- Executes during object creation, after setting all properties.
function q2WHres_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to q2WHres_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in slipsysHCP_l.
function slipsysHCP_l_Callback(hObject, eventdata, handles)
% hObject    handle to slipsysHCP_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns slipsysHCP_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from slipsysHCP_l


% --- Executes during object creation, after setting all properties.
function slipsysHCP_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slipsysHCP_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in WHslipsysInd_b.
function WHslipsysInd_b_Callback(hObject, eventdata, handles)
% hObject    handle to WHslipsysInd_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% individual slip systems

if strcmp(get(handles.WHslipsys_p,'visible'),'off')==1
load([cd,'\0. variables\WHRes'],'WHres_set')
WHres = WHres_set.WHres;
slipsys={'1.B<a> '; '2.Pr<a> '; '3.Pr<c>'; '4.Pr<c+a> '; '5.Py<a> ';...
       '6.Py2<c+a> '; '7.Py3<c+a> '; '8.Py4<c+a> '; '9.Scr<a> '; '10.Scr<c+a> ';...
       '11.Scr<c> '};

indiv_comb = WHres.HCP_indivs ; 

for ii=1:11
   OUT{ii}=[slipsys{ii}, num2str(indiv_comb(ii)) ]; 
end

% menu(OUT, 'ok','fontsize',14)

set(handles.slipsysHCPindiv_l,'string',OUT)
set(handles.WHslipsys_p,'visible','on')
else
    
set(handles.WHslipsys_p,'visible','off')
end

% --- Executes on button press in closeHCPslipsysindiv_p.
function closeHCPslipsysindiv_p_Callback(hObject, eventdata, handles)
% hObject    handle to closeHCPslipsysindiv_p (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.WHslipsys_p,'visible','off')

% --- Executes on selection change in slipsysHCPindiv_l.
function slipsysHCPindiv_l_Callback(hObject, eventdata, handles)
% hObject    handle to slipsysHCPindiv_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns slipsysHCPindiv_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from slipsysHCPindiv_l


% --- Executes during object creation, after setting all properties.
function slipsysHCPindiv_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slipsysHCPindiv_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in loadinstraswell_b.
function loadinstraswell_b_Callback(hObject, eventdata, handles)
% hObject    handle to loadinstraswell_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of loadinstraswell_b


% --- Executes on button press in plotexternal_b.
function plotexternal_b_Callback(hObject, eventdata, handles)
% hObject    handle to plotexternal_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of plotexternal_b
