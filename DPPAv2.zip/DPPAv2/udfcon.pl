#!/usr/bin/perl -w

$fin  = $ARGV[0];
$fout = $ARGV[0];
$fout =~ s/\.UDF/.dat/;

open FIN,  "<$fin";
open FOUT, ">$fout";

while (<FIN>) {

    if (m/^DataAngleRange,\s+(\d+\.\d+),\s+(\d+\.\d+),\//) {
        $start = $1;
        $end   = $2;
    }
    if (m/^ScanStepSize,\s+(\d+\.\d+),\//) {
        $step = $1;
    }
    if (m/^\s+\d/) {
        chomp;
        s/\r//;
        s/\t//;
        s/\///;
        @line = split ",", $_;
        push @data, @line;
    }
}

$n = 0;
foreach (@data) {
    $int = $start + $n * $step;
    print FOUT "$int\t$_\n";
    $n++;
}
close FIN;
close FOUT;

if ( $int - $end == 0 ) {
    print " Conversion done successfully!\n";
}
else {
    print " Number of records exceeds number of detector positions!\n";
}

