%% CP
function Stress_strain_plots_allnew
load('D:\MATLAB\DPPAv2\5. Stress-Strain data\CP tensile')
[CP1_8_strain, CP1_8_stress] = inner(CP1_8_strain, CP1_8_stress );
[CP2_8_strain, CP2_8_stress] = inner(CP2_8_strain, CP2_8_stress );
[CP3_3p5_strain, CP3_3p5_stress] = inner(CP3_3p5_strain, CP3_3p5_stress );
[CP4_1_strain, CP4_1_stress] = inner(CP4_1_strain, CP4_1_stress );

figure(2)
plot(CP1_8_strain, CP1_8_stress ,'r')
hold on
plot(CP2_8_strain, CP2_8_stress , 'g')
plot(CP3_3p5_strain, CP3_3p5_stress , 'b')
plot(CP4_1_strain, CP4_1_stress , 'k')
hold off

save('D:\MATLAB\DPPAv2\5. Stress-Strain data\TiCPstrestra',...
'CP1_8_strain', 'CP1_8_stress')
end

function [strain , stress]= inner(strain, stress)
strain(isnan(strain))=0;
pos = find(strain>1 & stress ==max(stress))

strain = strain(1:pos);
stress = stress(1:pos);

end

