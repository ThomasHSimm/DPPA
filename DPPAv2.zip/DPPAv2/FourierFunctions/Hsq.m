function H2=Hsq(dp)
N=size(dp,1);

for n=1:N;
    H2(n)=( dp(n,1)^2*dp(n,2)^2 + dp(n,1)^2*dp(n,3)^2 + dp(n,2)^2*dp(n,3)^2 )/ (dp(n,1)^2 + dp(n,2)^2 +dp(n,3)^2)^2;
end