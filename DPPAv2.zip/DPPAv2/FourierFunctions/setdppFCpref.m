function setdppFCpref(pref,value)
if nargin==1
   menu('error','ok') 
end
group = getappdata(0,'dppFCpref');

group.(pref) = value;

setappdata(0,'dppFCpref',group);
