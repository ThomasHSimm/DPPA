function [AD, lnAD_g_C] = get_strainFCs(rho, M, B, L, g, C, type_strain) 
%% gets strain Fourier coeffecients- two types Wilkens and Groma
%% THS 2016 dppa

rho = rho *1e-4;
Re = M / sqrt( rho );

switch type_strain
    case 'Grom'
        f = log( Re ./ L );
    case 'Wilk'
        f = get_Wilkens( Re, L );   
end
    
lnAD = zeros( length(L), length(g) );
for i=1:length(L)
    
    lnAD(i,:) = - rho * B * L(i)^2 * (C .* g.^2) * f(i);

end

lnAD_g_C =  rho  .* f ;

AD = exp(lnAD);


end