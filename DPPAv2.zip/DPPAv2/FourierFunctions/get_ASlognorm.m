function [AS ]=get_ASlognorm( gammaomega, L)
%% gets size Fourier coeffecients- using log-norm from Scardi 01
%% THS 2016 dppa 

if nargin ==0
    omega=0.5;   gamma_=5; L=1:1:200;
else
    if length(gammaomega)==1
    omega=0.7;
    gamma_=gammaomega;
    else
    gamma_=gammaomega(1);
    omega=gammaomega(2);
    end
end
m=gamma_;var=omega;
mu=log(m^2 / sqrt(var+m^2));
sigma=sqrt(log(var/m^2 + 1));
gamma_=mu;
omega=sigma;
% figure(3),if ishold==1;hold;end;
% plot(L,lognpdf(L,gamma_,omega))
%%gamma and omega are the mean and standard deviation, respectively, of the associated normal
%%distribution
%%gamma mean
%%omega2 var
HC=[1 -3/2 0 0.5]; 
% omega=sigma^0.5;
% gamma=m;
KC=1;%for spheres
AS=zeros(size(L));
for n=0:3
AS = AS +  HC(n+1)*( M(3-n)/(2*M(3)) ) * erfc( (log(KC*L) - gamma_ - (3 - n)*omega^2) / (omega * 2^0.5) ) .* L.^n;
end
mean=exp(gamma_ +0.5*omega^2);
var=exp(2*gamma_+omega^2)*(exp(omega^2) -1) ;

function Mln=M(n)
    Mln = exp(n*gamma_ + (n^2)*(omega^2/2));
end

end