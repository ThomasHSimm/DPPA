function [indiv_comb,  Burgcomb]=contrastHCP(q1m ,q2m,tizr)
%%%TH Simm 07
%%%calculates the slip systems given measured q values
%%%uses a method similar to Dragomir and Ungar's dislocation population
%%%method (see Dragomir and Ungar 02)
clc2=0.25;
c1c=0.3;
SIZ=0;
q1m,q2m
if q1m<.05 && q1m>0;
    q1m=0.05;
end
if q2m<.05 && q2m>0;
    q2m=0.05;
end

if q1m<=.0 && q1m > -0.05;
    q1m=-0.05;
end
if q2m<=.0 && q2m >-.050;
    q2m=-0.05;
end

while SIZ==0
        if nargin==1;
            q2m=q1m(2);
            q1m=q1m(1);
        end
%%         tizr=1;             %%%1 for titanium 0 for Zr
        %%Below values are for Titanium
        switch tizr
            case 'Titanium'
        q1slip=[-0.101142 -1.19272      3.6161928       2.017177        -0.894009       1.299046 1.89412 1.5270212      0.59492 1.25714 165366];
        q2slip=[-0.102625 0.355623      1.2264112        -0.616631       0.1833109      0.3972469 -0.365739 0.14615    -0.710368 -0.94015 -98611];
        Cslip=[0.20227 0.35387 0.04853 0.10247 0.3118 0.09227 0.09813 0.09323                           0.1444 0.41873 3.61*10^(-6)];
        ba=0.295;bc=0.468;bca=(ba^2+bc^2)^0.5;
        tizr=1;

        %%%below values are for Zirconium
            case 'Zirconium'
        q1slip=[0.48322  -1.18453  5.851276 3.224246    -0.85464    2.506234    3.130088    2.759486    1.4364  0.639863    2440];
        q2slip=[-0.415984  0.350907  -0.269922  -1.317095  0.162645  -0.35934   -1.089385   -0.605091   -1.198838   -0.137862   -1440];
        Cslip=[0.18313  0.34453 0.045  0.08937  0.30083 0.08407 0.08633 0.08393 0.11866 0.10493 4.7*10^(-6)];
        ba=0.3232;bc=0.5147;bca=0.6078;%%%Ungar 07
        tizr=0;

        %%%Mg
            case 'Magnesium'
        q1slip=[0.067864 -1.14306 4.880886  3.055985 -0.86223 1.750516 3.501807 2.081515 1.191931 1.321473 -2471.84];
        q2slip=[-0.19759  0.326649 1.079577 -1.01943 0.170791 0.248391 -0.66875 -0.03236 -1.008 -0.91879 1412.024];
        Cslip=[0.19483 0.33713 0.03967 0.08297 0.2986 0.08233 0.0817 0.0816 0.12366  0.38948 -2.3e-04];
        ba=0.295;bc=0.468;bca=(ba^2+bc^2)^0.5;    
        
            case 'TiAlt1' 
                %    1        2           3               4               5               6           7           8               9           10          11
        q1slip=[-0.101142 -1.19272      3.6161928       2.017177        -0.894009       1.299046    1.89412     1.5270212      0.59492      1.25714     165366];
        q2slip=[-0.102625 0.355623      1.2264112       -0.616631        0.1833109       0.3972469  -0.365739   0.14615        -0.710368    -0.94015    -98611];
        Cslip=[0.20227 0.35387 0.04853 0.10247 0.3118 0.09227 0.09813 0.09323                           0.1444 0.41873 3.61*10^(-6)];
        ba=0.295;bc=0.468;bca=(ba^2+bc^2)^0.5;
        
        tra = 10;
            if tra==10
                %screw A
                q1slip(10)=-0.5738; 
                q2slip(10)=0.3528;
                Cslip(10)= 0.1596;
            elseif tra==11
                %screw B
                q1slip(10)=0.1093;
                q2slip(10)=0.1197;
                Cslip(10)=0.1205;
            end
        tizr=1;
        end
%%
        Burger=[];
        bslip=[ba ba    bc      bca     ba      bca bca bca         ba bca bc];
        f=[0 0 0 0 0 0 0 0 0 0 0];

        ita=1;

        aa=0;
        fof=1;
        for c1=0:fof; f(1)=c1;
            for c2=0:fof; f(2)=c2;
                for c3=0:fof; f(3)=c3;
                    for c4=0:fof; f(4)=c4;
                        for c5=0:fof; f(5)=c5;
                            for c6=0:fof; f(6)=c6;
                                for c7=0:fof; f(7)=c7;
                                    for c8=0:fof; f(8)=c8;
                                        for c9=0:fof; f(9)=c9;
                                            for c10=0:fof; f(10)=c10;
                                                for c11=0:fof; f(11)=c11;
                                                    aa=aa+1;

        q1calct=0;q1calcb=0;q2calct=0;q2calcb=0;
        for n=1:11
            q1calct=q1calct + f(n)*(bslip(n))^2*Cslip(n)*q1slip(n);
            q1calcb=q1calcb + f(n)*(bslip(n))^2*Cslip(n);
            q2calct=q2calct + f(n)*(bslip(n))^2*Cslip(n)*q2slip(n);
            q2calcb=q2calcb + f(n)*(bslip(n))^2*Cslip(n);
        end
        if q1calcb>0 && q2calcb>0
            
% %                  if q1calcb<0.5
% %                      
% %                     q1eff=(q1calct+1)/(q1calcb+1);
% %                  else
                    q1eff = q1calct/q1calcb;
% %                  end
% %                  if q2calcb<0.5
% %                     q2eff=(q2calct+1)/(q2calcb+1);
% %                  else
                     q2eff=q2calct/q2calcb;
% %                  end
        else 
            q1eff=0;
            q2eff=0;
        end

        %%%%%%Checks
                check1=abs(q1eff-q1m);
                check2=abs(q2eff-q2m);

                if check1<c1c && check2<c1c; c12=1; 
                    else c12=0;end

                c3=1; c4=1;
                if abs(q1m)>=1 || abs(q2m)>=1
                    check3=((q1eff/q1m));
                    check4=((q2eff/q2m));

                    if check3>(1-clc2) && check3<(1+clc2); c3=1;
                    else c3=0;end
                    c4=1;
                    if check4>(1-clc2) && check4<(1+clc2); c4=1;
                    else c4=0;end

               end


        % %%% if negative and doesn't work use below
        %         c3=1;c4=1;
        %         if q1eff<0
        %             c12=1; else c12=0; end

         %%%%5
                NA=0;
                for n=1:11
                    NA=NA+f(n);
                end
                if NA>0
                    if c12==1 && c3==1 && c4==1
                fract_c=(f(3)+f(11))/NA;
                fract_ca=(f(4)+f(6)+f(7)+f(8)+f(10))/NA;
                fract_a=(f(1)+f(2)+f(5)+f(9))/NA;
                fract_c_ca_a=[fract_c, fract_ca, fract_a];

                fract_basal=(f(1))/NA;
                fract_pr=(f(2)+f(3)+f(4))/NA;
                fract_py=(f(5)+f(6)+f(7)+f(8))/NA;
                fract_scr=(f(9)+f(10)+f(11))/NA;
                fract_ba_pr_py_scr=[fract_basal, fract_pr, fract_py, fract_scr];

                for n=1:11;
                    fract_ind(ita,:, n)=(f(n))/NA;
                end


                ff(ita,:)=f;
                Burger(ita, :)=fract_c_ca_a;
                Plane(ita, :)=fract_ba_pr_py_scr;
                ita=ita+1;

                    end
                end


                                                end
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end

                SIZ=size(Burger, 1);
%                 if SIZ==0;
%                     OUT=[1/9 1/9 1/9 1/9 1/9 1/9 1/9 1/9 1/9 1/9 1/9]'; 
%                     Burgcomb=[0 0 100];
%                     indiv_comb=[0 0 0 0 0 0 0 0 0 0 0 ];
%                     return;end

clc2=clc2+0.05;
c1c=c1c+.05;

end
%%         aa
        %%%%%%%Burgers mean values
        burg_mpc=[];
        btot=0;
        for ma=1:3
            if isempty(Burger(:,ma)) > 0;
                burg_mpc(ma)=mean(nonzeros(Burger(:,ma)));
            else
                burg_mpc(ma)=0;
            end
            btot=burg_mpc(ma)+btot;
        end
        for ma=1:3
            Burgerres(ma)=100*burg_mpc(ma)/btot;
        end
        
        %%%%%Planes mean values
        btotp=0;
        for ma=1:4
        if length(nonzeros(Plane(:,ma)))>0;
        plane_mpc(ma)=mean(nonzeros(Plane(:,ma)));
        else plane_mpc(ma)=0;end
        btotp=plane_mpc(ma)+btotp;
        end
        for ma=1:4
            planeres(ma)=100*plane_mpc(ma)/btotp;
        end
        
        %%%%Indiv frequency values
        for n=1:11
        sizindi(n)=length(nonzeros(fract_ind(:,1,n)));
        end
        hi=0;
        for n=1:11
            if sizindi(n)>0;
            indiv(:,n)=length(nonzeros(fract_ind(:,1,n)));
            else indiv(:,n)=0;end
            hi=hi+indiv(1,n);
        end
        for n=1:11
            indiv(:,n)=100*indiv(:,n)/hi;
        end
        %%%%%%%%%%Indiv mean values
        hi2=0;
        for n=1:11
            if sizindi(n)>0;
            indiv_mean(:,n)=mean(nonzeros(fract_ind(:,1,n)));
            else indiv_mean(:,n)=0;end
            hi2=hi2+indiv_mean(1,n);
        end
        for n=1:11
            indiv_mean(:,n)=100*indiv_mean(:,n)/hi2;
        end
        %%%%%%%%%%%%
        %%%%%%%%%%Indiv combo values
        hi3=0;
        for n=1:11
            if sizindi(n)>0;
            indiv_comb(:,n)=length(nonzeros(fract_ind(:,1,n)))*mean(nonzeros(fract_ind(:,1,n)));
            else indiv_comb(:,n)=0;end
            hi3=hi3+indiv_comb(1,n);
        end
        for n=1:11
            indiv_comb(:,n)=100*indiv_comb(:,n)/hi3;
        end
        %%%%%%%%%%%%
       
        %%%%%%%%%%%%
        
        quote=['1 B<a> .', '2 Pr<a> .', '3 Pr<c> .', '4 Pr<c+a> .', '5 Py<a> .']
        quote2=['6 Py2<c+a> .', '7 Py3<c+a> .', '8 Py4<c+a> .', '9 Scr<a> .', '10 Scr<c+a> .', '11 Scr<c>']
        indiv;
        Burgerres(4)=0;
        %%%%
        Burgcomb(:,1)=indiv_comb(1,3)+indiv_comb(1,11);
        Burgcomb(:,2)=indiv_comb(1,4)+indiv_comb(1,6)+indiv_comb(1,7)+indiv_comb(1,8)+indiv_comb(1,10);
        Burgcomb(:,3)=indiv_comb(1,1)+indiv_comb(1,2)+indiv_comb(1,5)+indiv_comb(1,9);
        %%
        
        indiv_comb=indiv_comb';

        
%             ba=settings(1,1).lat1/3;
%             bc=settings(1,1).lat2;
%             bca=bc+ba;
            ha=Burgcomb(:,3)/(100*4);
            hca=Burgcomb(:,2)/(100*5);
            hc=Burgcomb(:,1)/(100*2);
            
            b=[ba, ba, bc, bca, ba, bca, bca, bca, ba, bca ,bc]*10;            
            h=[ha, ha, hc, hca, ha, hca, hca, hca, ha, hca, hc];
            %   1   2   3   4   5   6     7     8   9   10  11
            ff=[1 1 3 2 1 2 2 2 1 2 3];
            BB=[ba bca bc]*10;%in Armstrongs
            for n=1:3
                posB{n}=find(n==ff);
                Hav(n)=sum(h(posB{n}));
                Cav(n)=mean(Cslip(posB{n}));
                CB(n)=Hav(n)*Cav(n)*BB(n)^2;
            end
                CBav=sum(CB)
                C_bsq=b.^2*(indiv_comb'.*Cslip)'/100;
                Burgcomb(:,4)=C_bsq;                
                Cav
                Burgcomb(1:3)
       
end