function  [ OUT, all_I]=logWAindi_noSIZE_HCP(selected,num)
%% fits FCs to logWA- indi method HCP version
%% THS 2016 dppa

%% initialises
%loads
load([cd,'/0. variables/phases.mat'],'dsettings')
load([cd,'/0. variables/FC.mat'],'FC','selected','L','delK')

%prefs for HCP -1
qscrew = getdppFCpref('qscrew');
qedge = getdppFCpref('qedge');

q1_lb = qedge(1);   q1_ub = qscrew(1);
q2_lb = qedge(2);   q2_ub = qscrew(2);
qv2 = .5;qv1 = -.7;
% qv1= .5*(q1_lb + q1_ub);
% qv2= .5*(q2_lb + q2_ub);

KWmax = getdppFCpref('KWmax');
KWmin = getdppFCpref('KWmin');
delK = getdppFCpref('delK');

% Fouriers 
a3=0.5/delK;
L2 = L'; %fourier length
A = FC(:,selected);
% sizA=length(A);
lnA=log(A);
st=2;%%starting L
% g
for n=1:length(selected)
    g(n)=1./dsettings(1,1).d(selected(n));
end

%% changes for HCP 2
chk0= 1;
B= pi/2;
l=dsettings(1,1).index(selected,3)';
x=(2/3)*((l./(g*2.95)).^2);
         
%%
% Fit of individual

%% Initial Combined Fits 
options=optimset('tolx',1e-9,'tolf',1e-12);

guesspar=[qv1 12 0.003 qv2];
lb=[q1_lb ,  -7 ,  0  , q2_lb ];
ub=[q1_ub , 10 ,  15  , q2_ub];
               %q1     gs         rho         M      q2
guesspar_all=[qv1,   1e6,       0.05e-4,      3      qv2];   
lb_all      =[q1_lb ,-1e3,      1e-10,        0.1,   q2_lb  ];
ub_all      =[q1_ub, 1e20,      1e20,         10,    q2_ub ];

%% The first fit gets the q-values but could be used as a fit on its own
all_I_together=lsqcurvefit(@allF_together,...
    guesspar_all , L2(st:num), lnA((st:num),:),lb_all,ub_all,options);
all_I_together=lsqcurvefit(@allF_together, ...
    all_I_together , L2(st:num), lnA((st:num),:),lb_all,ub_all,options);


%% defines for linear fit
% q found
qv1=all_I_together(1);
qv2=all_I_together(5);

guesspar(1)=qv1;
guesspar(4)=qv2;

lb(1)=qv1-1e-4;ub(1)=qv1+1e-4;
lb(4)=qv2-1e-4;ub(4)=qv2+1e-4;

for nn=st:num
    guesspar(nn,:)=guesspar(1,:);
end

% 2nd fit gets the gradient and intercept terms (used later)
if length(selected) >2%find a better defirnition of individual or not
    disp('line 64 change')
    all_I(st:num,:)=lsqcurvefit(@allF, ...
        guesspar(st:num,:) , L2(st:num), lnA((st:num),:),lb,ub,options);
    all_I(:,1)=qv1*ones(size( all_I(:,1) ) ) ;
    all_I(:,4)=qv2*ones(size( all_I(:,4) ) ) ;
else 
    disp('Error')
end

%% Individual Fits

% new q
% lb(1)=qv - 1e-4;
% ub(1)=qv+1e-4;

q1_ind=qv1;
q2_ind=qv2;

% %code removed for plas
% CHOI=4;%menu('What C value?','1. from fit of data','2. input','3. intergranular','4. load C values')
        
for n=st:num
    all_I(n,2:3)=lsqcurvefit(@indivF, all_I(n,2:3) ,...
        L2(n), lnA(n,:),lb(2:3),ub(2:3),options);
end
        


%% Fit of strain & size

frst=find( abs(L2-KWmin)==min(abs(L2-KWmin)) ,1);
lst=find( abs(L2-KWmax)==min(abs(L2-KWmax)) ,1);

if lst>num;lst=num;end

%  strain fit
XL_m=( all_I(1:num,3) )./L2(1:num).^2;
posnot=find(all_I(1:num,3)>-inf);
posnot=posnot( posnot>5 & posnot<num );
XL =lsqcurvefit(@Kriv_Wilk, ...
    [6.5e-03 0.5] , log(L2(frst:lst)), XL_m(frst:lst,:));

% get rho
rho=XL(2);Re=exp(XL(1)/rho);
lb=[5 , 1e-07];ub=[3000 , 1e-03];

XL2 =lsqcurvefit(@Wilkens3, ...
    [Re rho] , (L2(frst:lst)), XL_m(frst:lst),lb,ub,options);%.*(L2(frst:lst)).^2';

% get sizes
strain2fit =lsqcurvefit(@strain2FCC, ...
    [1 10 ]  , (L2(posnot)),  all_I(posnot,2) ,[0 0 ],[1e4 1e4 ]);%10e04,options);%.*(L2(frst:lst)).^2';

%% data out
q=[qv1, qv2];
Qstr2=strain2fit(1);
R1str2=strain2fit(2);

%Grom
rho=XL(2);
Re=exp(XL(1)/rho);
M=rho^0.5*Re;

% Wilk
rho(2)=XL2(2)
Re(2)=XL2(1);
M(2)=rho(2)^0.5*Re(2);

RerhoM=[Re(2),rho(2)*1e20*1e-16,M(2)];

C=1+q(1)*x + q(2)*x.^2 ; 

%% update outputs
FCresStr.C = C;
FCresStr.g = g;
FCresStr.chk0 = chk0;
FCresStr.B = B;
FCresStr.q = q;

FCresStr.MGrom = M(1);
FCresStr.MWilk = M(2);
FCresStr.rhoGrom = rho(1)*1e20*1e-16;
FCresStr.rhoWilk = rho(2)*1e20*1e-16;

FCresStr.M = M(1);
FCresStr.rho = rho(1)*1e20*1e-16;

FCresStr.gs = 1e99;
FCresStr.Qstr2 = Qstr2;
FCresStr.R1str2 = R1str2;
FCresStr.a3 = a3;
% FCresStr.allindi = 'ind'
setdppFCpref('allindi','ind')

dppFCpref = getdppFCpref;
FCresStr.dppFCpref = dppFCpref;

OUT = FCresStr;

%% function to fit all together to FCs
function [lnAA, lam]=allF_together(lam, L)
    %defines
    q1_ = lam(1);
    q2_ = lam(5);
    
       
    FCres.gs = lam(2);
    FCres.rho =lam(3);
    FCres.M =lam(4);
    FCres.g =g;
    FCres.B =B;
    FCres.Qstr2 = 0;
    FCres.R1str2 = 1;
    
    C_ =(1+q1_*x + q2_*x.^2)  ; 
    FCres.C = C_;
    %get FCs
FCs_ = get_WAFCs(FCres, L);
    %get outs
lnAA = log(FCs_);

    if min(C_)<0;
        lnAA=-lnAA*1e5;
    end
    
end
%%
function [lnAA ,lam]=allF(lam, L)
        
%     q=lam(1);
%     C=chk0*(1-q*H2)  ; 
    q1 = lam(1);
    q2 = lam(4);
    C=(1+q1*x + q2*x.^2)  ;
    
    for no=1:length(L)
        lnAA(no,:) =  B^2*real(lam(2))*(g.^2.*C).^2 -...
            B*real(lam(no,3))*g.^2.*C ;
    end
    if min(C)<0;
        lnAA=inf*lnAA;
    end
end
%%
function [lnAA ,lam]=indivF(lam, L)

%     q=q_ind;
%     C=chk0*(1-q*H2)  ;      
    q1 = q1_ind ;
    q2 = q2_ind ;
    C=(1+q1*x + q2*x.^2)  ;
    
    lnAA = - B*real(lam(2))*g.^2.*C +...
        B^2*real(lam(1))*(g.^2.*C).^2;
    
    if min(C)<0;
        lnAA=inf*lnAA;
    end
end 


%%
function [AA, lam]=strain2FCC(lam, L)
    Q=lam(1);
    R1=lam(2);
    
    
    AA = Q * L.^4 .* log(R1./L);

end 

%%
function [XL, lam]=Kriv_Wilk(lam,lnL)
    for n=1:length(lnL)
        XL(n,:) = lam(1) -lam(2)*lnL(n,:);
    end
end
%%
function [fout, Rerho] = Wilkens3(Rerho, L)
    Re_ = Rerho(1); rho_ = Rerho(2);
    fout =get_Wilkens(Re_, L);
    fout = fout * rho_;
end
%%
end