function  [OUT , all_I]=alternative(selected,num)
%% fits FCs to logWA- indi method
%% THS 2016 dppa

%% initialises
%loads
load([cd,'/0. variables/phases.mat'],'dsettings')
load([cd,'/0. variables/FC.mat'],'FC','selected','L','delK')

%prefs
qscrew = getdppFCpref('qscrew');
qedge = getdppFCpref('qedge');
qv=.5*(qscrew+qedge);
KWmax = getdppFCpref('KWmax');
KWmin = getdppFCpref('KWmin');
delK = getdppFCpref('delK');

%defines
chk0= getdppFCpref('chk0');
B= getdppFCpref('B');
a3=0.5/delK;
H2=Hsq(dsettings(1,1).index(selected,:));
C=chk0*(1-qv*H2)  ; 
% Fouriers 
L2 = L'; %fourier length
A = FC(:,selected);
% sizA=length(A);
lnA=log(A);
st=2;%%starting L
% g
for n=1:length(selected)
    g(n)=1./dsettings(1,1).d(selected(n));
end

%% create Li variable 
xx=1;
for n=1:length(selected)
    Li(:,n)=L*g(n)./g(xx);
end
a3_new=2.5;
Linterp=0:a3_new:1300;
%% create new A values 
for n=1:length(selected)
    Anew(:,n) = interp1(Li(:,n),A(:,n),Linterp)';
end
% lo is equivalent to sample_n but for Linterp- increase steps 
lo=find(Anew(:,1)==0,1)-10;
posval=1:15:lo;

%% some plots

figure(16)
if ishold==1;hold;end
plot(L,(A),'-','linewidth',2)
hold on
plot(Linterp,(Anew),'--','linewidth',2),
hold off
legend('111','222','111 Li','222 Li')
set(gca,'fontsize',17)
xlabel('Fourier length L (10^-^1^0m)','fontsize',17)
ylabel('Fourier coeficients','fontsize',17)

xlim([0 2.2*500])
 

%% fit each line to get size (column 1) and strain (column 2) 
guesspar=[ 0.5 1 ];
options=optimset('tolx',1e-9,'tolf',1e-12);
for n=2:lo
    all_I(n,:)=lsqcurvefit(@logalt, guesspar ,g , log(Anew(n,:)) );
end
all_I(:,2)=-all_I(:,2);



 
%% more plots 
figure(33)
if ishold==1;hold;end
plot(Linterp(1:lo),exp(all_I(:,1)) ,'.-'),hold on
plot(Linterp(1:lo),exp(-all_I(:,2)) ,'.-r') 
hold off
ylim([0 2])
legend('size','strain')
title('size strain fcs')

figure(26)
for ii=2:4:42
plot( g(1)./g , log(Anew(ii,:)) ,'o','linewidth',2,'markersize',8)
hold on
end

gx = 0:0.1:1;
for ii=2:4:42
   lnAll = gx*all_I(ii,1) - all_I(ii,2); 
   plot( gx , lnAll ,'-','linewidth',2) 
end
hold off

figure(16)
hold on
for ii=1:2
   lnAll = g(1)./g(ii) *all_I(:,1) - all_I(:,2); 
   plot( Linterp(2:length(lnAll)) , exp(lnAll(2:end)) ,'-') 
end
hold off
%% strain fit

frst=find( abs(Linterp-KWmin)==min(abs(Linterp-KWmin)) ,1);
lst=find( abs(Linterp-KWmax)==min(abs(Linterp-KWmax)) ,1);

if lst>lo-1;lst=lo;end
XL_m=( all_I(1:lo,2) )./Linterp(1:lo).^2';
XL =lsqcurvefit(@Kriv_Wilk, [-6.5e-03 0.5] , log(Linterp(frst:lst)),...
    XL_m(frst:lst,:));

rho=XL(2);
Re=exp(XL(1)/rho);

lb=[5 , 1e-07];ub=[3000 , 1e-03];
XL2 =lsqcurvefit(@Wilkens3, [Re, rho] , (L2(frst:lst)), XL_m(frst:lst),lb,ub,options);%.*(L2(frst:lst)).^2';

M=rho^0.5*Re
rho=rho*1e4

XL_d=Kriv_Wilk(XL,log(Linterp(1:lo)));

%% sizes fit
Lmax = L(num);
posnot=find(Linterp < Lmax );

sizefit =lsqcurvefit(@sizeFC, 300  , (Linterp(posnot)'), exp( all_I(posnot,1) ),[0 ],[100000000],options);%10e04,options);%.*(L2(frst:lst)).^2';



%% more plots
figure(6),if ishold==1;hold;end
semilogx((Linterp(1:lo)), XL_m(1:lo,:) ,'o'),hold
plot((Linterp(1:lo)),XL_d(1:lo,:))


%% interpolate back to orignial
Lmax = Linterp(lo)-1;
Lvals = find(abs(L-Lmax)==min(abs(L-Lmax),1));
for n=1:2
   all_Inew(:,n) = interp1(Linterp(1:lo),all_I(:,n),L(1:Lvals))';
end
all_I=[];
all_I(:,3)=(all_Inew(:,2));
all_I(:,2)=(all_Inew(:,1));
all_I(:,1)=qv*ones( size(all_Inew(:,1) ));

%% data out
q=qv;
gs=sizefit(1);

%Grom
rho=XL(2);
Re=exp(XL(1)/rho);
M=rho^0.5*Re;

% Wilk
rho(2)=XL2(2)
Re(2)=XL2(1);
M(2)=rho(2)^0.5*Re(2);

C=chk0*(1-q*H2)  ; 

%% update outputs
FCresStr.C = C;
FCresStr.g = g;
FCresStr.chk0 = chk0;
FCresStr.B = B;
FCresStr.q = q;

FCresStr.MGrom = M(1);
FCresStr.MWilk = M(2);
FCresStr.rhoGrom = rho(1)*1e20*1e-16;
FCresStr.rhoWilk = rho(2)*1e20*1e-16;

FCresStr.M = M(1);
FCresStr.rho = rho(1)*1e20*1e-16;

FCresStr.gs = gs * 1e-4;
FCresStr.a3 = a3;
% FCresStr.allindi = 'ind'
setdppFCpref('allindi','ind')

dppFCpref = getdppFCpref;
FCresStr.dppFCpref = dppFCpref;

OUT = FCresStr;

%%

    function [lnAA, lam]=logalt(lam, g)
        
                lnAS=lam(1);
                lnAD=lam(2);
                lnAA = (lnAD*(B*C)) + lnAS*(g(xx)./g) ;
    end

    function [AA, lam]=linalt(lam, g)
        
                lnAS=lam(1);
                lnAD=lam(2);
                AA = exp(lnAD*(B*C)) .* (1  - (g(xx)./g)* (1-exp(lnAS))  );
    end
    
end
   %% 
function [XL, lam]=Kriv_Wilk(lam,lnL)
    for n=1:length(lnL)
    XL(n,:) = lam(1) -lam(2)*lnL(n);
    end
end

function [fout, Rerho] = Wilkens3(Rerho, L)
    Re_ = Rerho(1); rho_ = Rerho(2);
    fout =get_Wilkens(Re_, L);
    fout = fout * rho_;
end

function [AA, lam]=sizeFC(lam, L)

    AA = exp(-L/lam(1) );
end

