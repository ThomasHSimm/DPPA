function create_index(sym,krange)

if strcmp(sym,'bcc')
    
    
elseif strcmp(sym,'fcc')
%    111, 200, 220, 311, 222
% all odd or all even
    
end




end