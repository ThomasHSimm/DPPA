function F= pv_tv(lam0, x)
global alpha2
len=length(lam0);
npks=(len-3)/4;
F=zeros(size(x));

for n=1:npks
    k=1+(n-1)*4;
    lam(1:4)=lam0(k:k+3);
    if alpha2==1
    [fia lam]=pk_voigt2(x,lam); %if no alpha2 present
    elseif alpha2==0
    [fia lam]=pk_alpha(x,lam);
    end
    F=F+fia;
end

backgd =  lam0(len-2) + x*lam0(len-1) + lam0(len)*x.^2;
F=F+backgd;
