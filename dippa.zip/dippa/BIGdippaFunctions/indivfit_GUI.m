function indivfit_GUI(n, val, haxes)
%% fitting of indiv peaks
%% THS 2016 dppa

%initialises
load([cd,'/0. variables/phases.mat'],'dsettings')
datainstr=getDPPApref('datainstr');
fitsiz=getDPPApref('sizfit');
logplot=getDPPApref('logplot');

if strcmp(datainstr, 'Sampl')
if val==2 
    n=length(dsettings(1,1).d)+n;
end
end


if strcmp(datainstr, 'Instr')
    %%
    load([cd,'/0. variables/data_I.mat'],'data_I')
    load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
        
              
        incretth=data_I(2,1)-data_I(1,1);
        incretth=double( int16(incretth/1e-5 ))*1e-05;
        posdelK=fitsiz/incretth;
        aa2=aa_I;
        adjtth=abs(data_I(:,1)-aa_I(1,n));
        peakpos=find(adjtth==min(adjtth));
        clear adjtth
        I=data_I(:,2) ;
 
        posb4=peakpos-posdelK;if posb4<1;posb4=1 ;end
        posa4=peakpos+posdelK;if posa4>size(data_I,1);posa4=size(data_I,1);end

        I=I(posb4:posa4);

        delxp=abs( aa_I(1,:)-aa_I(1,n) );    
        aapos=find( delxp<fitsiz );
        lenaa=size(aa_I,2);

        fpos=find(aapos==n);%which peak is changing
 
        
        aapos(end+1)=lenaa;
        tth=data_I((posb4:posa4), 1);
        I  =  I + pv_tv_aa([aa2(:,aapos(1:end-1)),zeros(size(aa_I(:,1)))],data_I((posb4:posa4), 1)) -  pv_tv_aa(aa2(:,:),data_I((posb4:posa4), 1));
        %I = intensity + fit_of_close(inc_bcg) - fit_of_all(inc_bcg) 
        aa_I(1:4,lenaa)=[I(1) 0 0 fpos]';
        lam0=aa_I(:,aapos);
        aa_I(1:2,end)=aabcg_I(:,aapos(fpos(1)));
        
        aa_I(:,aapos)=onepeak(tth, I, aa_I(:,aapos));
        
%         aa(5:6,:)=aa(3:4,:);
%         aa(:,end)=0*aa(:,end);
        aapeak=aa_I(:,aapos);
        IIfit=pv_tv_aa(aapeak,data_I((posb4:posa4), 1));
        
        hold(haxes,'off')
        if logplot==0
            plot(data_I(posb4:posa4,1),I,...
                'parent',haxes)
        else
            semilogy(data_I(posb4:posa4,1),I,...
                'parent',haxes)
        end
        hold(haxes,'on')
        plot(tth,IIfit,'m',...
            'parent',haxes)
        hold(haxes,'off')
        aabcg_I(:,n)=aa_I(1:2,lenaa);
        aa_I(1:4,end)=aa2(1:4,end);

        %save data
        save([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')

elseif strcmp(datainstr, 'Sampl')
        %%
        load([cd,'/0. variables/data.mat'],'data')
        load([cd,'/0. variables/fit.mat'],'aa','aabcg')
        
        incretth=data(2,1)-data(1,1);
        incretth=double( int16(incretth/1e-5 ))*1e-05;
        posdelK=fitsiz/incretth;
        aa2=aa;
        adjtth=abs(data(:,1)-aa(1,n));
        peakpos=find(adjtth==min(adjtth));
        clear adjtth
        I=data(:,2) ;
        
        posb4=peakpos-posdelK;if posb4<1;posb4=1 ;end
        posa4=peakpos+posdelK;if posa4>size(data,1);posa4=size(data,1);end

        I=I(posb4:posa4);

        delxp=abs( aa(1,:)-aa(1,n) );    
        aapos=find( delxp<fitsiz );
        lenaa=size(aa,2);

        fpos=find(aapos==n);%which peak is changing
 
        aapos(end+1)=lenaa;
        tth=data((posb4:posa4), 1);
        %I = intensity + fit_of_close(inc_bcg) - fit_of_all(inc_bcg) 
        I  =  I + pv_tv_aa([aa2(:,aapos(1:end-1)),zeros(size(aa(:,1)))],data((posb4:posa4), 1)) ...
            -  pv_tv_aa(aa2(:,:),data((posb4:posa4), 1));
        
        aa(1:4,lenaa)=[I(1) 0 0 fpos]';
        lam0=aa(:,aapos);
        aa(1:2,end)=aabcg(:,aapos(fpos(1)));
        
        aa(:,aapos)=onepeak(tth, I, aa(:,aapos));
        

        aapeak=aa(:,aapos);
        IIfit=pv_tv_aa(aapeak,data((posb4:posa4), 1));
        
        hold(haxes,'off')
        if logplot==0
            plot(data(posb4:posa4,1),I,...
                'parent',haxes)
        else
            semilogy(data(posb4:posa4,1),I,...
                'parent',haxes)
        end
        hold(haxes,'on')
        plot(tth,IIfit,'m',...
            'parent',haxes)
        hold(haxes,'off')
        
        aabcg(:,n)=aa(1:2,lenaa);
        aa(1:4,end)=aa2(1:4,end);
        
        grid(haxes,'on')
        %saves
        save([cd,'/0. variables/fit.mat'],'aa','aabcg')
        
end

end