function [fsum , lambda ]=pk_alpha(x,lambda)
%% fits for peaks with alpha1 + alpha2
%% THS 2016 dppa
                    %%%%lambda or 'a' gives the voight parameters lam(1:4)
                    %%%%f gives the intensities from the voight
tube = getDPPApref('tube');

if tube=='Cu'
    alphadiff_lam=0.00383;
    wavelen=(1.54056+	1.54439)/2;
    alphadiff=lambda(1)*alphadiff_lam/wavelen;
    %%1.54056	1.54439  for Cu
elseif  tube=='Co'
    LabdaAlpha1=  1.789010;%1.78897;
    LabdaAlpha2=  1.792900;%1.79285;
%     LabdaAlphaS=  1.78897-0.0075;
    wavelen=(LabdaAlpha1+LabdaAlpha2)/2;
    alphadiff_lam=(LabdaAlpha2-LabdaAlpha1);
%     alphadiff=1.78901-1.79290;
    alphadiff=lambda(1)*alphadiff_lam/wavelen;
    
    
%     alphadiff_lam2=(LabdaAlphaS-LabdaAlpha1);
%     alphadiff2=lambda(1)*alphadiff_lam2/wavelen;
end

	[f , lam]=pk_voigt2(x,lambda);
    lambda2=lambda;
    lambda2(1)=lambda(1)+alphadiff;
    lambda2(2)=0.5*lambda(2);
    [f2, lam2]=pk_voigt2(x,lambda2);
	
%     lambda2=lambda;
%     lambda2(1)=lambda(1)+alphadiff2;
%     lambda2(2)=0.5*(1.6/57)*lambda(2);
%     lambda2(3)=lambda(3)*0.4*(3.69/0.5);
%     [f3 lam2]=pk_voigt2(x,lambda2);
    fsum=f+f2;%+f3;
        
end       
        
        
        
%%%lam(1) ==x0
%%%lam(2) ==PHI0  intensity
%%%lam(3) ==FWHM
%%%lam(4) ==neta (0->1 gauss->lorentz)
%%%%f intensity
%%%%x twotheta values
             