function I_all=bcgmin(sample_n, selected, I_all)
%%


ff=6;
bcg=zeros(1,2);
I_all_ = I_all(:,:,:);
I_all_(1,1,4) = selected;
I_all_(2,1,4) = ff;
lb=-.2;ub=.2;
options=optimset('tolx',1e-4,'tolf',1e-222,'tolFun',1e-20);
bcg = lsqcurvefit(@bcgmin_f, bcg , I_all_,[0, 0, 0],...
    lb, ub, options)

I_all(:,selected,1) = I_all(:,selected,1) + bcg(1);        
I_all(:,selected,2) = I_all(:,selected,2) + bcg(2);

end
%%
function erro=bcgmin_f(lam, I_all)
        I_all(:,:,1)=I_all(:,:,1)+lam(1);   %measured     
        I_all(:,:,2)=I_all(:,:,2)+lam(2);   %instr
        
        selected = I_all(1,1,4);
        ff=I_all(2,1,4);
        
        [   FCi,  FCnew, FCm]=ts_findfourier_indi(selected,I_all);
        FCi = FCi(:, selected);
        FCnew = FCnew(:, selected);
        FCm = FCm(:, selected);
        

        
        lb=0;ub=inf;
        
        L=0:1:ff-1;L=L'*25;
        if exist('xf1')==0;xf1=500;end
        if exist('xf2')==0;xf2=500;end        
        if exist('xf3')==0;xf3=500;end
        
        [xf1 , erro1]=lsqcurvefit(@gauss,xf1, L,FCnew(1:ff),lb,ub);
        [xf2 , erro2]=lsqcurvefit(@gauss,xf2, L,FCm(1:ff),lb,ub)
        [xf3 , erro3]=lsqcurvefit(@gauss,xf3, L,FCi(1:ff),lb,ub);
        
        erro=[erro1, erro2, erro3];
        
                
end
    
    
%%
    function GA=gauss(lam0,L)
        GA=1-L/lam0;

    end
