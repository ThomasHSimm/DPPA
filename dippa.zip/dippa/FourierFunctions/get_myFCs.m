function [OUT0 OUT1 OUT2] = get_myFCs(selected_v)
%% get FCs
%% THS 2016

if nargin==0
    valuee = getdppFCpref('selected');
else
    valuee = selected_v;
end
    
%loads
load([cd,'/0. variables/FC_Iall.mat'],'I_all')
%some prefs

sample_n = getdppFCpref('sample_n');

if length(valuee)>size(I_all,2);
    valuee=1:1:size(I_all,2);selected=valuee;
elseif length(valuee)==0
    valuee=1:1:size(I_all,2);selected=valuee;
end
selected = valuee;
FClen=size(I_all,1);

for nn=1:length(valuee)
    n=valuee(nn);
% for n=1:size(I_all,2)
    FC_I(:,n)=fft(I_all(:,n,2),FClen);
    FC_I(:,n)=FC_I(:,n)/max(abs(FC_I(:,n)));


    FC(:,n)=fft(I_all(:,n,1),FClen);
    FC(:,n)=FC(:,n)/max(abs(FC(:,n)));
    FC_R(:,n)=FC(:,n)./FC_I(:,(n));
    
    FC_R2=zeros(size(FC_R(:,n)));
    
    
    usedL=sample_n;
    
    %%make FC consist of 1st part ad last part of the deconvoluted
    %%FCs--rest is zero
    
    FC_R2(1:usedL)=FC_R(1:usedL,n);
    FC_R2(end-usedL:end)=FC_R(end-usedL:end,n);
    FC_R(:,n)=(FC_R2);
    FC_Rreal(:,n)=abs(FC_R(:,n));
    clear FC_R2
    I_R(:,n)=reverse(ifft(FC_R(:,n)));
    I_Rreal(:,n)=reverse(ifft( FC_Rreal(:,n)));
    
    FC_R(:,n)=abs( FC_R(:,n) )./max(abs( FC_R(1,n) ));
    
    
end

for n=1:size(FC,2)
    OUT0(:,n)= abs(FC_I(:,n ))/abs(FC_I(1,n ));
    OUT2(:,n)= abs(FC(:,n  ))/abs(FC(1,n));
    OUT1(:,n)=FC_R(:,n);

end




clear data adjtth lam0 Ipeak

end

function Iout=reverse(I)

len=length(I);lenhalf=(len+1)/2;
Iout=I;
Iout(1:lenhalf)=I(lenhalf:end);
Iout(lenhalf+1:end)=I(1:lenhalf-1);
Iout=abs(real(Iout));Iout=Iout/max(Iout);


end