function  [ OUT, all_I]=logWAindi(selected,num)
%% fits FCs to logWA- indi method
%% THS 2016 dppa

%% initialises
%loads
load([cd,'/0. variables/phases.mat'],'dsettings')
load([cd,'/0. variables/FC.mat'],'FC','selected','L','delK')

%prefs
qscrew = getdppFCpref('qscrew');
qedge = getdppFCpref('qedge');
qv=.5*(qscrew+qedge);
KWmax = getdppFCpref('KWmax');
KWmin = getdppFCpref('KWmin');
delK = getdppFCpref('delK');

%defines
chk0= getdppFCpref('chk0');
B= getdppFCpref('B');
a3=0.5/delK;
H2=Hsq(dsettings(1,1).index(selected,:));

% Fouriers 
L2 = L'; %fourier length
A = FC(:,selected);
% sizA=length(A);
lnA=log(A);
st=2;%%starting L
% g
for n=1:length(selected)
    g(n)=1./dsettings(1,1).d(selected(n));
end
         
%%
% Fit of individual

%% Initial Combined Fits 
options=optimset('tolx',1e-9,'tolf',1e-12);
guesspar=[qv -0.05 0.003];
lb=[qedge*.8 -7 0   ];
ub=[qscrew*1.2 -1e-34 15 ];
guesspar_all=[qv,   1e6,    0.05e-4,      3];   %q gs rho  M
lb_all      =[lb(1), 1e-10,  1e-10,        0.1];
ub_all      =[ub(1), 1e20,   1e20,       10];

%% The first fit gets the q-values but could be used as a fit on its own
all_I_together=lsqcurvefit(@allF_together, guesspar_all , L2(st:num), lnA((st:num),:),lb_all,ub_all,options);
all_I_together=lsqcurvefit(@allF_together, all_I_together , L2(st:num), lnA((st:num),:),lb_all,ub_all,options);


%% defines for linear fit
% q found
qv=all_I_together(1);
guesspar(1)=qv;
lb(1)=qv-1e-4;ub(1)=qv+1e-4;

for nn=st:num
    guesspar(nn,:)=guesspar(1,:);
end

% 2nd fit gets the gradient and intercept terms (used later)
if length(selected) >2%find a better defirnition of individual or not
    disp('line 64 change')
    all_I(st:num,:)=lsqcurvefit(@allF, guesspar(st:num,:) , L2(st:num), lnA((st:num),:),lb,ub,options);
    all_I(:,1)=qv*ones(size( all_I(:,1) ) ) ;
else 
    all_I(st:num,2:3)=lsqcurvefit(@allFindividual, guesspar(st:num,2:3) , L2(st:num), lnA((st:num),:),lb,ub,options);
    qv=1.92;
    all_I(:,1)=qv*ones(size( all_I(:,1) ) ) ;
end

%% Individual Fits

% new q
lb(1)=qv - 1e-4;
ub(1)=qv+1e-4;
q_ind=qv;

% %code removed for plas
% CHOI=4;%menu('What C value?','1. from fit of data','2. input','3. intergranular','4. load C values')
        
for n=st:num
    all_I(n,2:3)=lsqcurvefit(@indivF, all_I(n,2:3) ,...
        L2(n), lnA(n,:),lb(2:3),ub(2:3),options);
end
        


%% Fit of strain & size

            
frst=find( abs(L2-KWmin)==min(abs(L2-KWmin)) ,1);
lst=find( abs(L2-KWmax)==min(abs(L2-KWmax)) ,1);

if lst>num;lst=num;end

%  strain fit
XL_m=( all_I(1:num,3) )./L2(1:num).^2;
posnot=find(all_I(1:num,3)>-inf);
posnot=posnot( posnot>5 & posnot<num );
XL =lsqcurvefit(@Kriv_Wilk, [6.5e-03 0.5] , log(L2(frst:lst)), XL_m(frst:lst,:));

% get rho
rho=XL(2);Re=exp(XL(1)/rho);
lb=[5 , 1e-07];ub=[3000 , 1e-03];

XL2 =lsqcurvefit(@Wilkens3, [Re rho] , (L2(frst:lst)), XL_m(frst:lst),lb,ub,options);%.*(L2(frst:lst)).^2';

% get sizes
sizefit =lsqcurvefit(@sizeFC, 300  , (L2(posnot)), exp( all_I(posnot,2) ),[0 ],[100000000],options);%10e04,options);%.*(L2(frst:lst)).^2';


%% data out
q=qv;
gs=sizefit(1);

%Grom
rho=XL(2);
Re=exp(XL(1)/rho);
M=rho^0.5*Re;

% Wilk
rho(2)=XL2(2)
Re(2)=XL2(1);
M(2)=rho(2)^0.5*Re(2);

RerhoM=[Re(2),rho(2)*1e20*1e-16,M(2)];

C=chk0*(1-q*H2)  ; 

%% update outputs
FCresStr.C = C;
FCresStr.g = g;
FCresStr.chk0 = chk0;
FCresStr.B = B;
FCresStr.q = q;

FCresStr.MGrom = M(1);
FCresStr.MWilk = M(2);
FCresStr.rhoGrom = rho(1)*1e20*1e-16;
FCresStr.rhoWilk = rho(2)*1e20*1e-16;

FCresStr.M = M(1);
FCresStr.rho = rho(1)*1e20*1e-16;

FCresStr.gs = gs * 1e-4;
FCresStr.a3 = a3;
% FCresStr.allindi = 'ind'
setdppFCpref('allindi','ind')

dppFCpref = getdppFCpref;
FCresStr.dppFCpref = dppFCpref;

OUT = FCresStr;

%% function to fit all together to FCs
function [lnAA, lam]=allF_together(lam, L)
    %defines
    q_ = lam(1);
    FCres.q = q_;
    FCres.gs = lam(2);
    FCres.rho =lam(3);
    FCres.M =lam(4);
    FCres.g =g;
    FCres.B =B;
    
    FCres.C=chk0*(1-q_*H2)  ;

    %get FCs
FCs_ = get_WAFCs(FCres, L);
    %get outs
lnAA = log(FCs_);
    
end
%%
function [lnAA ,lam]=allF(lam, L)
        
    q=lam(1);
    C=chk0*(1-q*H2)  ;      

    for no=1:length(L)
        lnAA(no,:) = (lam(no,2)) - ...
            B*real(lam(no,3))*g.^2.*C ;
    end
    if min(C)<0;
        lnAA=inf*lnAA;
    end
end
%%
function [lnAA ,lam]=indivF(lam, L)

    q=q_ind;
    C=chk0*(1-q*H2)  ;      

    lnAA = (lam(1)) - B*real(lam(2))*g.^2.*C ;
    
    if min(C)<0;
        lnAA=inf*lnAA;
    end
end 

%% if peaks of same type i.e. no contrast 
function [lnAA, lam]=allFindividual(lam, L)   

    for no=1:length(L)
        lnAA(no,:) = (lam(no,1)) -...
            B*real(lam(no,2))*g.^2.*C ;
    end
    if min(C)<0;
        lnAA=inf*lnAA;
    end
end
%%
function [AA, lam]=sizeFC(lam, L)
        
    AA = exp(-L/lam(1) );
end 

%%
function [XL, lam]=Kriv_Wilk(lam,lnL)
    for n=1:length(lnL)
        XL(n,:) = lam(1) -lam(2)*lnL(n,:);
    end
end
%%
function [fout, Rerho] = Wilkens3(Rerho, L)
    Re_ = Rerho(1); rho_ = Rerho(2);
    fout =get_Wilkens(Re_, L);
    fout = fout * rho_;
end
%%
end