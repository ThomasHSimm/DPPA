function [A, AS, AD]=get_logWA(FCres, L)
%% gets Fourier coeffecients using logWA form 
%% options type_size, type_strain
%% THS 2016 dppa




end