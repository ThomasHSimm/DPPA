function [A, AS, AD]=get_WAFCs(FCres, L, type_size, type_strain, type_sizestrain)
%% gets Fourier coeffecients using logWA form 
%% options type_size, type_strain
%% THS 2016 dppa
if nargin==2
    type_sizestrain = getdppFCpref('type_sizestrain');
    type_strain = 'other';%getdppFCpref('type_strain');
    type_size = getdppFCpref('type_size');
end

gs = FCres.gs;

if strcmp(type_strain, 'Grom')==1
    rho = FCres.rhoGrom;
    M = FCres.MGrom;
    
elseif strcmp(type_strain, 'Wilk')==1
    rho = FCres.rhoWilk;
    M = FCres.MWilk;
    
elseif strcmp(type_strain, 'other')==1
    rho = FCres.rho;
    M = FCres.M;
    type_strain = getdppFCpref('type_strain');
end

% rho = FCres.rho;
% M = FCres.M;

g = FCres.g;
C = FCres.C;
B = FCres.B;

AD = get_strainFCs(rho, M, B, L, g, C, type_strain);

AS = get_sizeFCs(gs, L, type_size, length(g));


switch type_sizestrain
    
    case 'logWA'
        lnA = log(AS) +log(AD);  
        A = exp( lnA );
        
    case 'linWA'
        A = AS * (1 - log(AD));  
        
    case 'none'
        Qstr2 = FCres.Qstr2 ;
        R1str2 = FCres.R1str2 ;
        A = get_GromSQ_strainFCs(rho,...
            M, B, L, g, C, Qstr2, R1str2, type_strain) ;

end