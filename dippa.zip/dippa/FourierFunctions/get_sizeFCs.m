function AS = get_sizeFCs(gs, L, type_size, lenAS)
%% gets size Fourier coeffecients- two types Cauchy and log-norm
%% THS 2016 dppa

gs = gs *1e4;

if nargin==3
    lenAS = 1;
end

switch type_size
    case 'Cauchy'
        for ii = 1 : lenAS
            AS(:,ii) = exp( -L/gs );
        end
        
    case 'logNorm'
        
end


end