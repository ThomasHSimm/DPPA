function varargout = dippaFC(varargin)
% DIPPAFC MATLAB code for dippaFC.fig
%      DIPPAFC, by itself, creates a new DIPPAFC or raises the existing
%      singleton*.
%
%      H = DIPPAFC returns the handle to a new DIPPAFC or the handle to
%      the existing singleton*.
%
%      DIPPAFC('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DIPPAFC.M with the given input arguments.
%
%      DIPPAFC('Property','Value',...) creates a new DIPPAFC or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before dippaFC_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to dippaFC_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help dippaFC

% Last Modified by GUIDE v2.5 06-Jul-2016 18:07:50

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @dippaFC_OpeningFcn, ...
                   'gui_OutputFcn',  @dippaFC_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before dippaFC is made visible.
function dippaFC_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to dippaFC (see VARARGIN)

% Choose default command line output for dippaFC
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes dippaFC wait for user response (see UIRESUME)
% uiwait(handles.figure1);

imshow('Billetsandbillets2v.png','parent',handles.axes2)
imshow('big-dipper.png','parent',handles.axes1)
path('BIGdippaFunctions',path)
path('FourierFunctions',path)

%% set prefs
startup_dppaFC
startup_DPPA
%% update GUI
dppFCpref = getdppFCpref; 

set(handles.sample_n_t, 'string',dppFCpref.sample_n)
set(handles.delK_t, 'string',dppFCpref.delK)
set(handles.semilog_b, 'value',dppFCpref.semilogq)

switch dppFCpref.type_strain
    case 'Grom'
        set(handles.strain_l,'value',1)
    case 'Wilk'
        set(handles.strain_l,'value',2)   
end

switch dppFCpref.type_sizestrain
    case 'logWA'
        set(handles.sizestrain_l,'value',1)
    case 'linWA'
        set(handles.sizestrain_l,'value',2)   
    case 'altrn'
        set(handles.sizestrain_l,'value',3)
    case 'none'
        set(handles.sizestrain_l,'value',4)
end

set(handles.KWmin_t, 'string',dppFCpref.KWmin)
set(handles.KWmax_t, 'string',dppFCpref.KWmax)

set(handles.qhi_t, 'string',dppFCpref.qscrew)
set(handles.qlo_t, 'string',dppFCpref.qedge)
set(handles.C200_t, 'string',dppFCpref.chk0)

% --- Outputs from this function are returned to the command line.
function varargout = dippaFC_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in menu_l.
function menu_l_Callback(hObject, eventdata, handles)
% hObject    handle to menu_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns menu_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from menu_l

% Menu:
% 1. Load/Save
% 2. Settings
% 3. Find Fourier Coeffs.
% 4. Fit 
% 5. Results
% 6. All results

val=get(hObject,'value')-1;

switch val
    
    case 0% menu
        set(handles.loadsave_p,'visible','off')
        set(handles.FCset_p,'visible','off')
        set(handles.WA_p,'visible','off')
        set(handles.axes_p,'visible','off')
        set(handles.fitta_p,'visible','off')
        set(handles.about_p,'visible','off')
        set(handles.results_p,'visible','off')
        set(handles.editpks_p,'visible','off')
        set(handles.resall_p,'visible','off')
        
    case 1 % load / save
        set(handles.loadsave_p,'visible','on')
        set(handles.FCset_p,'visible','off')
        set(handles.WA_p,'visible','off')
        set(handles.axes_p,'visible','on')
        set(handles.fitta_p,'visible','off')
        set(handles.about_p,'visible','off')
        set(handles.results_p,'visible','off')
        set(handles.editpks_p,'visible','off')
        set(handles.resall_p,'visible','off')
        
    case 2 % settings
        set(handles.loadsave_p,'visible','off')
        set(handles.FCset_p,'visible','on')
        set(handles.WA_p,'visible','off')
        set(handles.axes_p,'visible','off')
        set(handles.fitta_p,'visible','off')
        set(handles.about_p,'visible','off')
        set(handles.results_p,'visible','off')
        set(handles.editpks_p,'visible','off')
        set(handles.resall_p,'visible','off')
        
    case 3 %fc
        set(handles.loadsave_p,'visible','off')
        set(handles.FCset_p,'visible','off')
        set(handles.WA_p,'visible','on')
        set(handles.axes_p,'visible','on')
        set(handles.fitta_p,'visible','off')
        set(handles.about_p,'visible','off')
        set(handles.results_p,'visible','off')
        set(handles.editpks_p,'visible','on')
        set(handles.resall_p,'visible','off')
        
    case 4 %fit
        set(handles.loadsave_p,'visible','off')
        set(handles.FCset_p,'visible','off')
        set(handles.WA_p,'visible','off')
        set(handles.fitta_p,'visible','on')
        set(handles.axes_p,'visible','on')
        set(handles.about_p,'visible','off')
        set(handles.results_p,'visible','off')
        set(handles.editpks_p,'visible','off')
        set(handles.resall_p,'visible','off')
        
    case 5%res
        set(handles.loadsave_p,'visible','off')
        set(handles.FCset_p,'visible','off')
        set(handles.WA_p,'visible','off')
        set(handles.fitta_p,'visible','off')
        set(handles.axes_p,'visible','on')
        set(handles.about_p,'visible','off')
        set(handles.results_p,'visible','on')   
        set(handles.editpks_p,'visible','off')
        set(handles.resall_p,'visible','off')
        
    case 6%resall
        set(handles.loadsave_p,'visible','off')
        set(handles.FCset_p,'visible','off')
        set(handles.WA_p,'visible','off')
        set(handles.fitta_p,'visible','off')
        set(handles.axes_p,'visible','on')
        set(handles.about_p,'visible','off')
        set(handles.results_p,'visible','off')   
        set(handles.editpks_p,'visible','off')
        set(handles.resall_p,'visible','on')
        
    case 7 %about
        set(handles.loadsave_p,'visible','off')
        set(handles.FCset_p,'visible','off')
        set(handles.WA_p,'visible','off')
        set(handles.fitta_p,'visible','off')
        set(handles.axes_p,'visible','off')
        set(handles.about_p,'visible','on')
        set(handles.results_p,'visible','off')
        set(handles.editpks_p,'visible','off')
        set(handles.resall_p,'visible','off')
        
        imshow('big-dipper.png','parent',handles.axes13)
        imshow('octocat.jpg','parent',handles.axes11)
        imshow('drn.png','parent',handles.axes12)
        imshow('help.png','parent',handles.axes10)
        imshow('mail.png','parent',handles.axes9)
end

% --- Executes during object creation, after setting all properties.
function menu_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to menu_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in getFC_b.
function getFC_b_Callback(hObject, eventdata, handles)
% hObject    handle to getFC_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% get FCs for fitting

%loads
haxes = handles.axes1;
figure(2)
haxes = gca
selected = getdppFCpref('selected');
delK = getdppFCpref('delK');
sample_n = getdppFCpref('sample_n');
load([cd,'/0. variables/phases.mat'],'dsettings')

% get fcs
[  ~, FC, ~]=get_myFCs(selected);

% define L
L=0:1:size( FC,1 )-1;
a3=0.5/delK;
L=L*a3;

%plots
hold(haxes,'off')
plot(L,FC(:,selected),'.:','markersize',15, 'linewidth',2,'parent', haxes),
xlim(haxes, [0 sample_n*1.3*a3])
ind_leg= num2str( dsettings(1,1).index(selected,:) );
set(haxes,'fontsize',17)
legend(haxes, ind_leg)
xlabel(haxes, 'L- Fourier length (x 10^-^1^0m)','fontsize',17)
ylabel(haxes,'Fourier coefficients A(n)','fontsize',17)
grid(haxes,'on')

%saves
save([cd,'/0. variables/FC.mat'],'FC','selected','L','delK')

set(handles.FCexist_b,'value',1)

function sample_n_t_Callback(hObject, eventdata, handles)
% hObject    handle to sample_n_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sample_n_t as text
%        str2double(get(hObject,'String')) returns contents of sample_n_t as a double
%% number of n values to get FCs

valn = str2double(get(hObject,'String'));
setdppFCpref('sample_n', valn);
% --- Executes during object creation, after setting all properties.
function sample_n_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sample_n_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in view_b.
function view_b_Callback(hObject, eventdata, handles)
% hObject    handle to view_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%% create intensity values

% external function
get_Iall
set(handles.Iallexist_b,'value',1)

% --- Executes on selection change in index_l.
function index_l_Callback(hObject, eventdata, handles)
% hObject    handle to index_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns index_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from index_l
%% index of peaks click to plot

%loads
load([cd,'/0. variables/FC_Iall.mat'])
val=get(hObject,'value');
semilogq=getdppFCpref('semilogq');
selected=getdppFCpref('selected');
sample_n=getdppFCpref('sample_n');

I_FC=get(handles.FCintens_b,'value');

% plot initialises
haxes = handles.axes1;
hold(haxes,'off')
set(haxes,'fontsize',17)

switch I_FC
    case 0 %plot intensity
        lenI=size(I_all,1);
        ttxp=-delK:delK/(.5*(lenI-1)):delK;
        if semilogq==1
            semilogy(ttxp,I_all(:,val,2),'b.-','parent',haxes);
        else
            plot(ttxp,I_all(:,val,2),'b.-','parent',haxes);%hold
        end
        hold(haxes,'on')
        plot(ttxp,I_all(:,val,1),'r.-','parent',haxes)
        plot(ttxp,I_all(:,val,3),'k-','parent',haxes)
        ylim(haxes,[-.1 1.1])
        legend(haxes,'Instrumental','Measured','Real','Location','Northeast')

    case 1 %plot FC
        [FCi, FCnew,FCm]=ts_findfourier_indi( selected(val));

        n=0:1:length(FCm)-1;L=n*25;
        plot(L,FCnew(:,selected(val)),'-k','linewidth',3,'parent',haxes),
        hold(haxes,'on')
        plot(L,FCi(:,selected(val)),':k','linewidth',3,'parent',haxes)
        plot(L,FCm(:, selected(val) ),'--k','linewidth',3,'parent',haxes)

        legend(haxes,'Real','Instrument','Measured','Real 2')
        xlabel(haxes,'Fourier Length L (10^-^1^0m)')
        ylabel(haxes,'Fourier coefficients A(L)', 'fontsize',17)
%     xlim([0 sample_n*1.3])
        xlim(haxes,[0 625])
        set(haxes,'fontsize',17)
end


% --- Executes during object creation, after setting all properties.
function index_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to index_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in removepk_b.
function removepk_b_Callback(hObject, eventdata, handles)
% hObject    handle to removepk_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% choose selected peaks
load([cd,'/0. variables/phases.mat'],'dsettings')

inda{1} = 'Done';
for n=1:size(dsettings(1,1).index,1)
    inda{n+1} = num2str(dsettings(1,1).index(n,:));
end

sel=2;h=1;
while sel~=1
    sel = menu('select peaks to use',inda);
    if sel~=1
       selected(h) = sel-1;
       inda{sel}=['>>',inda{sel}];
       h=h+1;
    end
end
setdppFCpref('selected',selected)
set(handles.index_l,'value',1);
set(handles.index_l,'string',num2str(dsettings(1,1).index(selected,:)) )
    
set(handles.selectexist_b,'value',1);

% --- Executes on button press in semilog_b.
function semilog_b_Callback(hObject, eventdata, handles)
% hObject    handle to semilog_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of semilog_b

semilogq = get(hObject,'Value');
setdppFCpref('semilogq', semilogq)

% --- Executes on button press in edit_b.
function edit_b_Callback(hObject, eventdata, handles)
% hObject    handle to edit_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in FCintens_b.
function FCintens_b_Callback(hObject, eventdata, handles)
% hObject    handle to FCintens_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of FCintens_b



% --- Executes on button press in saveIall_b.
function saveIall_b_Callback(hObject, eventdata, handles)
% hObject    handle to saveIall_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% save intensity and FCs


[FileName2, PathName2] = ...
     uiputfile({'*.mat';'*.*'},'Select existing fille to append, or create file');
 
if  PathName2 ~= 0%check entered a file
    
    %% load details
    dppFCpref = getdppFCpref;
    ident = getdppFCpref('sampleID')
    load([cd,'/0. variables/FC.mat'],'FC',...
    'selected','L','delK')
    load([cd,'/0. variables/phases.mat'],'dsettings')
    load([cd,'/0. variables/FC_Iall.mat'],'I_all')

    %% get file location
    filq=exist( [PathName2,FileName2],'file');
    if filq~=0%file exists
        disp('adding to existing file')
        load([PathName2,FileName2],'fita')
        sizfit=length(fita);
    else
        disp('creating new file')
        dotsq=find(FileName2=='.');
        if isempty(dotsq)==0
            FileName2=FileName2(1:dotsq-1);

        end
        FileName2=[FileName2,'_Iall'];
        sizfit=0;
        val_old=1;
        fita=[];
    end

    % get position of file
    % find if file already exists
    for n=1:length(fita)

        noms=fita(1,n).name;
        ifind=strcmp(noms,ident);
        val_old=sizfit+1;
        if ifind~=0
            mnuu = menu(['replace previous data: "',ident,'" within file?'] ,'yes','no');
            if mnuu==1
                val_old=n;
                break
            end
        end

    end


%% add data to the save file
    fita(1,val_old).I_all = I_all;
    fita(1,val_old).FC = FC;
    fita(1,val_old).L = L;
    %not strictyly nec as in dppfcpre -- use for safety in case changed?
%     fita(1,val_old).delK = delK;%
%     fita(1,val_old).selected = selected;
    
    fita(1,val_old).dppFCpref = dppFCpref;
    fita(1,val_old).name=ident;
    
    fita(1,val_old).dsettings=dsettings;
    

    val=input('Enter a numerical value For the data:  \n');
    fita(1,val_old).val=val;
    save([PathName2,FileName2],'fita')
    
else
   menu('Error: nothing to load','ok') 
end

% --- Executes on button press in loadIall_b.
function loadIall_b_Callback(hObject, eventdata, handles)
% hObject    handle to loadIall_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%% load FC and I_all data 

[FileName2,PathName2] = uigetfile('*.mat','Select the Intensity Fit file');
if  PathName2 ~= 0%check entered a file

    load([PathName2,FileName2],'fita')
    
    for n = 1:length(fita)
        noms{n} = fita(1,n).name;
    end

    val_old = menu('Select Intensity values to load',noms);

    %% get data from the save file
    I_all = fita(1,val_old).I_all ;
    FC = fita(1,val_old).FC;
    L = fita(1,val_old).L ;
        
    dppFCpref = fita(1,val_old).dppFCpref ;
    ident = fita(1,val_old).name;
    
    dsettings = fita(1,val_old).dsettings;
    
    %% update local data
    dppFCpref = getdppFCpref;
    startup_dppaFC(dppFCpref)
    delK = getdppFCpref('delK');
    selected = getdppFCpref('selected');
    
    setdppFCpref('sampleID', ident);
    set(handles.sampleid_t,'string',ident)
    
    save([cd,'/0. variables/FC.mat'],'FC',...
    'selected','L','delK')
    save([cd,'/0. variables/phases.mat'],'dsettings')
    save([cd,'/0. variables/FC_Iall.mat'],'I_all')


else
    menu('Error: nothing to load','ok');
end

% --- Executes on button press in loadfit_b.
function loadfit_b_Callback(hObject, eventdata, handles)
% hObject    handle to loadfit_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%% load fit data

% loads
[file path] = uigetfile('','Select File containing batch data',[cd,'/3. fit_data/']);

if file~=0
%     load([cd,'/0. variables/phases.mat'],'dsettings')%replace to update
%     menu??
    load([path,file]);
    for n=1:length(fita)
        nom{n}=fita(n).name;
    end

    % select fit file to load
    filnom=menu('Select File',nom);
    filnomI=menu('Select File with Instrumental',nom);

    %extract data
    data=fita(filnom).data;
    data_I=fita(filnomI).data_I;
    
    aa=fita(filnom).aa;
    aabcg=fita(filnom).aabcg;
    aa_I=fita(filnomI).aa_I;
    aabcg_I=fita(filnomI).aabcg_I;
    
    sampleID = nom{filnom};
    setdppFCpref('sampleID', sampleID )
    set(handles.sampleid_t,'string',sampleID)

    save([cd,'/0. variables/data_I.mat'],'data_I')
    save([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
    save([cd,'/0. variables/data.mat'],'data')
    save([cd,'/0. variables/fit.mat'],'aa','aabcg')

    %
    set(handles.fitexist_b,'value',1)
    set(handles.dsettingsexist_b,'value',0)
    set(handles.Iallexist_b,'value',0)
    set(handles.FCexist_b,'value',0)
end



function KWmin_t_Callback(hObject, eventdata, handles)
% hObject    handle to KWmin_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of KWmin_t as text
%        str2double(get(hObject,'String')) returns contents of KWmin_t as a double

%% set minimum KW used for fitting on KW plot
stringa = str2double(get(hObject,'String'));
setdppFCpref('KWmin',stringa);

% --- Executes during object creation, after setting all properties.
function KWmin_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to KWmin_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function KWmax_t_Callback(hObject, eventdata, handles)
% hObject    handle to KWmax_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of KWmax_t as text
%        str2double(get(hObject,'String')) returns contents of KWmax_t as a double

%% set minimum KW used for fitting on KW plot
stringa = str2double(get(hObject,'String'));
setdppFCpref('KWmax',stringa);

% --- Executes during object creation, after setting all properties.
function KWmax_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to KWmax_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in strain_l.
function strain_l_Callback(hObject, eventdata, handles)
% hObject    handle to strain_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns strain_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from strain_l

%% set strain type

val = get(hObject,'Value');

switch val
    case 1
        type_strain = 'Grom';

    case 2
        type_strain = 'Wilk';
    
    
end
setdppFCpref('type_strain',type_strain);

% --- Executes during object creation, after setting all properties.
function strain_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to strain_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in doneSettings_b.
function doneSettings_b_Callback(hObject, eventdata, handles)
% hObject    handle to doneSettings_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% when completed settings

set(handles.FCset_p,'visible','off')
set(handles.axes_p,'visible','on')
set(handles.WA_p,'visible','on')

% --- Executes on selection change in sizestrain_l.
function sizestrain_l_Callback(hObject, eventdata, handles)
% hObject    handle to sizestrain_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns sizestrain_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from sizestrain_l

%% how to separate size and strain

val = get(hObject,'Value');
'logWA';%'linWA','altrn','sfeld'
switch val
    case 1
        type_sizestrain = 'logWA';

    case 2
        type_sizestrain = 'linWA';
    
    case 3
        type_sizestrain = 'altrn';

    case 4
        type_sizestrain = 'none';
    
end
setdppFCpref('type_sizestrain',type_sizestrain);


% --- Executes during object creation, after setting all properties.
function sizestrain_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sizestrain_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox1.
function checkbox1_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox1



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function C200_t_Callback(hObject, eventdata, handles)
% hObject    handle to C200_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of C200_t as text
%        str2double(get(hObject,'String')) returns contents of C200_t as a double
%% define Chk0
chk0 = str2double( get(hObject,'String') );

setdppFCpref('chk0', chk0)

% --- Executes during object creation, after setting all properties.
function C200_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to C200_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function qlo_t_Callback(hObject, eventdata, handles)
% hObject    handle to qlo_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of qlo_t as text
%        str2double(get(hObject,'String')) returns contents of qlo_t as a double
%% define qedge
qedge = str2double( get(hObject,'String') );
setdppFCpref('qedge', qedge)

% --- Executes during object creation, after setting all properties.
function qlo_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to qlo_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function qhi_t_Callback(hObject, eventdata, handles)
% hObject    handle to qhi_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of qhi_t as text
%        str2double(get(hObject,'String')) returns contents of qhi_t as a double
%% define qscrew
qscrew = str2double( get(hObject,'String') );

setdppFCpref('qscrew', qscrew)

% --- Executes during object creation, after setting all properties.
function qhi_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to qhi_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton11.
function pushbutton11_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit9_Callback(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit9 as text
%        str2double(get(hObject,'String')) returns contents of edit9 as a double


% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in radiobutton3.
function radiobutton3_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton3


% --- Executes on button press in loadfit_b.
function pushbutton22_Callback(hObject, eventdata, handles)
% hObject    handle to loadfit_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in saveIall_b.
function pushbutton20_Callback(hObject, eventdata, handles)
% hObject    handle to saveIall_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in loadIall_b.
function pushbutton21_Callback(hObject, eventdata, handles)
% hObject    handle to loadIall_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in saveRes_b.
function saveRes_b_Callback(hObject, eventdata, handles)
% hObject    handle to saveRes_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% save results

[FileName2,PathName2] = uiputfile('*.mat','Select the Fit_Results file');
if PathName2~=0
    %% 
    filq=exist( [PathName2,FileName2]);
   
    if filq~=0
        load([PathName2,FileName2],'FCres_set')
        sizfit=length(FCres_set);
        len=length(FCres_set);
    else
        dotsq=find(FileName2=='.');
        if isempty(dotsq)==0
            FileName2=FileName2(1:dotsq-1);
            FileName2=[FileName2,'_RES'];
        end
        len=0;
        FCres_set=[];
    end
    %%
    load([cd,'/0. variables/FC.mat'],'FC',...
    'selected','L','delK')
    load([cd,'/0. variables/phases.mat'],'dsettings')
    load([cd,'/0. variables/FCresStr.mat'],'FCres')
    load([cd,'/0. variables/all_I.mat'],'all_I')
    dppFCpref = getdppFCpref; 
    sampleID = dppFCpref.sampleID
    
    FCres_set(1,len+1).FCres = FCres;
    FCres_set(1,len+1).dppFCpref = dppFCpref;
    FCres_set(1,len+1).selected = selected;
    FCres_set(1,len+1).ident = sampleID;
    
    %may not be necessary
    FCres_set(1,len+1).dsettings = dsettings;
    FCres_set(1,len+1).FC = FC;
    FCres_set(1,len+1).L = L;
    FCres_set(1,len+1).all_I = all_I;
%     FCres_set(1,len+1).delK = delK;
    
    %then save it
    val=input('input \n');
    FCres_set(1,len+1).val=val;
    save([PathName2,FileName2],'FCres_set')
    
else
   menu('error: no file to load','ok'); 
end
% --- Executes on button press in loadRes_b.
function loadRes_b_Callback(hObject, eventdata, handles)
% hObject    handle to loadRes_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% load combined results

[FileName2,PathName2] = uigetfile('*.mat','Select the Results file');
if FileName2~= 0
    load([PathName2,FileName2],'FCres_set')
    for n=1:length(FCres_set)
        nom{n}=FCres_set(1,n).ident;
    end
    set(handles.resallnom_l,'String',nom)

    save([cd,'/0. variables/FCres_setLocation.mat'],'FileName2','PathName2')

end
% --- Executes on button press in loadsampleSettings_b.
function loadsampleSettings_b_Callback(hObject, eventdata, handles)
% hObject    handle to loadsampleSettings_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%% Load sample settings

%load stuff


%open file location
[file path] = uigetfile({'*.mat';},...%file type
'find Settings file',...%quote
[cd,'\1. settings\']);%location

if file~=0
    %load it  
    load([path,file],'dppapref','dsettings');
    save([cd,'/0. variables/phases.mat'],'dsettings','dppapref')
    %update prefs
    startup_DPPA(dppapref)

    %update GUI
    set(handles.index_l,'value',1);
    set(handles.index_l,'string',num2str(dsettings(1,1).index) )
    set(handles.dsettingsexist_b,'value',1)
else
    disp('error')
end

% --- Executes on button press in Iallexist_b.
function Iallexist_b_Callback(hObject, eventdata, handles)
% hObject    handle to Iallexist_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Iallexist_b


% --- Executes on button press in fitexist_b.
function fitexist_b_Callback(hObject, eventdata, handles)
% hObject    handle to fitexist_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of fitexist_b


% --- Executes on button press in gotoFC_b.
function gotoFC_b_Callback(hObject, eventdata, handles)
% hObject    handle to gotoFC_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%% open edit /fc paer from load

% set(handles.menu_l,'value',4)
% menu_l_Callback(hObject, eventdata, handles)
% --- Executes on button press in dsettingsexist_b.
function dsettingsexist_b_Callback(hObject, eventdata, handles)
% hObject    handle to dsettingsexist_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of dsettingsexist_b


% --- Executes on button press in FCexist_b.
function FCexist_b_Callback(hObject, eventdata, handles)
% hObject    handle to FCexist_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of FCexist_b


% --- Executes on button press in fitFC_b.
function fitFC_b_Callback(hObject, eventdata, handles)
% hObject    handle to fitFC_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of fitFC_b
%% to fit the FCs

valok = get(handles.FCexist_b,'value');
if valok == 1
   disp('add this later FCexist_b') 
else
   disp('add this later FCexist_b') 
end

fitFC_GUI(handles)

% --- Executes when selected object is changed in uibuttongroup2.
function uibuttongroup2_SelectionChangedFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in uibuttongroup2 
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function axes8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes8


% --- Executes on button press in pushbutton49.
function pushbutton49_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton49 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of pushbutton49



function q_t_Callback(hObject, eventdata, handles)
% hObject    handle to q_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of q_t as text
%        str2double(get(hObject,'String')) returns contents of q_t as a double


% --- Executes during object creation, after setting all properties.
function q_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to q_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function gs_t_Callback(hObject, eventdata, handles)
% hObject    handle to gs_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of gs_t as text
%        str2double(get(hObject,'String')) returns contents of gs_t as a double


% --- Executes during object creation, after setting all properties.
function gs_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to gs_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function rho_t_Callback(hObject, eventdata, handles)
% hObject    handle to rho_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of rho_t as text
%        str2double(get(hObject,'String')) returns contents of rho_t as a double


% --- Executes during object creation, after setting all properties.
function rho_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rho_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function M_t_Callback(hObject, eventdata, handles)
% hObject    handle to M_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of M_t as text
%        str2double(get(hObject,'String')) returns contents of M_t as a double


% --- Executes during object creation, after setting all properties.
function M_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to M_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function q2Res_t_Callback(hObject, eventdata, handles)
% hObject    handle to q2Res_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of q2Res_t as text
%        str2double(get(hObject,'String')) returns contents of q2Res_t as a double


% --- Executes during object creation, after setting all properties.
function q2Res_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to q2Res_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton50.
function pushbutton50_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton50 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function cSlip_t_Callback(hObject, eventdata, handles)
% hObject    handle to cSlip_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of cSlip_t as text
%        str2double(get(hObject,'String')) returns contents of cSlip_t as a double


% --- Executes during object creation, after setting all properties.
function cSlip_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cSlip_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function cplusaSlip_t_Callback(hObject, eventdata, handles)
% hObject    handle to cplusaSlip_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of cplusaSlip_t as text
%        str2double(get(hObject,'String')) returns contents of cplusaSlip_t as a double


% --- Executes during object creation, after setting all properties.
function cplusaSlip_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cplusaSlip_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function aSlip_t_Callback(hObject, eventdata, handles)
% hObject    handle to aSlip_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of aSlip_t as text
%        str2double(get(hObject,'String')) returns contents of aSlip_t as a double


% --- Executes during object creation, after setting all properties.
function aSlip_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to aSlip_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in plotres_l.
function plotres_l_Callback(hObject, eventdata, handles)
% hObject    handle to plotres_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns plotres_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from plotres_l

%%
contents = cellstr(get(hObject,'String'));
val=get(hObject,'value');
mnu = contents{val};
dppFCpref = getdppFCpref;

HCPalloy = dppFCpref.HCPalloy;

if strcmp(HCPalloy(1:2),'No')
    dippaFCplot(mnu, handles.axes1, dppFCpref)
else
    dippaFCplot_HCP(mnu, handles.axes1, dppFCpref)
end



% --- Executes during object creation, after setting all properties.
function plotres_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to plotres_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function delK_t_Callback(hObject, eventdata, handles)
% hObject    handle to delK_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of delK_t as text
%        str2double(get(hObject,'String')) returns contents of delK_t as a double
%% define delK
delK = str2double( get(hObject,'String') );

setdppFCpref('delK', delK)

% --- Executes during object creation, after setting all properties.
function delK_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to delK_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in plotraw_b.
function plotraw_b_Callback(hObject, eventdata, handles)
% hObject    handle to plotraw_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in edit_l.
function edit_l_Callback(hObject, eventdata, handles)
% hObject    handle to edit_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns edit_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from edit_l

contents = cellstr(get(hObject,'String'));
val = get(hObject,'value');
value = contents{val}

peakno=get(handles.index_l,'value');
selected = getdppFCpref('selected');

peakno = selected(peakno);
realorinstr = get(handles.realinstrplot_b,'value');
haxes = handles.axes1;

editpks_GUI(value, peakno, realorinstr, haxes, handles)


% plotraw_b_Callback(hObject, eventdata, handles)
set(hObject,'value',1)

getFC_b_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function edit_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit26_Callback(hObject, eventdata, handles)
% hObject    handle to edit26 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit26 as text
%        str2double(get(hObject,'String')) returns contents of edit26 as a double


% --- Executes during object creation, after setting all properties.
function edit26_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit26 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in realinstrplot_b.
function realinstrplot_b_Callback(hObject, eventdata, handles)
% hObject    handle to realinstrplot_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of realinstrplot_b


% --- Executes on button press in nextpk_b.
function nextpk_b_Callback(hObject, eventdata, handles)
% hObject    handle to nextpk_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in saveRes2_b.
function saveRes2_b_Callback(hObject, eventdata, handles)
% hObject    handle to saveRes2_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

saveRes_b_Callback(hObject, eventdata, handles)


% --- Executes on button press in saveIall2_b.
function saveIall2_b_Callback(hObject, eventdata, handles)
% hObject    handle to saveIall2_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

saveIall_b_Callback(hObject, eventdata, handles)


% --- Executes on button press in loadres2_b.
function loadres2_b_Callback(hObject, eventdata, handles)
% hObject    handle to loadres2_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

loadRes_b_Callback(hObject, eventdata, handles)


% --- Executes on selection change in resallnom_l.
function resallnom_l_Callback(hObject, eventdata, handles)
% hObject    handle to resallnom_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns resallnom_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from resallnom_l
%% Samples Combined Results

%loads
load([cd,'/0. variables/FCres_setLocation.mat'],...
    'FileName2','PathName2')

load([PathName2,FileName2],'FCres_set')
val=get(hObject,'Value');

dsettings = FCres_set(1,val).dsettings;
FC = FCres_set(1,val).FC ;
L =  FCres_set(1,val).L;
selected = FCres_set(1,val).selected;

sampleID = FCres_set(1).ident;
delK = getdppFCpref('delK');
dppFCpref = FCres_set(1,val).dppFCpref;
dppFCpref.delK = delK;
dppFCpref.sampleID = sampleID;
startup_dppaFC(dppFCpref)

FCres = FCres_set(1,val).FCres;
all_I = FCres_set(1,val).all_I;

save([cd,'/0. variables/FC.mat'],'FC',...
    'selected','L','delK')
save([cd,'/0. variables/phases.mat'],'dsettings')
save([cd,'/0. variables/FCresStr.mat'],'FCres')
save([cd,'/0. variables/all_I.mat'],'all_I')

set(handles.sampleid_t,'string',sampleID)
set(handles.rhoAR_t,'string',FCres.rho)
set(handles.gsAR_t,'string',FCres.gs)
set(handles.MAR_t,'string',FCres.M)
set(handles.qAR_t,'string',FCres.q)

% --- Executes during object creation, after setting all properties.
function resallnom_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resallnom_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in resallplot_l.
function resallplot_l_Callback(hObject, eventdata, handles)
% hObject    handle to resallplot_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns resallplot_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from resallplot_l
%% PLOT results combined

%% loads
val=get(handles.resallplot_l,'value');
contents = cellstr(get(hObject,'String'));
choii = contents{val};

haxes = handles.axes1;

plotresALL_GUI(haxes,choii)



% --- Executes during object creation, after setting all properties.
function resallplot_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resallplot_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in resallplot2_l.
function resallplot2_l_Callback(hObject, eventdata, handles)
% hObject    handle to resallplot2_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns resallplot2_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from resallplot2_l

%% plot results in all results
contents = cellstr(get(hObject,'String'));
val=get(hObject,'value');
mnu = contents{val};
dppFCpref = getdppFCpref;

dippaFCplot(mnu, handles.axes1, dppFCpref)

% --- Executes during object creation, after setting all properties.
function resallplot2_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resallplot2_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function qAR_t_Callback(hObject, eventdata, handles)
% hObject    handle to qAR_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of qAR_t as text
%        str2double(get(hObject,'String')) returns contents of qAR_t as a double


% --- Executes during object creation, after setting all properties.
function qAR_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to qAR_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function gsAR_t_Callback(hObject, eventdata, handles)
% hObject    handle to gsAR_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of gsAR_t as text
%        str2double(get(hObject,'String')) returns contents of gsAR_t as a double


% --- Executes during object creation, after setting all properties.
function gsAR_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to gsAR_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function rhoAR_t_Callback(hObject, eventdata, handles)
% hObject    handle to rhoAR_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of rhoAR_t as text
%        str2double(get(hObject,'String')) returns contents of rhoAR_t as a double


% --- Executes during object creation, after setting all properties.
function rhoAR_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rhoAR_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function MAR_t_Callback(hObject, eventdata, handles)
% hObject    handle to MAR_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of MAR_t as text
%        str2double(get(hObject,'String')) returns contents of MAR_t as a double


% --- Executes during object creation, after setting all properties.
function MAR_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to MAR_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in contrastAlloys_l.
function contrastAlloys_l_Callback(hObject, eventdata, handles)
% hObject    handle to contrastAlloys_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns contrastAlloys_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from contrastAlloys_l
%% different alloys with known C and q-values

contents = cellstr(get(hObject,'String'));
choi = contents{get(hObject,'Value')} ;

switch choi
    case 'Nickel'
        startup_dppaFC('fcc',0)
        qscrew = 2.333; qedge = 1.515;
        C0screw = 0.289; C0edge = 0.279;
        
        qscrew_ = qscrew; qedge_ = qedge;
        set(handles.HCPset_p,'visible','off')
        
    case 'Stainless Steel'
        startup_dppaFC('fcc',0)
        qscrew = 2.470; qedge = 1.718;
        C0screw = 0.31; C0edge = 0.324;
        
        qscrew_ = qscrew; qedge_ = qedge;
        set(handles.HCPset_p,'visible','off')
        
    case 'HCP'
        C0screw = 1; C0edge = 1;
        startup_dppaFC('hcp',0)
        qscrew = getdppFCpref('qscrew'); 
        qedge = getdppFCpref('qedge');
        
        qscrew_ = 0; qedge_ = 0;
        set(handles.HCPset_p,'visible','on')
        
    case 'Add'
        disp('Error: In progress: add details here later')
        set(handles.HCPset_p,'visible','off')
        
        
end
%% 
if exist('C0screw','var')==1
    C0 = 0.5 * ( C0screw + C0edge );
    
    set(handles.C200_t,'string',C0)
    set(handles.qlo_t,'string',qedge_)    
    set(handles.qhi_t,'string',qscrew_)
    
    setdppFCpref('chk0',C0)
    setdppFCpref('qscrew',qscrew)
    setdppFCpref('qedge',qedge)
    
end

% --- Executes during object creation, after setting all properties.
function contrastAlloys_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to contrastAlloys_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function q1lo_t_Callback(hObject, eventdata, handles)
% hObject    handle to q1lo_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of q1lo_t as text
%        str2double(get(hObject,'String')) returns contents of q1lo_t as a double


% --- Executes during object creation, after setting all properties.
function q1lo_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to q1lo_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function q1hi_t_Callback(hObject, eventdata, handles)
% hObject    handle to q1hi_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of q1hi_t as text
%        str2double(get(hObject,'String')) returns contents of q1hi_t as a double


% --- Executes during object creation, after setting all properties.
function q1hi_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to q1hi_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function q2lo_t_Callback(hObject, eventdata, handles)
% hObject    handle to q2lo_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of q2lo_t as text
%        str2double(get(hObject,'String')) returns contents of q2lo_t as a double


% --- Executes during object creation, after setting all properties.
function q2lo_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to q2lo_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function q2hi_t_Callback(hObject, eventdata, handles)
% hObject    handle to q2hi_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of q2hi_t as text
%        str2double(get(hObject,'String')) returns contents of q2hi_t as a double


% --- Executes during object creation, after setting all properties.
function q2hi_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to q2hi_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes when figure1 is resized.
function figure1_SizeChangedFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in contrastHCP_l.
function contrastHCP_l_Callback(hObject, eventdata, handles)
% hObject    handle to contrastHCP_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns contrastHCP_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from contrastHCP_l

contents = cellstr(get(hObject,'String'));
conta = contents{get(hObject,'Value')};
setdppFCpref('HCPalloy',conta);


% --- Executes during object creation, after setting all properties.
function contrastHCP_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to contrastHCP_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in selectexist_b.
function selectexist_b_Callback(hObject, eventdata, handles)
% hObject    handle to selectexist_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of selectexist_b


% --- Executes on button press in FCsettings_b.
function FCsettings_b_Callback(hObject, eventdata, handles)
% hObject    handle to FCsettings_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.FCset_p,'visible','on')
% --- Executes on button press in FCsettingsexist_b.
function FCsettingsexist_b_Callback(hObject, eventdata, handles)
% hObject    handle to FCsettingsexist_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of FCsettingsexist_b


% --------------------------------------------------------------------
function uipushtool1_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to uipushtool1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
