function FF=steel_bcg(tth, counts, xp, bcg2peak,logplot)
xp=sort(xp);
[FF bbx bby]=bcgminus(tth, counts, xp, bcg2peak*1.25,logplot);
FF=FF';
FF(4)=0;
end
%%
 function [Bfit bbx bby]=bcgminus(tth, counts, xp, bcg2peak,logplot)

                

                incr=tth(2)-tth(1);

                npks=length(xp);

                len=length(tth);

                for t=1:npks            %%%find positions around peak for background

                    xbcg1=xp(t)-bcg2peak           ; %xp x-position at Imax

                    xxx1=abs(tth-xbcg1);

                    posb4(t)=find(xxx1==min(xxx1),1);

                    xbcg2=xp(t)+bcg2peak;

                    xxx2=abs(tth-xbcg2);

                    posa4(t)=find(xxx2==min(xxx2),1);

                end

                %%%%find x,y points for background

                bbx=tth(1:posb4(1));

                bby=counts(1:posb4(1));

                

                AA=posb4(1)+len-posa4(npks);%%%%size of vector

               
                for tt=2:npks

                    bb=bcg2(tth, counts, posb4, posa4);

                    bbx=[bbx;bb(:,1)];

                    bby=[bby;bb(:,2)];

                end

                bbx=[bbx;tth(posa4(npks):len)];

                bby=[bby;counts(posa4(npks):len)];
                if ishold==1;hold;end
                
                if logplot==1
                    semilogy(tth,counts),hold
                else
                    plot(tth,counts),hold
                end
                plot(bbx,bby,'ro-')

                Bfit=fitcube(bbx,bby);
                
                BBfit= tth*Bfit(2) + Bfit(1) + Bfit(3)*tth.^2;
                plot(tth,BBfit,'k','linewidth',4);
                bcgI=zeros(AA,2);

               
%%
                    function BB=bcg2(tth, counts, posb4, posa4)

                        bb1=tth(posa4(tt-1):posb4(tt));

                        bb2=counts(posa4(tt-1):posb4(tt));

                        BB=[bb1, bb2];

                    end

            function [estimates, model,normal] = fitcube(xdata, ydata,thetak)

                % Call fminsearch with a random starting point.

                start_point = rand(1, 3);

                model = @expfun;

                estimates = fminsearch(model, start_point);

                    function [sse, FittedCurve] = expfun(params)

                        A = params(1);

                        m= params(2);

                        lambda = params(3);

                        FittedCurve = xdata*m + A + lambda*xdata.^2;

                        ErrorVector = FittedCurve - ydata;

                        sse = sum(ErrorVector .^ 2);

                    end

            end

 end